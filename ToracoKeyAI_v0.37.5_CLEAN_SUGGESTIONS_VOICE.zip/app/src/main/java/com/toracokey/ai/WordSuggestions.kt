package com.toracokey.ai

import android.content.Context
import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Large local predictive typing engine.
 *
 * It never calls the AI backend for ordinary word suggestions.
 *
 * Features:
 * - 123k+ local vocabulary from the bundled dictionary.
 * - Prefix completion for short and long words.
 * - Fuzzy correction even when the first letter is wrong.
 * - Personal word frequency and personal word-pair learning.
 * - Context-sensitive next-word seeds for common phrases.
 * - Always returns three different word suggestions when possible.
 */
object WordSuggestions {
    private const val ASSET_NAME = "toracokey_words.tsv.gz"
    private const val MAX_PERSONAL_WORDS = 8000
    private const val MAX_PERSONAL_PAIRS = 12000
    private const val MAX_PREFIX_SCAN = 6000
    private const val MAX_FUZZY_SCAN = 30000
    private const val FUZZY_MIN_LENGTH = 3
    private const val PERSONAL_WORD_WEIGHT = 24.0
    private const val PERSONAL_PAIR_WEIGHT = 34.0

    private data class Entry(
        val word: String,
        val frequency: Int
    )

    private var appContext: Context? = null
    @Volatile private var loaded = false
    @Volatile private var loading = false
    private var entries: List<Entry> = emptyList()
    private var topFrequencyWords: List<String> = emptyList()

    // Fuzzy indexes avoid scanning the complete 123k dictionary on every key.
    private val firstLetterBuckets = HashMap<Char, MutableList<Entry>>()
    private val lastLetterBuckets = HashMap<Char, MutableList<Entry>>()
    private val secondLetterBuckets = HashMap<Char, MutableList<Entry>>()

    private val personalWords = ConcurrentHashMap<String, Int>()
    private val personalPairs = ConcurrentHashMap<String, Int>()

    private val fallback = listOf(
        "the", "a", "to", "and", "is", "it", "this", "that", "you", "your",
        "my", "me", "for", "with", "in", "on", "of", "can", "will", "have",
        "want", "need", "more", "some", "also", "just", "now", "then", "there", "here"
    )

    /** Small context seed model. Personal pairs always outrank these seeds. */
    private val commonNextWords: Map<String, List<String>> = mapOf(
        "the" to listOf("best", "same", "next", "first", "most", "new"),
        "a" to listOf("good", "new", "little", "few", "lot", "long"),
        "an" to listOf("example", "important", "easy", "interesting", "idea", "answer"),
        "i" to listOf("am", "will", "can", "have", "want", "need"),
        "you" to listOf("can", "will", "have", "need", "want", "are"),
        "we" to listOf("can", "will", "have", "need", "are", "should"),
        "they" to listOf("are", "have", "can", "will", "were", "want"),
        "he" to listOf("is", "was", "has", "will", "can", "did"),
        "she" to listOf("is", "was", "has", "will", "can", "did"),
        "it" to listOf("is", "was", "will", "can", "has", "does"),
        "this" to listOf("is", "was", "will", "can", "means", "time"),
        "that" to listOf("is", "was", "the", "you", "we", "can"),
        "what" to listOf("is", "are", "do", "does", "was", "about"),
        "how" to listOf("are", "can", "do", "to", "much", "many"),
        "where" to listOf("is", "are", "can", "do", "did", "was"),
        "when" to listOf("is", "are", "will", "can", "did", "was"),
        "why" to listOf("is", "are", "do", "does", "did", "not"),
        "please" to listOf("send", "give", "help", "tell", "make", "check"),
        "thank" to listOf("you", "god", "them", "him", "her", "everyone"),
        "thankful" to listOf("for", "that", "to", "today", "we", "you"),
        "good" to listOf("morning", "night", "idea", "job", "luck", "work"),
        "goodbye" to listOf("for", "and", "everyone", "friend", "message", "now"),
        "congratulations" to listOf("on", "for", "you", "to", "and", "again"),
        "happy" to listOf("birthday", "to", "for", "with", "new", "day"),
        "see" to listOf("you", "the", "this", "it", "what", "how"),
        "let" to listOf("me", "us", "them", "it", "him", "her"),
        "need" to listOf("to", "a", "help", "more", "some", "you"),
        "want" to listOf("to", "a", "you", "more", "this", "the"),
        "going" to listOf("to", "home", "there", "out", "back", "well"),
        "go" to listOf("to", "home", "there", "back", "ahead", "now"),
        "come" to listOf("here", "back", "home", "with", "and", "to"),
        "make" to listOf("a", "the", "it", "sure", "this", "your"),
        "made" to listOf("a", "the", "it", "this", "sure", "me"),
        "can" to listOf("you", "be", "do", "make", "get", "help"),
        "will" to listOf("be", "have", "do", "get", "make", "come"),
        "would" to listOf("be", "have", "like", "you", "do", "want"),
        "could" to listOf("be", "you", "have", "do", "help", "make"),
        "should" to listOf("be", "have", "do", "go", "get", "make"),
        "have" to listOf("to", "a", "been", "the", "you", "more"),
        "has" to listOf("been", "a", "the", "to", "not", "more"),
        "had" to listOf("a", "been", "to", "the", "not", "more"),
        "for" to listOf("the", "a", "you", "your", "this", "me"),
        "with" to listOf("the", "a", "you", "this", "your", "me"),
        "from" to listOf("the", "a", "you", "this", "your", "here"),
        "about" to listOf("the", "this", "it", "you", "to", "a"),
        "after" to listOf("the", "a", "that", "you", "this", "we"),
        "before" to listOf("the", "you", "a", "we", "this", "it"),
        "right" to listOf("now", "away", "here", "there", "back", "after"),
        "just" to listOf("a", "the", "now", "want", "need", "like"),
        "very" to listOf("good", "much", "well", "important", "happy", "easy"),
        "more" to listOf("than", "about", "time", "information", "people", "help"),
        "much" to listOf("more", "better", "than", "time", "for", "of"),
        "many" to listOf("people", "times", "more", "different", "things", "years"),
        "time" to listOf("to", "for", "and", "is", "will", "now"),
        "today" to listOf("is", "was", "will", "and", "we", "you"),
        "tomorrow" to listOf("is", "will", "morning", "at", "and", "we"),
        "yesterday" to listOf("was", "i", "we", "and", "the", "when"),
        "morning" to listOf("everyone", "i", "is", "today", "and", "to"),
        "night" to listOf("and", "everyone", "i", "is", "good", "you"),
        "school" to listOf("today", "tomorrow", "is", "and", "for", "the"),
        "work" to listOf("today", "tomorrow", "is", "and", "from", "with"),
        "home" to listOf("now", "today", "and", "from", "to", "again"),
        "phone" to listOf("number", "call", "is", "and", "for", "the"),
        "call" to listOf("me", "you", "back", "the", "and", "when"),
        "message" to listOf("me", "you", "the", "and", "for", "now"),
        "typing" to listOf("this", "is", "a", "the", "on", "test"),
        "test" to listOf("this", "the", "is", "again", "and", "for"),
        "keyboard" to listOf("is", "for", "and", "the", "with", "on"),
        "voice" to listOf("typing", "input", "recognition", "is", "not", "works"),
        "input" to listOf("text", "field", "connection", "is", "from", "to"),
        "text" to listOf("and", "in", "the", "is", "for", "to"),
        "word" to listOf("suggestions", "is", "for", "and", "in", "the"),
        "words" to listOf("and", "are", "with", "for", "the", "that"),
        "suggestion" to listOf("is", "for", "the", "and", "to", "word"),
        "suggestions" to listOf("are", "for", "the", "and", "to", "word"),
        "answer" to listOf("is", "the", "to", "for", "and", "that"),
        "question" to listOf("is", "about", "and", "for", "the", "that"),
        "problem" to listOf("is", "with", "the", "and", "that", "for"),
        "because" to listOf("the", "i", "it", "you", "we", "they"),
        "if" to listOf("you", "it", "we", "the", "there", "i"),
        "and" to listOf("the", "i", "a", "you", "it", "we"),
        "but" to listOf("i", "the", "you", "it", "we", "this"),
        "or" to listOf("the", "a", "you", "i", "it", "this"),
        "not" to listOf("the", "a", "be", "to", "have", "for"),
        "never" to listOf("be", "been", "the", "again", "a", "to"),
        "always" to listOf("be", "have", "the", "and", "try", "use"),
        "first" to listOf("time", "of", "the", "one", "step", "day"),
        "last" to listOf("time", "night", "week", "year", "one", "day"),
        "next" to listOf("time", "step", "day", "week", "word", "one"),
        "same" to listOf("time", "thing", "as", "for", "way", "here"),
        "different" to listOf("from", "ways", "things", "types", "words", "people")
    )

    fun initialize(context: Context) {
        appContext = context.applicationContext
        loadPersonalLearning()
        if (loaded || loading) return
        loading = true
        Thread {
            try {
                loadDictionary()
            } finally {
                loading = false
            }
        }.start()
    }

    /** Returns exactly up to [limit] useful word suggestions, normally three. */
    fun suggest(text: String, limit: Int = 3): List<String> {
        if (limit <= 0) return emptyList()
        ensureLoadedSynchronouslyIfPossible()

        val trailingSpace = text.lastOrNull()?.isWhitespace() == true
        val trimmed = text.trimEnd()
        val words = tokenize(trimmed)

        if (trailingSpace) {
            return nextWordCandidates(words, limit)
        }

        val last = words.lastOrNull().orEmpty()
        if (last.isEmpty()) return fill(fallback, limit)

        val lower = last.lowercase(Locale.ROOT)
        val completions = prefixCandidates(lower, max(limit * 8, 12))
        val fuzzy = if (lower.length >= FUZZY_MIN_LENGTH) fuzzyCandidates(lower) else emptyList()

        // Never stop suggesting merely because the current word is valid.
        // Exact matches are kept only as a weak candidate and next-word/context
        // seeds fill the remaining slots.
        val context = if (words.size > 1) words.dropLast(1) + lower else listOf(lower)
        val contextNext = nextWordCandidates(context, limit * 3)

        return fill(
            completions +
                fuzzy +
                contextNext +
                personalWords.entries
                    .sortedByDescending { it.value }
                    .map { it.key } +
                fallback,
            limit
        )
    }

    fun learnFromText(text: String) {
        val words = tokenize(text)
        if (words.isEmpty()) return

        words.forEach { word ->
            incrementBounded(personalWords, word, MAX_PERSONAL_WORDS)
        }
        for (i in 1 until words.size) {
            val pair = words[i - 1] + "\u0000" + words[i]
            incrementBounded(personalPairs, pair, MAX_PERSONAL_PAIRS)
        }
        savePersonalLearning()
    }

    fun learnSelection(contextText: String, selectedWord: String) {
        val word = selectedWord.trim().lowercase(Locale.ROOT)
        if (word.isEmpty()) return
        incrementBounded(personalWords, word, MAX_PERSONAL_WORDS)

        val previous = tokenize(contextText).lastOrNull()
        if (!previous.isNullOrEmpty()) {
            incrementBounded(personalPairs, previous + "\u0000" + word, MAX_PERSONAL_PAIRS)
        }
        savePersonalLearning()
    }

    private fun nextWordCandidates(words: List<String>, limit: Int): List<String> {
        if (limit <= 0) return emptyList()
        val previous = words.lastOrNull()?.lowercase(Locale.ROOT)
        if (previous.isNullOrEmpty()) return fill(fallback + topFrequencyWords, limit)

        val pairPrefix = previous + "\u0000"
        val rankedPersonal = personalPairs.entries
            .asSequence()
            .filter { it.key.startsWith(pairPrefix) }
            .map { pair ->
                val word = pair.key.removePrefix(pairPrefix)
                word to (pair.value * PERSONAL_PAIR_WEIGHT + 100.0)
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .toList()

        val contextual = commonNextWords[previous].orEmpty()
        val personalBroad = personalWords.entries
            .sortedByDescending { it.value }
            .map { it.key }
            .take(limit * 6)

        // Rotate corpus fallback by the previous word so unknown contexts do
        // not display the identical three words forever.
        val corpus = rotatedTopWords(previous, limit * 8)

        return fill(
            rankedPersonal + contextual + personalBroad + corpus + fallback,
            limit
        )
    }

    private fun rotatedTopWords(seed: String, count: Int): List<String> {
        if (topFrequencyWords.isEmpty()) return emptyList()
        val start = (seed.hashCode() and Int.MAX_VALUE) % topFrequencyWords.size
        return (0 until min(count, topFrequencyWords.size)).map { offset ->
            topFrequencyWords[(start + offset) % topFrequencyWords.size]
        }
    }

    private fun prefixCandidates(prefix: String, wanted: Int): List<String> {
        if (!loaded || entries.isEmpty() || prefix.isEmpty()) return emptyList()

        val start = lowerBound(prefix)
        val candidates = ArrayList<Pair<String, Double>>()
        var index = start
        var scanned = 0
        while (index < entries.size &&
            entries[index].word.startsWith(prefix) &&
            scanned < MAX_PREFIX_SCAN
        ) {
            val entry = entries[index]
            val personal = personalWords[entry.word] ?: 0
            val exactBonus = if (entry.word == prefix) -10.0 else 0.0
            val lengthPenalty = max(0, entry.word.length - prefix.length) * 0.28
            val score =
                baseScore(entry.frequency) +
                    personal * PERSONAL_WORD_WEIGHT +
                    exactBonus - lengthPenalty
            candidates.add(entry.word to score)
            index++
            scanned++
        }

        personalWords.entries
            .asSequence()
            .filter { it.key.startsWith(prefix) }
            .forEach { item ->
                candidates.add(
                    item.key to (
                        item.value * PERSONAL_WORD_WEIGHT +
                            100.0 -
                            max(0, item.key.length - prefix.length) * 0.28
                        )
                )
            }

        return candidates
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(wanted)
    }

    private fun fuzzyCandidates(token: String): List<String> {
        if (!loaded || entries.isEmpty() || token.length < FUZZY_MIN_LENGTH) return emptyList()

        val candidateSet = LinkedHashSet<Entry>()
        val first = token.first()
        val last = token.last()
        val second = token.getOrNull(1)

        firstLetterBuckets[first].orEmpty().forEach { candidateSet.add(it) }
        lastLetterBuckets[last].orEmpty().forEach { candidateSet.add(it) }
        if (second != null) secondLetterBuckets[second].orEmpty().forEach { candidateSet.add(it) }

        val minLength = max(2, token.length - 2)
        val maxLength = token.length + 2
        val cutoff = if (token.length <= 5) 2 else 3
        val candidates = ArrayList<Pair<String, Double>>()
        var scanned = 0

        for (entry in candidateSet) {
            if (scanned >= MAX_FUZZY_SCAN) break
            scanned++
            if (entry.word == token || entry.word.length !in minLength..maxLength) continue

            val distance = editDistance(token, entry.word, cutoff)
            if (distance > cutoff) continue

            val firstBonus = if (entry.word.firstOrNull() == first) 9.0 else 0.0
            val lastBonus = if (entry.word.lastOrNull() == last) 7.0 else 0.0
            val secondBonus = if (second != null && entry.word.getOrNull(1) == second) 4.0 else 0.0
            val personal = personalWords[entry.word] ?: 0
            val score =
                -distance * 70.0 +
                    firstBonus +
                    lastBonus +
                    secondBonus +
                    baseScore(entry.frequency) +
                    personal * PERSONAL_WORD_WEIGHT
            candidates.add(entry.word to score)
        }

        personalWords.entries.forEach { item ->
            if (item.key == token || item.key.length !in minLength..maxLength) return@forEach
            val distance = editDistance(token, item.key, cutoff)
            if (distance <= cutoff) {
                val firstBonus = if (item.key.firstOrNull() == first) 9.0 else 0.0
                val lastBonus = if (item.key.lastOrNull() == last) 7.0 else 0.0
                candidates.add(
                    item.key to (
                        -distance * 70.0 +
                            firstBonus +
                            lastBonus +
                            item.value * PERSONAL_WORD_WEIGHT +
                            100.0
                        )
                )
            }
        }

        return candidates
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(8)
    }

    private fun baseScore(frequency: Int): Double = ln((frequency + 1).toDouble()) * 4.0

    private fun editDistance(a: String, b: String, cutoff: Int): Int {
        if (abs(a.length - b.length) > cutoff) return cutoff + 1
        if (a == b) return 0

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in a.indices) {
            current[0] = i + 1
            var rowMin = current[0]
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = min(
                    min(current[j] + 1, previous[j + 1] + 1),
                    previous[j] + cost
                )
                rowMin = min(rowMin, current[j + 1])
            }
            if (rowMin > cutoff) return cutoff + 1
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }

    private fun lowerBound(prefix: String): Int {
        var low = 0
        var high = entries.size
        while (low < high) {
            val mid = (low + high) ushr 1
            if (entries[mid].word < prefix) low = mid + 1 else high = mid
        }
        return low
    }

    private fun tokenize(text: String): List<String> =
        Regex("[A-Za-z]{2,64}")
            .findAll(text.lowercase(Locale.ROOT))
            .map { it.value }
            .toList()

    private fun fill(candidates: List<String>, limit: Int): List<String> {
        val result = LinkedHashSet<String>()
        for (candidate in candidates) {
            val clean = candidate.trim().lowercase(Locale.ROOT)
            if (clean.matches(Regex("[a-z]{2,64}"))) result.add(clean)
            if (result.size >= limit) return result.toList()
        }
        return result.take(limit)
    }

    private fun loadDictionary() {
        val context = appContext ?: return
        try {
            val loadedEntries = ArrayList<Entry>(130_000)
            context.assets.open(ASSET_NAME).use { raw ->
                GZIPInputStream(raw).use { gzip ->
                    BufferedReader(InputStreamReader(gzip, Charsets.UTF_8), 64 * 1024).useLines { lines ->
                        lines.forEach { line ->
                            val tab = line.indexOf('\t')
                            if (tab <= 1) return@forEach
                            val word = line.substring(0, tab).trim().lowercase(Locale.ROOT)
                            val frequency = line.substring(tab + 1).toIntOrNull() ?: 1
                            if (word.matches(Regex("[a-z]{2,64}"))) {
                                loadedEntries.add(Entry(word, frequency))
                            }
                        }
                    }
                }
            }

            loadedEntries.sortBy { it.word }
            entries = loadedEntries
            topFrequencyWords = loadedEntries
                .sortedByDescending { it.frequency }
                .take(1000)
                .map { it.word }

            firstLetterBuckets.clear()
            lastLetterBuckets.clear()
            secondLetterBuckets.clear()
            loadedEntries.forEach { entry ->
                firstLetterBuckets.getOrPut(entry.word.first()) { ArrayList() }.add(entry)
                lastLetterBuckets.getOrPut(entry.word.last()) { ArrayList() }.add(entry)
                entry.word.getOrNull(1)?.let { second ->
                    secondLetterBuckets.getOrPut(second) { ArrayList() }.add(entry)
                }
            }

            loaded = loadedEntries.isNotEmpty()
        } catch (_: Exception) {
            entries = emptyList()
            topFrequencyWords = emptyList()
            firstLetterBuckets.clear()
            lastLetterBuckets.clear()
            secondLetterBuckets.clear()
            loaded = false
        }
    }

    private fun ensureLoadedSynchronouslyIfPossible() {
        if (loaded) return
        if (loading) return
        loading = true
        try {
            loadDictionary()
        } finally {
            loading = false
        }
    }

    private fun incrementBounded(map: ConcurrentHashMap<String, Int>, key: String, maxEntries: Int) {
        map.merge(key, 1) { old, one -> min(old + one, 100_000) }
        if (map.size > maxEntries) {
            val weakest = map.entries.minByOrNull { it.value }
            if (weakest != null) map.remove(weakest.key, weakest.value)
        }
    }

    private fun loadPersonalLearning() {
        val context = appContext ?: return
        try {
            val prefs = context.getSharedPreferences("toracokey_word_learning", Context.MODE_PRIVATE)
            decodeMap(prefs.getString("words", ""), personalWords)
            decodeMap(prefs.getString("pairs", ""), personalPairs)
        } catch (_: Exception) {}
    }

    private fun savePersonalLearning() {
        val context = appContext ?: return
        try {
            val prefs = context.getSharedPreferences("toracokey_word_learning", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("words", encodeMap(personalWords))
                .putString("pairs", encodeMap(personalPairs))
                .apply()
        } catch (_: Exception) {}
    }

    private fun encodeMap(map: Map<String, Int>): String =
        map.entries.joinToString("|") {
            Base64.encodeToString(it.key.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + ":" + it.value
        }

    private fun decodeMap(raw: String?, target: ConcurrentHashMap<String, Int>) {
        if (raw.isNullOrBlank()) return
        raw.split('|').forEach { item ->
            val split = item.lastIndexOf(':')
            if (split <= 0) return@forEach
            try {
                val key = String(Base64.decode(item.substring(0, split), Base64.NO_WRAP), Charsets.UTF_8)
                val value = item.substring(split + 1).toIntOrNull() ?: return@forEach
                target[key] = value
            } catch (_: Exception) {}
        }
    }
}
