# ToracoKey AI v0.38.7 — Gboard Geometry + Black/Grey Theme + Contextual Unique Suggestions

Based on the v0.38.2 Android project.

Changes in this revision:
- increased the visible keyboard row height to 66dp to move the key geometry closer to the Gboard reference;
- tightened key margins to reduce excessive gaps while preserving full-width touch slots;
- reduced the bottom black tail to 6dp so the empty area below the keyboard is minimized;
- reduced the spacebar weight so it is no longer excessively wide;
- changed the keyboard background to a clearly visible grey-at-top to pure-black-at-bottom gradient;
- changed the key palette to progressively darker grey toward the lower rows;
- increased the suggestion strip to 48dp and matched its grey-to-black treatment more closely;
- moved the Mode changer to the far-left/start of the suggestion strip;
- kept three visible word suggestions and case-insensitive de-duplication;
- added contextual next-word predictions such as `shorter -> i / than / now / version / one`;
- preserved existing AI, voice, authorization, number/symbol pages and utility controls.

Version: 0.38.9
Version code: 53


## v0.38.7 Geometry Alignment
- Increased letter-row height slightly to make the keyboard closer to the Gboard reference height.
- Fixed the third letter row so Z-M uses the same base key width as the A-L row instead of being stretched by its own row weight total.
- Kept Shift and Backspace as wider edge controls with small balancing side spacers.
- Kept Mode fixed at the far-left of the suggestion strip.
- Kept three local suggestions, typo correction, prefix completion, contextual next-word prediction, and personal learning.
- Updated app version and authorization User-Agent to 0.38.7.


## v0.38.9 Dimensions Only
- Reduced the four keyboard row heights to better match the Gboard reference.
- Restored a clearly visible black blank tail below the bottom row.
- Reduced the suggestion strip height to match the Gboard toolbar proportion.
- Reduced the left Mode control height with the suggestion strip.
- Kept Z-M column alignment unchanged.
- No changes to authorization, suggestions logic, voice, or backend.


ToracoKey AI v0.39.0 - dimensions only.
Keyboard row height: 60dp. Bottom blank black tail: 48dp.
Authorization, suggestions, voice, and backend are unchanged.


## v0.45.0 remote policy and typing modes

This source adds Vertical and Stair typing, adjusts the bottom-row comma/number-switcher/spacebar widths, and checks the server-owned feature policy at `GET /device/policy`. The backend must be updated first using `backend-policy-router.js` and `BACKEND_POLICY_SETUP.md`. Until the policy endpoint exists and returns an allowed policy, this build intentionally disables typing rather than silently bypassing remote controls.

Admin controls are protected by `TORACOKEY_ADMIN_TOKEN`; use the backend setup guide to toggle `typingEnabled`, `aiEnabled`, and `minimumAppVersion`. Existing APKs do not gain remote-control behavior retroactively.
