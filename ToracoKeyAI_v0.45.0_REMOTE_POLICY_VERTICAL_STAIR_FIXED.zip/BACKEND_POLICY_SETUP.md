# ToracoKey remote policy — backend integration

**Deploy this backend change before installing the v0.45.0 Android build.** The current backend does not yet expose `/device/policy`; the new Android build fails closed if it cannot verify the policy.

## 1. Add the router

Copy `backend-policy-router.js` into the backend repository. In `server.js`, near the other imports, add:

```js
const { router: toracoPolicyRouter, loadPolicy: loadToracoPolicy } = require('./backend-policy-router');
```

Mount it **after** `express.json()` and **after** the existing app-version middleware for `/device` and `/ask`, so `/device/policy` is version-gated too:

```js
app.use(toracoPolicyRouter);
```

Keep your existing admin token secret configured as `TORACOKEY_ADMIN_TOKEN`. Do not remove authentication from admin routes. Ensure the hosting platform's filesystem is persistent if you want policy changes to survive restarts/redeploys; otherwise set `TORACOKEY_POLICY_FILE` to a persistent disk path.

## 2. Make the minimum-version middleware use the policy value

In the existing `enforceMinimumAppVersion` middleware, replace the fixed minimum-version constant used for comparisons and in the 426 response with:

```js
const minimumVersion = loadToracoPolicy().minimumAppVersion;
```

Use `minimumVersion` for the semver comparison and response's `minimumAppVersion` field. Keep the app-version header validation and 426 behavior. This makes the minimum version remotely changeable through the protected policy endpoint. If your backend's semver helper is scoped elsewhere, keep using that same helper.

## 3. Ensure the AI endpoint obeys the AI switch

At the beginning of the `/ask` route handler, after version middleware and before provider work, add:

```js
const policy = loadToracoPolicy();
if (!policy.typingEnabled || !policy.aiEnabled) {
  return res.status(503).json({ ok: false, code: 'FEATURE_DISABLED', error: 'AI is disabled by the administrator' });
}
```

If you want AI to be independently switchable while typing is disabled, remove the `!policy.typingEnabled` part. The supplied Android client treats AI as disabled whenever typing is disabled.

## 4. Remove per-device approval from the app-facing routes

The Android source no longer calls `/device/register` and no longer waits for a device to be manually authorized. In `server.js`, remove the per-device registered/authorized-device rejection from the `/ask` handler (and any app-facing typing/suggestion endpoints that use the same approval check). Keep the app-version middleware and the feature-policy checks. **Do not remove `TORACOKEY_ADMIN_TOKEN` protection from administrative routes.** The `/device/policy` route must remain available without per-device approval, but it must remain behind minimum-version enforcement.

## 5. Admin control examples

Use your real backend URL and admin token. Do not share the token publicly.

Get current policy:

```bash
curl -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  https://YOUR-BACKEND/admin/policy
```

Disable all ToracoKey typing modes and AI:

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"typingEnabled":false,"aiEnabled":false,"message":"ToracoKey is temporarily disabled"}'
```

Re-enable typing but keep AI off:

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"typingEnabled":true,"aiEnabled":false,"message":"AI is temporarily disabled"}'
```

Raise the minimum version (example):

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"minimumAppVersion":"0.46.0"}'
```

## Important limits

- This controls builds that implement `/device/policy` checks, such as the new Android source in this ZIP. Existing v0.44.0 and older APKs do not implement this policy endpoint, so this cannot remotely disable their local typing modes.
- Connected new builds refresh the policy about once per minute. If the server cannot be reached, the app uses a cached policy for at most five minutes, then disables typing and AI until it can verify the policy again.
- Version headers are not cryptographic proof of APK identity; a modified client can spoof them.
- Test with a staging backend first. Do not deploy a minimum version higher than the version you have distributed unless you intend to block older installs.
