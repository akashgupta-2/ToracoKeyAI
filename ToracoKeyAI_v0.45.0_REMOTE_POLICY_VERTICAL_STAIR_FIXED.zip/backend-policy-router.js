// ToracoKey remote feature-policy addon (CommonJS / Express)
// Integration: see BACKEND_POLICY_SETUP.md before deploying.
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const router = express.Router();
const POLICY_FILE = process.env.TORACOKEY_POLICY_FILE || path.join(process.cwd(), 'toracokey-policy.json');
const DEFAULT_POLICY = Object.freeze({
  minimumAppVersion: '0.45.0',
  typingEnabled: true,
  aiEnabled: true,
  message: 'ToracoKey is enabled',
  updatedAt: null
});

function loadPolicy() {
  try {
    const saved = JSON.parse(fs.readFileSync(POLICY_FILE, 'utf8'));
    return {
      minimumAppVersion: String(saved.minimumAppVersion || DEFAULT_POLICY.minimumAppVersion),
      typingEnabled: saved.typingEnabled !== false,
      aiEnabled: saved.aiEnabled !== false,
      message: String(saved.message || DEFAULT_POLICY.message).slice(0, 240),
      updatedAt: saved.updatedAt || null
    };
  } catch (_) {
    return { ...DEFAULT_POLICY };
  }
}

function savePolicy(policy) {
  const dir = path.dirname(POLICY_FILE);
  fs.mkdirSync(dir, { recursive: true });
  const temp = `${POLICY_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(policy, null, 2), { mode: 0o600 });
  fs.renameSync(temp, POLICY_FILE);
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function requireAdmin(req, res, next) {
  const expected = process.env.TORACOKEY_ADMIN_TOKEN;
  const provided = req.get('X-ToracoKey-Admin-Token') ||
    (req.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  if (!expected || !safeEqual(provided, expected)) {
    return res.status(401).json({ ok: false, error: 'Admin authentication required' });
  }
  next();
}

// App-facing policy. Keep this route behind the app-version middleware in server.js.
router.get('/device/policy', (req, res) => {
  const p = loadPolicy();
  res.set('Cache-Control', 'no-store');
  res.json({
    ok: true,
    minimumAppVersion: p.minimumAppVersion,
    typingEnabled: p.typingEnabled,
    aiEnabled: p.aiEnabled,
    message: p.message,
    updatedAt: p.updatedAt
  });
});

// Protected control endpoint. Example: PATCH /admin/policy
router.get('/admin/policy', requireAdmin, (_req, res) => res.json({ ok: true, policy: loadPolicy() }));
router.patch('/admin/policy', requireAdmin, express.json({ limit: '8kb' }), (req, res) => {
  const current = loadPolicy();
  const body = req.body || {};
  const next = {
    minimumAppVersion: body.minimumAppVersion === undefined
      ? current.minimumAppVersion : String(body.minimumAppVersion).trim(),
    typingEnabled: body.typingEnabled === undefined ? current.typingEnabled : body.typingEnabled === true,
    aiEnabled: body.aiEnabled === undefined ? current.aiEnabled : body.aiEnabled === true,
    message: body.message === undefined ? current.message : String(body.message).trim().slice(0, 240),
    updatedAt: new Date().toISOString()
  };
  if (!/^\d+\.\d+\.\d+$/.test(next.minimumAppVersion)) {
    return res.status(400).json({ ok: false, error: 'minimumAppVersion must use x.y.z format' });
  }
  if (!next.typingEnabled) next.aiEnabled = false;
  savePolicy(next);
  res.set('Cache-Control', 'no-store');
  return res.json({ ok: true, policy: next });
});

module.exports = { router, loadPolicy };
