package com.toracokey.ai

import android.content.Context
import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** Fast local keyboard suggestions: prefix completion, typo correction and learning. */
object WordSuggestions {
    private const val ASSET = "toracokey_words.tsv.gz"
    private const val MAX_WORDS = 4000
    private const val MAX_PAIRS = 6000
    private const val PREFIX_SCAN = 5000
    private const val FUZZY_SCAN = 16000

    private data class Entry(val word: String, val frequency: Int)

    private var context: Context? = null
    @Volatile private var loaded = false
    @Volatile private var loading = false
    private var entries: List<Entry> = emptyList()
    private var topCommon: List<String> = emptyList()

    private val personalWords = ConcurrentHashMap<String, Int>()
    private val personalPairs = ConcurrentHashMap<String, Int>()
    private val first = HashMap<Char, MutableList<Entry>>()
    private val second = HashMap<Char, MutableList<Entry>>()
    private val last = HashMap<Char, MutableList<Entry>>()

    private val common = """
        i a an the to of and or in on at for from with is are am was were be been being
        have has had do does did can could will would should may might must this that these
        those it its they them their we us he him his she her my me your our mine yours
        what when where why how who which all any some no not never always just only very
        more most less many few enough good better best bad first last next new old same
        different other another one two three four five six seven eight nine ten time day
        week month year today tomorrow yesterday now here there home work school college
        student friend family people person thing things way place world life love need want
        know think make take get give go come see look use find tell ask try help keep let
        put bring start stop happen feel seem become leave call show hear play move live
        write read speak talk say mean message phone computer keyboard voice typing text word
        words suggestion suggestions please thanks thank sorry hello morning evening night
        okay ok yes sure right wrong really probably definitely maybe together again before
        after during while still already also even too much important possible easy hard long
        short great little big small group green greeting ground around going gone general
        government problem probably because congratulations encyclopedia different example
        every everyone everything someone something tomorrow information message school home
        answer question conversation continue control complete correct correction please
    """.trimIndent().split(Regex("\\s+")).toSet()

    private val aliases = mapOf(
        "cong" to listOf("congratulations", "congratulate", "congratulation"),
        "ency" to listOf("encyclopedia", "encyclopaedia", "encyclopedic"),
        "def" to listOf("definitely", "definition", "different"),
        "prob" to listOf("probably", "problem", "problems"),
        "bec" to listOf("because", "become", "became"),
        "tom" to listOf("tomorrow", "together", "tomato"),
        "pls" to listOf("please", "pleasant", "pleased"),
        "msg" to listOf("message", "messages", "messaging"),
        "info" to listOf("information", "inform", "informative"),
        "diff" to listOf("different", "difference", "difficult"),
        "som" to listOf("something", "sometimes", "someone"),
        "evry" to listOf("every", "everyone", "everything"),
        "gud" to listOf("good", "guide", "guilty")
    )

    private val next = mapOf(
        "i" to "am will can have want need",
        "you" to "can will have are need want",
        "we" to "can will have are should need",
        "they" to "are have can will were want",
        "he" to "is was has will can did",
        "she" to "is was has will can did",
        "it" to "is was will can has does",
        "this" to "is was will can means time",
        "that" to "is was the you we can",
        "what" to "is are do does about happened",
        "where" to "is are can do did you",
        "when" to "is are will can did do",
        "why" to "is are do did was not",
        "how" to "are can do much many to",
        "can" to "you i we be help do",
        "could" to "you please i we be help",
        "would" to "you be like have rather want",
        "should" to "be have i we you do",
        "please" to "help send tell let make check",
        "thank" to "you god goodness much very",
        "thanks" to "for you again very so",
        "good" to "morning night job idea luck one",
        "morning" to "everyone sir all too and",
        "night" to "everyone good and too sleep see",
        "the" to "best same next first most new",
        "a" to "good new little few lot long",
        "an" to "example important easy interesting idea answer",
        "and" to "the i a you it we",
        "but" to "i the you it we this",
        "or" to "the a you i it this",
        "not" to "the a be to have for",
        "because" to "the i it you we they",
        "if" to "you it we the there i",
        "great" to "job idea work work day",
        "green" to "color light tea energy",
        "group" to "of chat work members",
        "congratulations" to "on your you and"
    ).mapValues { it.value.split(" ") }

    fun initialize(ctx: Context) {
        context = ctx.applicationContext
        loadLearning()
        if (loaded || loading) return
        loading = true
        Thread { try { loadDictionary() } finally { loading = false } }.start()
    }

    fun suggest(text: String, limit: Int = 3): List<String> {
        if (limit <= 0) return emptyList()
        ensureLoaded()

        val trailingSpace = text.lastOrNull()?.isWhitespace() == true
        val words = tokenize(text)
        val current = if (trailingSpace) "" else words.lastOrNull().orEmpty()
        if (current.isEmpty()) return nextWord(words, limit)

        val token = current.lowercase(Locale.ROOT)
        val exact = findFrequency(token) >= 0
        if (exact && token.length >= 2) return nextWord(words, limit)

        val candidates = LinkedHashSet<String>()
        aliases[token]?.let { candidates.addAll(it) }
        candidates.addAll(prefix(token, limit * 8))
        candidates.addAll(personalPrefix(token))
        candidates.addAll(common.filter { it.startsWith(token) }.sortedByDescending { wordScore(it) })
        if (token.length >= 3) candidates.addAll(fuzzy(token))
        if (token.length >= 3) candidates.addAll(fuzzy(token, relaxed = true))

        val cleaned = candidates.asSequence()
            .map { it.lowercase(Locale.ROOT).trim() }
            .filter { it != token && it.length in 2..32 && it.matches(Regex("[a-z]+")) }
            .distinct()
            .toList()

        val diverse = diverseCandidates(cleaned, limit)
        if (diverse.size >= limit) return diverse

        // Fill missing slots without reintroducing the same morphological
        // family. The old fallback could turn "size" back into
        // "size / sizes / sized" after the diversity filter.
        val fallback = ArrayList<String>(limit)
        val families = HashSet<String>()

        fun addUniqueCandidate(word: String) {
            if (fallback.size >= limit) return
            val clean = word.trim().lowercase(Locale.ROOT)
            if (clean.isEmpty() || clean == token || !clean.matches(Regex("[a-z]+"))) return
            val family = suggestionFamily(clean)
            if (families.add(family)) fallback.add(clean)
        }

        diverse.forEach(::addUniqueCandidate)
        cleaned.forEach(::addUniqueCandidate)
        topCommon.forEach(::addUniqueCandidate)

        return fallback.take(limit)
    }

    fun learnFromText(text: String) {
        val words = tokenize(text)
        if (words.isEmpty()) return
        words.forEach { add(personalWords, it, MAX_WORDS) }
        for (i in 1 until words.size) add(personalPairs, words[i - 1] + "\u0000" + words[i], MAX_PAIRS)
        saveLearning()
    }

    fun learnSelection(contextText: String, selectedWord: String) {
        val word = selectedWord.trim().lowercase(Locale.ROOT)
        if (!word.matches(Regex("[a-z]{2,32}"))) return
        add(personalWords, word, MAX_WORDS)
        tokenize(contextText).dropLast(1).lastOrNull()?.let { add(personalPairs, "$it\u0000$word", MAX_PAIRS) }
        saveLearning()
    }

    private fun prefix(token: String, wanted: Int): List<String> {
        if (!loaded) return emptyList()
        val start = lowerBound(token)
        val scored = ArrayList<Pair<String, Double>>()
        var i = start
        var scanned = 0
        while (i < entries.size && entries[i].word.startsWith(token) && scanned++ < PREFIX_SCAN) {
            val e = entries[i]
            val extra = e.word.length - token.length
            val commonBoost = if (e.word in common) 65.0 else 0.0
            val personalBoost = (personalWords[e.word] ?: 0) * 24.0
            val lengthPenalty = extra * if (token.length <= 3) 1.0 else 0.35
            val frequencyScore = ln((e.frequency + 1).toDouble()) * 10.0
            scored += e.word to (frequencyScore + commonBoost + personalBoost - lengthPenalty)
            i++
        }
        return scored.sortedByDescending { it.second }.map { it.first }.distinct().take(wanted)
    }

    private fun fuzzy(token: String, relaxed: Boolean = false): List<String> {
        if (!loaded || token.length < 3) return emptyList()
        val cutoff = if (relaxed) min(4, max(2, token.length / 3)) else when {
            token.length <= 4 -> 1
            token.length <= 7 -> 2
            else -> 3
        }
        val set = LinkedHashSet<Entry>()
        first[token.first()].orEmpty().take(5000).forEach(set::add)
        second[token.getOrNull(1)].orEmpty().take(5000).forEach(set::add)
        last[token.last()].orEmpty().take(5000).forEach(set::add)
        val minLen = max(2, token.length - 2)
        val maxLen = token.length + 2
        entries.asSequence().filter { it.word.length in minLen..maxLen }.take(7000).forEach(set::add)

        return set.asSequence().mapNotNull { e ->
            if (e.word == token || e.word.length !in minLen..maxLen) return@mapNotNull null
            val d = editDistance(token, e.word, cutoff)
            if (d > cutoff) return@mapNotNull null
            val commonBoost = if (e.word in common) 55.0 else 0.0
            val personalBoost = (personalWords[e.word] ?: 0) * 24.0
            e.word to (-d * 100.0 + commonBoost + personalBoost + wordScore(e.word))
        }.sortedByDescending { it.second }.map { it.first }.distinct().take(10).toList()
    }

    /**
     * Avoid filling the three visible slots with the same morphological word
     * family, e.g. "size", "sizes", "sized". Exact duplicates are already
     * removed, but this second filter makes the row feel much closer to a
     * keyboard predictor by preferring genuinely different candidates.
     */
    private fun diverseCandidates(candidates: List<String>, limit: Int): List<String> {
        val result = ArrayList<String>(limit)
        val families = HashSet<String>()
        for (word in candidates) {
            val family = suggestionFamily(word)
            if (family in families) continue
            result += word
            families += family
            if (result.size == limit) break
        }
        return result
    }

    private fun suggestionFamily(word: String): String {
        var w = word
        if (w.length > 6 && w.endsWith("ing")) w = w.dropLast(3)
        else if (w.length > 5 && (w.endsWith("ed") || w.endsWith("er"))) w = w.dropLast(2)
        else if (w.length > 5 && (w.endsWith("es") || w.endsWith("ly"))) w = w.dropLast(2)
        else if (w.length > 4 && w.endsWith("s")) w = w.dropLast(1)
        return w
    }

    private fun personalPrefix(token: String): List<String> = personalWords.entries
        .asSequence().filter { it.key.startsWith(token) }
        .sortedByDescending { it.value }.map { it.key }.take(10).toList()

    private fun nextWord(words: List<String>, limit: Int): List<String> {
        val previous = words.lastOrNull()?.lowercase(Locale.ROOT)
        if (previous.isNullOrBlank()) return topCommon.take(limit)

        val result = LinkedHashSet<String>()

        // First priority: words the user has actually selected after this word.
        personalPairs.entries.asSequence()
            .filter { it.key.startsWith("$previous\u0000") }
            .sortedByDescending { it.value }
            .map { it.key.substringAfter('\u0000') }
            .forEach(result::add)

        // Second priority: built-in context predictions such as
        // "i -> am / will / can" and "a -> good / new / little".
        next[previous].orEmpty().forEach(result::add)

        // Third priority: frequent personal vocabulary, but only words that
        // are useful as standalone next words. Do not dump the same generic
        // dictionary entries into every context.
        personalWords.entries.asSequence()
            .filter { it.value >= 2 }
            .sortedByDescending { it.value }
            .map { it.key }
            .filter { it != previous }
            .take(20)
            .forEach(result::add)

        // Final fallback only if the contextual sources did not provide enough.
        topCommon.forEach { if (result.size < limit) result.add(it) }

        return result.asSequence()
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.matches(Regex("[a-z]{1,32}")) && it != previous }
            .distinctBy { it.lowercase(Locale.ROOT) }
            .take(limit)
            .toList()
    }

    private fun findFrequency(word: String): Int {
        val i = entries.binarySearch(Entry(word, 0), compareBy { it.word })
        return if (i >= 0) entries[i].frequency else -1
    }

    private fun wordScore(word: String): Double {
        val frequency = findFrequency(word)
        return if (frequency >= 0) ln((frequency + 1).toDouble()) * 10.0 else 0.0
    }

    private fun lowerBound(prefix: String): Int {
        var lo = 0
        var hi = entries.size
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (entries[mid].word < prefix) lo = mid + 1 else hi = mid
        }
        return lo
    }

    private fun editDistance(a: String, b: String, cutoff: Int): Int {
        if (abs(a.length - b.length) > cutoff) return cutoff + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            var rowMin = cur[0]
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = min(min(cur[j] + 1, prev[j + 1] + 1), prev[j] + cost)
                rowMin = min(rowMin, cur[j + 1])
            }
            if (rowMin > cutoff) return cutoff + 1
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun tokenize(text: String): List<String> =
        Regex("[A-Za-z]{2,32}").findAll(text.lowercase(Locale.ROOT)).map { it.value }.toList()

    private fun loadDictionary() {
        val ctx = context ?: return
        try {
            val list = ArrayList<Entry>(130000)
            ctx.assets.open(ASSET).use { raw ->
                GZIPInputStream(raw).use { gzip ->
                    BufferedReader(InputStreamReader(gzip, Charsets.UTF_8), 65536).useLines { lines ->
                        lines.forEach { line ->
                            val p = line.indexOf('\t')
                            if (p > 1) {
                                val word = line.substring(0, p)
                                if (word.matches(Regex("[a-z]{2,32}"))) list += Entry(word, line.substring(p + 1).toIntOrNull() ?: 1)
                            }
                        }
                    }
                }
            }
            list.sortBy { it.word }
            entries = list
            first.clear(); second.clear(); last.clear()
            list.forEach { e ->
                first.getOrPut(e.word.first()) { mutableListOf() }.add(e)
                e.word.getOrNull(1)?.let { second.getOrPut(it) { mutableListOf() }.add(e) }
                last.getOrPut(e.word.last()) { mutableListOf() }.add(e)
            }
            topCommon = common.mapNotNull { w -> list.binarySearch(Entry(w, 0), compareBy { it.word }).takeIf { it >= 0 }?.let { w to list[it].frequency } }
                .sortedByDescending { it.second }.map { it.first }
            loaded = list.isNotEmpty()
        } catch (_: Exception) {
            entries = emptyList(); topCommon = common.toList(); loaded = false
        }
    }

    private fun ensureLoaded() {
        if (loaded || loading) return
        loading = true
        try { loadDictionary() } finally { loading = false }
    }

    private fun add(map: ConcurrentHashMap<String, Int>, key: String, maxSize: Int) {
        map.merge(key, 1) { old, _ -> min(old + 1, 100000) }
        if (map.size > maxSize) map.entries.minByOrNull { it.value }?.let { map.remove(it.key, it.value) }
    }

    private fun saveLearning() {
        val ctx = context ?: return
        try {
            val words = personalWords.entries.joinToString("|") { "${it.key}:${it.value}" }
            val pairs = personalPairs.entries.joinToString("|") {
                "${Base64.encodeToString(it.key.toByteArray(), Base64.NO_WRAP)}:${it.value}"
            }
            ctx.getSharedPreferences("toracokey_learning", Context.MODE_PRIVATE).edit()
                .putString("words", words).putString("pairs", pairs).apply()
        } catch (_: Exception) {}
    }

    private fun loadLearning() {
        val ctx = context ?: return
        try {
            val p = ctx.getSharedPreferences("toracokey_learning", Context.MODE_PRIVATE)
            p.getString("words", "").orEmpty().split('|').forEach { item ->
                val x = item.lastIndexOf(':'); if (x > 1) personalWords[item.substring(0, x)] = item.substring(x + 1).toIntOrNull() ?: 1
            }
            p.getString("pairs", "").orEmpty().split('|').forEach { item ->
                val x = item.lastIndexOf(':'); if (x > 1) {
                    val key = runCatching { String(Base64.decode(item.substring(0, x), Base64.NO_WRAP)) }.getOrNull()
                    if (key != null) personalPairs[key] = item.substring(x + 1).toIntOrNull() ?: 1
                }
            }
        } catch (_: Exception) {}
    }
}
