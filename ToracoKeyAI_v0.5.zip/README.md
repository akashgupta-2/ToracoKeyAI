# ToracoKey AI v0.5

ToracoKey AI is an Android input method with a built-in AI suggestion bar.

## v0.5
- Connects to the ToracoKey AI backend over HTTPS.
- Sends detected questions to `/ask` after typing pauses briefly.
- Displays the returned AI answer in the suggestion bar.
- Tapping the answer inserts it into the active app.
- No OpenAI API key is stored in the Android app.
- Shows a connection error message if the backend cannot be reached.

Backend endpoint used by the app:
`https://toracokeyai-backend.onrender.com/ask`

## Security
The OpenAI API key remains server-side on the backend and is never included in this Android project.
