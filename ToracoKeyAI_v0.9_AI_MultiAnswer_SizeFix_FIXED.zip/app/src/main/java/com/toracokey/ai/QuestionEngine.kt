package com.toracokey.ai

object QuestionEngine {

    fun isQuestion(question: String): Boolean {
        val q = question.trim().lowercase()
        if (q.isEmpty()) return false

        val questionWords = listOf(
            "what", "why", "how", "when", "where", "who",
            "which", "can", "is", "are", "define", "explain"
        )

        return q.endsWith("?") || questionWords.any { q.startsWith("$it ") }
    }
}
