package com.toracokey.ai

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ToracoKeyService : InputMethodService() {

    companion object {
        private const val BACKEND_URL = "https://toracokeyai-backend.onrender.com/ask"
        private const val DEBOUNCE_MS = 700L
    }

    private var answerView: TextView? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val debounceExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var pendingRequest: java.util.concurrent.ScheduledFuture<*>? = null
    private var requestNumber = 0L

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 4)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

        val suggestion = TextView(this).apply {
            text = "ToracoKey AI • Type a question"
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.DKGRAY)
            setPadding(12, 0, 12, 0)
            setOnClickListener {
                val answer = tag as? String
                if (!answer.isNullOrEmpty()) {
                    currentInputConnection?.commitText(answer, 1)
                    text = "✓ Answer inserted"
                    tag = null
                }
            }
        }

        answerView = suggestion

        root.addView(
            suggestion,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(52)
            )
        )

        val keyboard = QwertyKeyboard(this) { text ->
            val connection = currentInputConnection ?: return@QwertyKeyboard
            if (text == "\b") {
                connection.deleteSurroundingText(1, 0)
            } else {
                connection.commitText(text, 1)
            }
            updateQuestionDetection()
        }

        root.addView(
            keyboard,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        pendingRequest?.cancel(false)
        requestNumber++
        answerView?.apply {
            text = "ToracoKey AI • Type a question"
            tag = null
        }
    }

    private fun updateQuestionDetection() {
        val view = answerView ?: return
        val connection = currentInputConnection ?: return
        val text = connection.getTextBeforeCursor(300, 0)?.toString() ?: ""
        val isQuestion = QuestionEngine.isQuestion(text)

        pendingRequest?.cancel(false)

        if (!isQuestion) {
            requestNumber++
            view.text = "ToracoKey AI • Type a question"
            view.tag = null
            return
        }

        val trimmedQuestion = text.trim()
        val thisRequest = ++requestNumber
        view.text = "✨ Thinking…"
        view.tag = null

        pendingRequest = debounceExecutor.schedule({
            networkExecutor.execute {
                val answer = askBackend(trimmedQuestion)
                mainHandler.post {
                    if (thisRequest != requestNumber) return@post
                    val currentText = currentInputConnection
                        ?.getTextBeforeCursor(300, 0)
                        ?.toString()
                        ?.trim()

                    if (currentText != trimmedQuestion) return@post

                    if (answer != null) {
                        answerView?.apply {
                            text = "✨ $answer  •  Tap to insert"
                            tag = answer
                        }
                    } else {
                        answerView?.apply {
                            text = "⚠ AI unavailable • Check your connection"
                            tag = null
                        }
                    }
                }
            }
        }, DEBOUNCE_MS, TimeUnit.MILLISECONDS)
    }

    private fun askBackend(question: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 30_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
            }

            val body = JSONObject().put("question", question).toString()
            connection.outputStream.use { output ->
                output.write(body.toByteArray(Charsets.UTF_8))
            }

            val status = connection.responseCode
            val stream = if (status in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            } ?: return null

            val responseBody = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                reader.readText()
            }

            if (status !in 200..299) return null
            JSONObject(responseBody).optString("answer").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    override fun onDestroy() {
        pendingRequest?.cancel(false)
        debounceExecutor.shutdownNow()
        networkExecutor.shutdownNow()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
