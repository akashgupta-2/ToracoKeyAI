# ToracoKey AI v0.9

ToracoKey AI with ReverseCalc features, improved keyboard sizing, multi-answer AI suggestions, and answer-tap replacement.

- 64dp key rows for a taller keyboard
- Reduced bottom blank space
- AI requests ask for up to 3 concise answers
- Up to 3 AI answer chips are shown
- Tapping an AI answer replaces the current question with that answer
