package com.toracokey.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.core.app.ActivityCompat
import java.util.Locale

class VoiceInputActivity : Activity() {
    companion object {
        const val ACTION_VOICE_RESULT = "com.toracokey.ai.VOICE_RESULT"
        const val EXTRA_TEXT = "text"
        const val EXTRA_REQUEST_PERMISSION = "request_permission"
        private const val REQUEST_AUDIO = 7001
        private const val REQUEST_SPEECH = 7002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
        } else {
            startRecognition()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startRecognition()
        } else {
            finish()
        }
    }

    private fun startRecognition() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now")
            }
            startActivityForResult(intent, REQUEST_SPEECH)
        } catch (_: Exception) {
            finish()
        }
    }

    @Deprecated("Deprecated in Android API 30, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).orEmpty()
            val text = results.firstOrNull().orEmpty().trim()
            if (text.isNotEmpty()) {
                sendBroadcast(Intent(ACTION_VOICE_RESULT).setPackage(packageName).putExtra(EXTRA_TEXT, text))
            }
        }
        finish()
    }
}
