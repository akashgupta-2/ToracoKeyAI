# ToracoKey AI v0.24

Android keyboard with seven Smart AI, clipboard, question-detection, and word-suggestion improvements.

## Included improvements
- Clipboard text is appended after the existing context.
- Detects "for what" and "in which" question starters.
- Detects "in what", "from where", "difference between", and "difference from".
- Detects the "thing is used to" construction.
- Trailing spaces do not restart the same AI question context.
- Word suggestions commit the selected word with a following space.
- Existing Smart AI, Rewrite, Explain, voice, calculator, modes, and clipboard features retained.


## v0.30 Hello Mode
- Added `Hello` typing mode.
- Each letter is doubled without spaces: `hello` -> `hheelllloo`.
- Backspace removes one complete generated unit in Hello mode, so one backspace removes two letters.
- Existing Mono, Double, and H H modes also use generated-unit-aware backspace.
