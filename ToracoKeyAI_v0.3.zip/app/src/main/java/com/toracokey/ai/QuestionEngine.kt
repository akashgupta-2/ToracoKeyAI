package com.toracokey.ai

object QuestionEngine {

    fun answer(question: String): String? {
        val q = question.trim().lowercase()
        if (q.isEmpty()) return null

        val questionWords = listOf(
            "what", "why", "how", "when", "where", "who",
            "which", "can", "is", "are", "define", "explain"
        )

        val isQuestion =
            q.endsWith("?") ||
            questionWords.any { q.startsWith("$it ") }

        if (!isQuestion) return null

        return when {
            "2+2" in q -> "4"
            "coulomb" in q -> "F = kq₁q₂/r²"
            "photosynthesis" in q ->
                "Plants use light energy to convert CO₂ and water into glucose and oxygen."
            else -> "Question detected. AI connection will answer this."
        }
    }
}
