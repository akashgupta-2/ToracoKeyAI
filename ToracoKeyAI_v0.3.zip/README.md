# ToracoKey AI v0.3

Android IME prototype.

Changes from v0.2:
- Fixed keyboard layout sizing so keys are always given explicit row heights.
- Added visible key backgrounds and borders.
- Preserved Gboard-style Z-M row indentation.
- Preserved the safe input-method initialization.
- AndroidX and JVM 17 configuration included.

Current AI answers are local demo responses. Internet/AI API integration is the next stage.
