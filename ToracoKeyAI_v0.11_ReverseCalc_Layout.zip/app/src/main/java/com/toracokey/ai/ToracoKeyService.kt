package com.toracokey.ai

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ToracoKeyService : InputMethodService() {
    companion object {
        private const val BACKEND_URL = "https://toracokeyai-backend.onrender.com/ask"
        private const val DEBOUNCE_MS = 700L
        private const val MAX_AI_ANSWERS = 3
    }

    private lateinit var suggestionScroll: HorizontalScrollView
    private lateinit var suggestions: LinearLayout
    private val mainHandler = Handler(Looper.getMainLooper())
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val debounceExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var pendingRequest: java.util.concurrent.ScheduledFuture<*>? = null
    private var requestNumber = 0L
    private var mode = KeyboardMode.NORMAL
    private var latestAiAnswers: List<String> = emptyList()
    private var aiError: String? = null

    private val keyboardBg = Color.rgb(47, 48, 50)
    private val suggestionBg = Color.rgb(61, 64, 68)
    private val keyText = Color.rgb(245, 245, 245)

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setBackgroundColor(keyboardBg)
        }

        suggestionScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(keyboardBg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        suggestions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        suggestionScroll.addView(suggestions, ViewGroup.LayoutParams(-2, dp(40)))
        root.addView(suggestionScroll, LinearLayout.LayoutParams(-1, dp(40)))

        val keyboard = QwertyKeyboard(
            service = this,
            getMode = { mode },
            onKey = { value ->
                if (value == "\b") safeDelete(1) else safeCommit(value)
                updateQuestionDetection()
            },
            onMode = { showModeSelector() },
            onQuestionCheck = { updateQuestionDetection() }
        )
        root.addView(keyboard, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        updateSuggestions()
        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        pendingRequest?.cancel(false)
        requestNumber++
        latestAiAnswers = emptyList()
        aiError = null
        mode = KeyboardMode.NORMAL
        if (::suggestions.isInitialized) updateSuggestions()
    }

    private fun updateQuestionDetection() {
        if (!::suggestions.isInitialized) return
        val text = editorText()
        val isQuestion = QuestionEngine.isQuestion(text) && mode == KeyboardMode.NORMAL
        pendingRequest?.cancel(false)
        latestAiAnswers = emptyList()
        aiError = null
        if (!isQuestion) {
            requestNumber++
            updateSuggestions()
            return
        }
        val question = text.trim()
        val thisRequest = ++requestNumber
        updateSuggestions(thinking = true)
        pendingRequest = debounceExecutor.schedule({
            networkExecutor.execute {
                val aiPrompt =
                    "Answer this question with up to 3 distinct, concise valid answers. " +
                    "Put each answer on its own line. Do not number them and do not add explanations unless necessary. " +
                    "Question: $question"
                val result = askBackend(aiPrompt)
                mainHandler.post {
                    // Only ignore results from an older request. Do not compare the
                    // editor text again: Android IMEs may normalize/correct text
                    // while the network request is in flight.
                    if (thisRequest != requestNumber) return@post
                    latestAiAnswers = result.answer?.let { parseAnswers(it) }.orEmpty()
                    aiError = result.error
                    updateSuggestions()
                }
            }
        }, DEBOUNCE_MS, TimeUnit.MILLISECONDS)
    }

    private fun updateSuggestions(thinking: Boolean = false) {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        addChip("▦ ${modeName()}") { showModeSelector() }

        val all = editorText()
        val tok = all.substringAfterLast(" ")
        Calculator.calculate(tok)?.let { addChip("= $it") { replaceToken(it) } }
        EmojiData.search(tok).forEach { item -> addChip(item.emoji) { replaceToken(item.emoji) } }

        if (thinking) {
            addChip("✨ Thinking…") {}
        } else if (latestAiAnswers.isNotEmpty()) {
            latestAiAnswers.take(MAX_AI_ANSWERS).forEach { answer ->
                addChip("✨ $answer") { replaceAll(all, answer); latestAiAnswers = emptyList(); aiError = null }
            }
        } else if (!aiError.isNullOrBlank() && QuestionEngine.isQuestion(all) && mode == KeyboardMode.NORMAL) {
            addChip("⚠ ${aiError!!}") {}
        } else if (QuestionEngine.isQuestion(all) && mode == KeyboardMode.NORMAL) {
            addChip("✨ AI ready") {}
        }

        if (all.isNotEmpty() && mode != KeyboardMode.NORMAL) {
            val transformed = transformAll(all)
            if (transformed != all) addChip("↻ $transformed") { replaceAll(all, transformed) }
        }

        if (suggestions.childCount == 1) addChip("Type a question • calculator • emoji • modes") {}
    }

    private fun showModeSelector() {
        suggestions.removeAllViews()
        KeyboardMode.values().forEach { selected ->
            val label = when (selected) {
                KeyboardMode.NORMAL -> "Normal"
                KeyboardMode.REVERSE -> "Reverse"
                KeyboardMode.MONO -> "M o n o"
                KeyboardMode.DOUBLE -> "DDoouubbllee"
                KeyboardMode.ALT_CASE -> "aLt CaSe"
                KeyboardMode.SPACED_DOUBLE -> "H H"
            }
            addChip(if (mode == selected) "✓ $label" else label) {
                mode = selected
                latestAiAnswers = emptyList()
                updateSuggestions()
            }
        }
    }

    private fun addChip(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = if (label.startsWith("✨")) 14f else 13f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(8), 0, dp(8), 0)
            background = GradientDrawable().apply { setColor(suggestionBg); cornerRadius = dp(9).toFloat() }
            stateListAnimator = null
            setOnClickListener { try { action() } catch (_: Exception) {} }
        }
        suggestions.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun replaceToken(value: String) {
        val all = editorText()
        val token = all.substringAfterLast(" ")
        if (token.isNotEmpty()) safeDelete(token.length)
        safeCommit(value)
        updateQuestionDetection()
    }

    private fun replaceAll(old: String, value: String) {
        if (old.isNotEmpty()) safeDelete(old.length)
        safeCommit(value)
        updateQuestionDetection()
    }

    private fun transformAll(input: String): String = when (mode) {
        KeyboardMode.NORMAL -> input
        KeyboardMode.REVERSE -> input.reversed()
        KeyboardMode.MONO -> input.split(" ", limit = -1).joinToString(" ") { it.toCharArray().joinToString(" ") }
        KeyboardMode.DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { w -> w.toCharArray().joinToString(" ") { ch -> "$ch$ch" } }
        KeyboardMode.ALT_CASE -> {
            var upper = false
            buildString(input.length) { input.forEach { ch ->
                if (ch == ' ') { append(ch); upper = false }
                else { append(if (upper) ch.uppercaseChar() else ch.lowercaseChar()); upper = !upper }
            }}
        }
        KeyboardMode.SPACED_DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { w -> w.toCharArray().joinToString(" ") { ch -> "$ch $ch" } }
    }

    private fun parseAnswers(raw: String): List<String> {
        return raw
            .replace("\r", "")
            .split("\n", "|||", "•", ";")
            .map { it.trim().replace(Regex("^[-*]\\s+"), "").replace(Regex("^\\d+[.)]\\s+"), "") }
            .filter { it.isNotBlank() }
            .distinct()
            .take(MAX_AI_ANSWERS)
    }

    private fun editorText(): String = try { currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: "" } catch (_: Exception) { "" }
    private fun safeCommit(value: String) { try { currentInputConnection?.commitText(value, 1) } catch (_: Exception) {} }
    private fun safeDelete(count: Int) { try { currentInputConnection?.deleteSurroundingText(count, 0) } catch (_: Exception) {} }

    private fun modeName() = when (mode) {
        KeyboardMode.NORMAL -> "Normal"
        KeyboardMode.REVERSE -> "Reverse"
        KeyboardMode.MONO -> "Mono"
        KeyboardMode.DOUBLE -> "Double"
        KeyboardMode.ALT_CASE -> "Alt"
        KeyboardMode.SPACED_DOUBLE -> "H H"
    }

    private data class AiResult(val answer: String?, val error: String?)

    private fun askBackend(question: String): AiResult {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 45_000
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "ToracoKeyAI/0.9")
            }
            val body = JSONObject().put("question", question).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseBody = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            if (status !in 200..299) {
                return AiResult(null, "Server error $status")
            }
            val answer = JSONObject(responseBody).optString("answer").trim()
            if (answer.isNotBlank()) AiResult(answer, null)
            else AiResult(null, "No answer")
        } catch (e: Exception) {
            val message = e.message?.take(32)?.replace("\n", " ") ?: "Network error"
            AiResult(null, message)
        } finally {
            connection?.disconnect()
        }
    }

    override fun onDestroy() {
        pendingRequest?.cancel(false)
        debounceExecutor.shutdownNow()
        networkExecutor.shutdownNow()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
