package com.toracokey.ai

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.os.Handler
import android.os.Looper

class QwertyKeyboard(
    private val service: InputMethodService,
    private val getMode: () -> KeyboardMode,
    private val onKey: (String) -> Unit,
    private val onMode: () -> Unit,
    private val onQuestionCheck: () -> Unit
) : LinearLayout(service) {

    private val rowHeight = dp(58)
    private val keyboardBg = Color.rgb(47, 48, 50)
    private val keyBg = Color.rgb(70, 73, 78)
    private val keyText = Color.rgb(245, 245, 245)
    private var symbols = false
    private var shift = false
    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false

    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            onKey("\b")
            backspaceHandler.postDelayed(this, 55)
        }
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.TOP
        setPadding(dp(3), dp(3), dp(3), dp(3))
        setBackgroundColor(keyboardBg)
        rebuild()
    }

    private fun rebuild() {
        removeAllViews()
        if (symbols) {
            addRow("1234567890", 0f)
            addRow("@#$%&*()-+", 0.45f)
            addRow(".,!?/:;'\"=", 0.45f, true)
        } else {
            addRow("qwertyuiop", 0f)
            addRow("asdfghjkl", 0.45f)
            addBottomLetterRow()
        }

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        key(bottom, if (symbols) "ABC" else "?123", 1f) {
            symbols = !symbols
            shift = false
            rebuild()
        }
        key(bottom, "▦", 0.9f) { onMode() }
        key(bottom, "SPACE", 4.8f) { onKey(" "); onQuestionCheck() }
        key(bottom, "🌐", 0.9f) {
            try { (service.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showInputMethodPicker() } catch (_: Exception) {}
        }
        key(bottom, "↵", 0.9f) { onEnter(); onQuestionCheck() }
        addView(bottom, LayoutParams(-1, dp(58)))
        // Reserve the same kind of bottom breathing room used by the earlier Gboard-like layout.
        addView(android.view.View(context), LayoutParams(-1, dp(52)))
    }

    private fun addBottomLetterRow() {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        // Gboard-style third row: Shift/ Caps is directly beside Z,
        // followed by Z-M, then Backspace. This keeps the letter row aligned
        // naturally with the S-K row above it.
        row.addView(android.view.View(context), LayoutParams(0, -1, 0.45f))

        key(row, "⇧", 1f) {
            shift = !shift
            rebuild()
        }

        "zxcvbnm".forEach { c ->
            val label = if (shift) c.uppercaseChar().toString() else c.toString()
            key(row, label) { onKey(typeFor(label)); onQuestionCheck() }
        }

        key(row, "⌫", 1f, true) { onKey("\b"); onQuestionCheck() }
        row.addView(android.view.View(context), LayoutParams(0, -1, 0.45f))
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun addRow(chars: String, sideWeight: Float, includeBackspace: Boolean = false) {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (sideWeight > 0f) row.addView(android.view.View(context), LayoutParams(0, -1, sideWeight))
        chars.forEach { c ->
            val label = if (!symbols && shift && c.isLetter()) c.uppercaseChar().toString() else c.toString()
            key(row, label) { onKey(typeFor(label)); onQuestionCheck() }
        }
        if (includeBackspace) key(row, "⌫", 1f, true) { onKey("\b"); onQuestionCheck() }
        if (sideWeight > 0f) row.addView(android.view.View(context), LayoutParams(0, -1, sideWeight))
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun typeFor(label: String): String {
        if (symbols || label.length != 1 || !label[0].isLetter()) return label
        val ch = label[0]
        return when (getMode()) {
            KeyboardMode.NORMAL -> ch.toString()
            KeyboardMode.REVERSE -> ch.toString() // Reverse is applied when suggestion chip is used; typing stays normal.
            KeyboardMode.MONO -> "$ch "
            KeyboardMode.DOUBLE -> "$ch$ch "
            KeyboardMode.ALT_CASE -> {
                val existing = try { service.currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: "" } catch (_: Exception) { "" }
                val letters = existing.count { it.isLetter() }
                if (letters % 2 == 0) ch.lowercaseChar().toString() else ch.uppercaseChar().toString()
            }
            KeyboardMode.SPACED_DOUBLE -> "$ch $ch "
        }
    }

    private fun onEnter() {
        try {
            service.currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
            service.currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER))
        } catch (_: Exception) {}
    }

    private fun key(row: LinearLayout, label: String, weight: Float = 1f, backspace: Boolean = false, action: () -> Unit) {
        val b = Button(context).apply {
            text = label
            textSize = if (label == "SPACE") 13f else 15f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply { setColor(keyBg); cornerRadius = dp(9).toFloat() }
            stateListAnimator = null
            if (backspace) {
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            backspaceDeleting = false; backspaceBurstStarted = false
                            backspaceHandler.postDelayed({
                                if (!isAttachedToWindow) return@postDelayed
                                backspaceDeleting = true; backspaceBurstStarted = true
                                backspaceHandler.post(backspaceRunnable)
                            }, 350); true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            val burst = backspaceBurstStarted
                            backspaceDeleting = false; backspaceBurstStarted = false
                            if (e.actionMasked == MotionEvent.ACTION_UP && !burst) action()
                            true
                        }
                        else -> true
                    }
                }
            } else setOnClickListener { try { action() } catch (_: Exception) {} }
        }
        row.addView(b, LayoutParams(0, -1, weight).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDetachedFromWindow() {
        backspaceHandler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
