# ToracoKey dictionary and AI cleanup changes

This package keeps the app version at v0.48.0.

## Included
- `app/src/main/assets/toracokey_words.tsv.gz` now includes additional vocabulary extracted from the supplied Gboard dictionary's shortcut and answer columns. This feeds the existing local prefix/typo suggestion engine.
- `app/src/main/assets/gboard_shortcuts.tsv` preserves the supplied shortcut-to-answer mappings as UTF-8 TSV (shortcut<TAB>answer).
- `ToracoKeyService.kt` now strips `<think>...</think>`, `<analysis>...</analysis>`, and `<reasoning>...</reasoning>` blocks from AI answers before showing them.

## Important
The Gboard file is a shortcut/phrase mapping file, not a full dictionary with language-specific spelling/grammar metadata. The extra vocabulary improves word coverage, but the shortcut-to-answer mappings are preserved as an asset and are not yet auto-expanded while typing. That requires a deliberate expansion UX so normal phrases are not unexpectedly replaced.

Build and test this source project before installing it on a device.
