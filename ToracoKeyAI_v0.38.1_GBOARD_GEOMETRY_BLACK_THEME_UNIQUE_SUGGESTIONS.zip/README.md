# ToracoKey AI v0.38.1 — Gboard Geometry + Black Theme + Unique Suggestions

Based on the current v0.37.9 source.

Changes in this revision:
- reduced the lower keyboard tail from 48dp to 38dp so the keyboard content is shorter and bottom spacing is closer to the Gboard reference screenshot;
- preserved full-width invisible touch slots while keeping visible gaps between key graphics;
- added a Gboard-like dark adaptive vertical key palette: lighter upper rows and progressively darker lower rows;
- changed the suggestion strip to the lighter Gboard-style dark gray used in the reference screenshot;
- forced case-insensitive de-duplication of the three visible word suggestions;
- kept existing AI, voice, authorization, number/symbol pages and utility controls.
