package com.toracokey.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ActivityCompat
import java.util.Locale

/**
 * Transparent voice-recognition host.
 *
 * SpeechRecognizer is intentionally created here rather than inside the IME
 * service. Android is much more reliable about microphone permission and the
 * recognition lifecycle when an Activity owns the recognizer.
 */
class VoiceInputActivity : Activity() {
    companion object {
        const val ACTION_VOICE_RESULT = "com.toracokey.ai.VOICE_RESULT"
        const val EXTRA_TEXT = "text"
        const val EXTRA_ERROR = "error"
        private const val REQUEST_AUDIO = 7001
    }

    private var recognizer: SpeechRecognizer? = null
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecognition()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_AUDIO
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startRecognition()
        } else {
            sendResult("", "Microphone permission denied")
        }
    }

    private fun startRecognition() {
        if (finished) return

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendResult("", "Speech recognition is unavailable")
            return
        }

        try {
            recognizer?.destroy()
            recognizer = if (
                android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
            ) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }

            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    sendResult("", "Speech recognition error: $error")
                }

                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()

                    sendResult(text, if (text.isEmpty()) "No speech recognized" else "")
                }
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }

            recognizer?.startListening(intent)
        } catch (_: Exception) {
            sendResult("", "Unable to start speech recognition")
        }
    }

    private fun sendResult(text: String, error: String) {
        if (finished) return
        finished = true

        sendBroadcast(
            Intent(ACTION_VOICE_RESULT).apply {
                setPackage(packageName)
                putExtra(EXTRA_TEXT, text)
                putExtra(EXTRA_ERROR, error)
            }
        )

        try { recognizer?.stopListening() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        finish()
    }

    override fun onDestroy() {
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        super.onDestroy()
    }
}
