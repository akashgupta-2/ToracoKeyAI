package com.toracokey.ai

import android.content.Context
import android.util.Base64
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Local predictive typing engine.
 *
 * The important rule here is that the first three chips are WORD predictions,
 * not utility buttons. Predictions are local and never call the AI backend.
 */
object WordSuggestions {
    private const val ASSET_NAME = "toracokey_words.tsv.gz"
    private const val MAX_PERSONAL_WORDS = 8000
    private const val MAX_PERSONAL_PAIRS = 12000
    private const val MAX_PREFIX_SCAN = 5000
    private const val MAX_FUZZY_SCAN = 24000
    private const val FUZZY_MIN_LENGTH = 3
    private const val PERSONAL_WORD_WEIGHT = 20.0
    private const val PERSONAL_PAIR_WEIGHT = 28.0

    private data class Entry(val word: String, val frequency: Int)

    private var appContext: Context? = null
    @Volatile private var loaded = false
    @Volatile private var loading = false
    private var entries: List<Entry> = emptyList()
    private var topFrequencyWords: List<String> = emptyList()

    private val firstLetterBuckets = HashMap<Char, MutableList<Entry>>()
    private val lastLetterBuckets = HashMap<Char, MutableList<Entry>>()
    private val secondLetterBuckets = HashMap<Char, MutableList<Entry>>()

    private val personalWords = ConcurrentHashMap<String, Int>()
    private val personalPairs = ConcurrentHashMap<String, Int>()

    /* High-value completions for common abbreviated/partial typing. */
    private val commonCompletions = mapOf(
        "cong" to listOf("congratulations", "congratulate", "congress"),
        "ency" to listOf("encyclopedia", "encyclopaedia", "encyclopedic"),
        "def" to listOf("definitely", "definition", "different"),
        "prob" to listOf("probably", "problem", "problems"),
        "bec" to listOf("because", "become", "became"),
        "tom" to listOf("tomorrow", "tomato", "together"),
        "thx" to listOf("thanks", "thank", "thankful"),
        "pls" to listOf("please", "please", "pleasant"),
        "msg" to listOf("message", "messages", "messaging"),
        "info" to listOf("information", "inform", "informative"),
        "gov" to listOf("government", "governor", "governments"),
        "app" to listOf("application", "apple", "applications"),
        "exam" to listOf("example", "examine", "examination"),
        "diff" to listOf("different", "difference", "difficult"),
        "som" to listOf("something", "sometimes", "someone"),
        "evry" to listOf("every", "everyone", "everything"),
        "eve" to listOf("evening", "every", "event"),
        "morn" to listOf("morning", "more", "normally"),
        "gud" to listOf("good", "guide", "guilty"),
        "goo" to listOf("good", "goodness", "goose"),
        "wha" to listOf("what", "whatever", "whatsoever"),
        "wher" to listOf("where", "wherever", "whether"),
        "whe" to listOf("when", "where", "what"),
        "how" to listOf("however", "howdy", "howsoever")
    )

    /* Compact local next-word model. Personal pairs are layered on top. */
    private val nextWords = mapOf(
        "i" to listOf("am", "will", "can", "have", "want", "need"),
        "you" to listOf("can", "will", "have", "are", "need", "want"),
        "we" to listOf("can", "will", "have", "are", "should", "need"),
        "they" to listOf("are", "have", "can", "will", "were", "want"),
        "he" to listOf("is", "was", "has", "will", "can", "did"),
        "she" to listOf("is", "was", "has", "will", "can", "did"),
        "it" to listOf("is", "was", "will", "can", "has", "does"),
        "this" to listOf("is", "was", "will", "can", "means", "time"),
        "that" to listOf("is", "was", "the", "you", "we", "can"),
        "what" to listOf("is", "are", "do", "does", "about", "happened"),
        "where" to listOf("is", "are", "can", "do", "did", "you"),
        "when" to listOf("is", "are", "will", "can", "did", "do"),
        "why" to listOf("is", "are", "do", "did", "was", "not"),
        "how" to listOf("are", "can", "do", "much", "many", "to"),
        "can" to listOf("you", "i", "we", "be", "help", "do"),
        "could" to listOf("you", "please", "i", "we", "be", "help"),
        "would" to listOf("you", "be", "like", "have", "rather", "want"),
        "should" to listOf("be", "have", "i", "we", "you", "do"),
        "please" to listOf("help", "send", "tell", "let", "make", "check"),
        "thank" to listOf("you", "you", "ful", "god", "goodness", "much"),
        "thanks" to listOf("for", "you", "a", "again", "very", "so"),
        "good" to listOf("morning", "night", "job", "idea", "luck", "one"),
        "morning" to listOf("everyone", "sir", "all", "too", "to", "and"),
        "night" to listOf("everyone", "good", "and", "too", "sleep", "see"),
        "the" to listOf("best", "same", "next", "first", "most", "new"),
        "a" to listOf("good", "new", "little", "few", "lot", "long"),
        "an" to listOf("example", "important", "easy", "interesting", "idea", "answer"),
        "and" to listOf("the", "i", "a", "you", "it", "we"),
        "but" to listOf("i", "the", "you", "it", "we", "this"),
        "or" to listOf("the", "a", "you", "i", "it", "this"),
        "not" to listOf("the", "a", "be", "to", "have", "for"),
        "never" to listOf("be", "been", "the", "again", "a", "to"),
        "always" to listOf("be", "have", "the", "and", "try", "use"),
        "first" to listOf("time", "of", "the", "one", "step", "day"),
        "last" to listOf("time", "night", "week", "year", "one", "day"),
        "next" to listOf("time", "step", "day", "week", "word", "one"),
        "same" to listOf("time", "thing", "as", "for", "way", "here"),
        "different" to listOf("from", "ways", "things", "types", "words", "people"),
        "typing" to listOf("this", "is", "a", "the", "on", "test"),
        "keyboard" to listOf("is", "for", "and", "the", "with", "on"),
        "voice" to listOf("typing", "input", "recognition", "is", "not", "working"),
        "input" to listOf("text", "field", "connection", "is", "from", "to"),
        "text" to listOf("and", "in", "the", "is", "for", "to"),
        "word" to listOf("suggestions", "is", "for", "and", "in", "the"),
        "words" to listOf("and", "are", "with", "for", "the", "that"),
        "suggestion" to listOf("is", "for", "the", "and", "to", "word"),
        "suggestions" to listOf("are", "for", "the", "and", "to", "word"),
        "answer" to listOf("is", "the", "to", "for", "and", "that"),
        "question" to listOf("is", "about", "and", "for", "the", "that"),
        "problem" to listOf("is", "with", "the", "and", "that", "for"),
        "because" to listOf("the", "i", "it", "you", "we", "they"),
        "if" to listOf("you", "it", "we", "the", "there", "i")
    )

    private val fallback = listOf(
        "the", "to", "and", "of", "in", "is", "that", "for", "it", "you",
        "with", "on", "this", "be", "are", "have", "can", "will", "your", "my"
    )

    fun initialize(context: Context) {
        appContext = context.applicationContext
        loadPersonalLearning()
        if (loaded || loading) return
        loading = true
        Thread {
            try { loadDictionary() } finally { loading = false }
        }.start()
    }

    fun suggest(text: String, limit: Int = 3): List<String> {
        if (limit <= 0) return emptyList()
        ensureLoadedSynchronouslyIfPossible()

        val trimmed = text.trimEnd()
        val trailingSpace = text.lastOrNull()?.isWhitespace() == true
        val words = tokenize(trimmed)

        if (trailingSpace || words.isEmpty() && text.isNotEmpty()) {
            return nextWordCandidates(words.lastOrNull(), limit)
        }

        val token = words.lastOrNull().orEmpty()
        if (token.isEmpty()) return nextWordCandidates(null, limit)

        val lower = token.lowercase(Locale.ROOT)
        val prefix = prefixCandidates(lower, limit * 5)
        val aliases = commonCompletions.entries
            .firstOrNull { lower.length >= 3 && lower.startsWith(it.key) }
            ?.value.orEmpty()

        val previous = words.dropLast(1).lastOrNull()
        val contextual = if (previous != null && lower.length <= 2) {
            nextWords[previous].orEmpty().filter { it.startsWith(lower) }
        } else emptyList()

        val fuzzy = if (lower.length >= FUZZY_MIN_LENGTH) fuzzyCandidates(lower) else emptyList()

        // If the typed word is already complete, never show the same word as
        // its own suggestion. Offer useful continuations/nearby words instead.
        val exact = lower
        val ranked = aliases + contextual + prefix + fuzzy
        val result = fill(ranked.filter { it != exact }, limit)

        if (result.size >= limit) return result

        val next = if (previous != null) nextWords[previous].orEmpty() else emptyList()
        return fill(result + next + nextWordCandidates(lower, limit * 2), limit)
    }

    fun learnFromText(text: String) {
        val words = tokenize(text)
        if (words.isEmpty()) return
        words.forEach { incrementBounded(personalWords, it, MAX_PERSONAL_WORDS) }
        for (i in 1 until words.size) {
            val pair = words[i - 1] + "\u0000" + words[i]
            incrementBounded(personalPairs, pair, MAX_PERSONAL_PAIRS)
        }
        savePersonalLearning()
    }

    fun learnSelection(contextText: String, selectedWord: String) {
        val word = selectedWord.trim().lowercase(Locale.ROOT)
        if (word.isEmpty() || !word.matches(Regex("[a-z]{2,64}"))) return
        incrementBounded(personalWords, word, MAX_PERSONAL_WORDS)
        val previous = tokenize(contextText).dropLast(1).lastOrNull()
        if (!previous.isNullOrEmpty()) {
            incrementBounded(personalPairs, previous + "\u0000" + word, MAX_PERSONAL_PAIRS)
        }
        savePersonalLearning()
    }

    private fun nextWordCandidates(previous: String?, limit: Int): List<String> {
        if (limit <= 0) return emptyList()

        val result = ArrayList<String>()
        if (!previous.isNullOrEmpty()) {
            val p = previous.lowercase(Locale.ROOT)
            val pairPrefix = "$p\u0000"

            // A word must be selected twice before personal-pair learning can
            // outrank the normal language model. This prevents one accidental
            // sentence from polluting all future suggestions.
            personalPairs.entries
                .asSequence()
                .filter { it.key.startsWith(pairPrefix) && it.value >= 2 }
                .sortedByDescending { it.value }
                .map { it.key.removePrefix(pairPrefix) }
                .forEach { result.add(it) }

            nextWords[p].orEmpty().forEach { result.add(it) }
        }

        // Personal words are useful only when they were actually selected by
        // the user several times; do not dump arbitrary learned words here.
        personalWords.entries
            .asSequence()
            .filter { it.value >= 3 }
            .sortedByDescending { it.value }
            .take(8)
            .map { it.key }
            .forEach { result.add(it) }

        result.addAll(fallback)
        return fill(result, limit)
    }

    private fun prefixCandidates(prefix: String, wanted: Int): List<String> {
        if (!loaded || prefix.isEmpty()) return emptyList()

        val start = lowerBound(prefix)
        val candidates = ArrayList<Pair<String, Double>>()
        var index = start
        var scanned = 0

        while (index < entries.size &&
            entries[index].word.startsWith(prefix) &&
            scanned < MAX_PREFIX_SCAN
        ) {
            val entry = entries[index]
            val personal = personalWords[entry.word] ?: 0
            val extraLength = max(0, entry.word.length - prefix.length)
            val lengthPenalty = when {
                prefix.length <= 3 -> extraLength * 1.10
                prefix.length <= 5 -> extraLength * 0.55
                else -> extraLength * 0.28
            }
            val score = baseScore(entry.frequency) +
                personal * PERSONAL_WORD_WEIGHT - lengthPenalty
            candidates.add(entry.word to score)
            index++
            scanned++
        }

        personalWords.entries
            .asSequence()
            .filter { it.key.startsWith(prefix) && it.value >= 1 }
            .forEach { item ->
                val extra = max(0, item.key.length - prefix.length)
                candidates.add(item.key to (item.value * PERSONAL_WORD_WEIGHT + 60.0 - extra * 0.4))
            }

        return candidates
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(wanted)
    }

    private fun fuzzyCandidates(token: String): List<String> {
        if (!loaded || token.length < FUZZY_MIN_LENGTH) return emptyList()

        val candidateSet = LinkedHashSet<Entry>()
        firstLetterBuckets[token.first()].orEmpty().forEach(candidateSet::add)
        lastLetterBuckets[token.last()].orEmpty().forEach(candidateSet::add)
        token.getOrNull(1)?.let { secondLetterBuckets[it].orEmpty().forEach(candidateSet::add) }

        // Add candidates from neighboring lengths/letters through frequency
        // buckets. This permits first-letter mistakes such as "thsi" -> "this".
        if (candidateSet.size < 4000) {
            entries.asSequence()
                .filter { abs(it.word.length - token.length) <= 1 }
                .take(7000)
                .forEach(candidateSet::add)
        }

        val minLength = max(2, token.length - 2)
        val maxLength = token.length + 2
        val cutoff = if (token.length <= 4) 2 else if (token.length <= 7) 3 else 3
        val candidates = ArrayList<Pair<String, Double>>()
        var scanned = 0

        for (entry in candidateSet) {
            if (scanned++ >= MAX_FUZZY_SCAN) break
            if (entry.word == token || entry.word.length !in minLength..maxLength) continue

            val distance = editDistance(token, entry.word, cutoff)
            if (distance > cutoff) continue

            val commonPrefix = commonPrefixLength(token, entry.word)
            val commonSuffix = commonSuffixLength(token, entry.word)
            val personal = personalWords[entry.word] ?: 0
            val score =
                -distance * 75.0 +
                commonPrefix * 7.0 +
                commonSuffix * 5.0 +
                baseScore(entry.frequency) +
                personal * PERSONAL_WORD_WEIGHT

            candidates.add(entry.word to score)
        }

        return candidates
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(10)
    }

    private fun baseScore(frequency: Int): Double = ln((frequency + 1).toDouble()) * 5.0

    private fun commonPrefixLength(a: String, b: String): Int {
        var n = 0
        while (n < a.length && n < b.length && a[n] == b[n]) n++
        return n
    }

    private fun commonSuffixLength(a: String, b: String): Int {
        var n = 0
        while (n < a.length && n < b.length && a[a.length - 1 - n] == b[b.length - 1 - n]) n++
        return n
    }

    private fun editDistance(a: String, b: String, cutoff: Int): Int {
        if (abs(a.length - b.length) > cutoff) return cutoff + 1
        if (a == b) return 0

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in a.indices) {
            current[0] = i + 1
            var rowMin = current[0]
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = min(
                    min(current[j] + 1, previous[j + 1] + 1),
                    previous[j] + cost
                )
                rowMin = min(rowMin, current[j + 1])
            }
            if (rowMin > cutoff) return cutoff + 1
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }

    private fun lowerBound(prefix: String): Int {
        var low = 0
        var high = entries.size
        while (low < high) {
            val mid = (low + high) ushr 1
            if (entries[mid].word < prefix) low = mid + 1 else high = mid
        }
        return low
    }

    private fun tokenize(text: String): List<String> =
        Regex("[A-Za-z]{1,64}")
            .findAll(text.lowercase(Locale.ROOT))
            .map { it.value }
            .toList()

    private fun fill(candidates: List<String>, limit: Int): List<String> {
        val result = LinkedHashSet<String>()
        for (candidate in candidates) {
            val clean = candidate.trim().lowercase(Locale.ROOT)
            if (clean.matches(Regex("[a-z]{2,64}"))) result.add(clean)
            if (result.size >= limit) break
        }
        return result.toList()
    }

    private fun loadDictionary() {
        val context = appContext ?: return
        try {
            val loadedEntries = ArrayList<Entry>(130_000)
            context.assets.open(ASSET_NAME).use { raw ->
                GZIPInputStream(raw).use { gzip ->
                    BufferedReader(InputStreamReader(gzip, Charsets.UTF_8), 64 * 1024).useLines { lines ->
                        lines.forEach { line ->
                            val tab = line.indexOf('\t')
                            if (tab <= 1) return@forEach
                            val word = line.substring(0, tab).trim().lowercase(Locale.ROOT)
                            val frequency = line.substring(tab + 1).toIntOrNull() ?: 1
                            if (word.matches(Regex("[a-z]{2,64}"))) {
                                loadedEntries.add(Entry(word, frequency))
                            }
                        }
                    }
                }
            }

            loadedEntries.sortBy { it.word }
            entries = loadedEntries
            topFrequencyWords = loadedEntries.sortedByDescending { it.frequency }.take(1000).map { it.word }

            firstLetterBuckets.clear()
            lastLetterBuckets.clear()
            secondLetterBuckets.clear()
            loadedEntries.forEach { entry ->
                firstLetterBuckets.getOrPut(entry.word.first()) { ArrayList() }.add(entry)
                lastLetterBuckets.getOrPut(entry.word.last()) { ArrayList() }.add(entry)
                entry.word.getOrNull(1)?.let { second ->
                    secondLetterBuckets.getOrPut(second) { ArrayList() }.add(entry)
                }
            }
            loaded = loadedEntries.isNotEmpty()
        } catch (_: Exception) {
            entries = emptyList()
            topFrequencyWords = emptyList()
            firstLetterBuckets.clear()
            lastLetterBuckets.clear()
            secondLetterBuckets.clear()
            loaded = false
        }
    }

    private fun ensureLoadedSynchronouslyIfPossible() {
        if (loaded || loading) return
        loading = true
        try { loadDictionary() } finally { loading = false }
    }

    private fun incrementBounded(map: ConcurrentHashMap<String, Int>, key: String, maxEntries: Int) {
        map.merge(key, 1) { old, one -> min(old + one, 100_000) }
        if (map.size > maxEntries) {
            val weakest = map.entries.minByOrNull { it.value }
            if (weakest != null) map.remove(weakest.key, weakest.value)
        }
    }

    private fun loadPersonalLearning() {
        val context = appContext ?: return
        try {
            val prefs = context.getSharedPreferences("toracokey_word_learning", Context.MODE_PRIVATE)
            decodeMap(prefs.getString("words", ""), personalWords)
            decodeMap(prefs.getString("pairs", ""), personalPairs)
        } catch (_: Exception) {}
    }

    private fun savePersonalLearning() {
        val context = appContext ?: return
        try {
            val prefs = context.getSharedPreferences("toracokey_word_learning", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("words", encodeMap(personalWords))
                .putString("pairs", encodeMap(personalPairs))
                .apply()
        } catch (_: Exception) {}
    }

    private fun encodeMap(map: Map<String, Int>): String =
        map.entries.joinToString("|") {
            Base64.encodeToString(it.key.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + ":" + it.value
        }

    private fun decodeMap(raw: String?, target: ConcurrentHashMap<String, Int>) {
        if (raw.isNullOrBlank()) return
        raw.split('|').forEach { item ->
            val split = item.lastIndexOf(':')
            if (split <= 0) return@forEach
            try {
                val key = String(Base64.decode(item.substring(0, split), Base64.NO_WRAP), Charsets.UTF_8)
                val value = item.substring(split + 1).toIntOrNull() ?: return@forEach
                target[key] = value
            } catch (_: Exception) {}
        }
    }
}
