# ToracoKey AI v0.2

Android IME starter for an AI-powered keyboard.

Includes:
- Android Input Method Service
- QWERTY keyboard
- Gboard-style Z-M row indentation
- Question detection
- Local demo answers
- Tap suggestion to insert answer
- Runtime initialization fix
- AndroidX
- Java/Kotlin JVM 17
