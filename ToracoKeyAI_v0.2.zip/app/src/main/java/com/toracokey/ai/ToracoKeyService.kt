package com.toracokey.ai

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class ToracoKeyService : InputMethodService() {

    private var answerView: TextView? = null

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 6, 6, 6)
        }

        val suggestion = TextView(this).apply {
            text = "ToracoKey AI • Type a question"
            textSize = 15f
            setPadding(12, 12, 12, 12)

            setOnClickListener {
                val answer = tag as? String
                if (!answer.isNullOrEmpty()) {
                    currentInputConnection?.commitText(answer, 1)
                }
            }
        }

        answerView = suggestion

        root.addView(
            suggestion,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                58
            )
        )

        val keyboard = QwertyKeyboard(this) { text ->
            val connection = currentInputConnection ?: return@QwertyKeyboard

            if (text == "\b") {
                connection.deleteSurroundingText(1, 0)
            } else {
                connection.commitText(text, 1)
            }

            updateQuestionDetection()
        }

        root.addView(
            keyboard,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)

        answerView?.apply {
            text = "ToracoKey AI • Type a question"
            tag = null
        }
    }

    private fun updateQuestionDetection() {
        val view = answerView ?: return
        val connection = currentInputConnection ?: return

        val text = connection
            .getTextBeforeCursor(300, 0)
            ?.toString()
            ?: ""

        val result = QuestionEngine.answer(text)

        if (result != null) {
            view.text = "✨ $result • Tap to insert"
            view.tag = result
        } else {
            view.text = "ToracoKey AI • Type a question"
            view.tag = null
        }
    }
}
