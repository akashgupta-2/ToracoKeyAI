# ToracoKey AI v0.37.9 — GBoard Geometry + Touch

This build is based on the current v0.37.8 source.

Changes are limited to keyboard geometry/touch behavior:
- increased keyboard row height to restore the reference vertical size;
- preserved visible gaps between key graphics;
- kept the full-width invisible touch slots so taps in/near visual gaps still activate the adjacent key;
- slightly increased the visual horizontal gap between key graphics;
- preserved existing suggestions, voice, authorization, AI, number/symbol pages, and utility controls.

GitHub Actions builds the project directly from the ZIP root and verifies the geometry source before compiling.
