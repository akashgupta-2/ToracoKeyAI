# ToracoKey AI v0.23

Android keyboard with seven Smart AI, clipboard, question-detection, and word-suggestion improvements.

## Included improvements
- Clipboard text is appended after the existing context.
- Detects "for what" and "in which" question starters.
- Detects "in what", "from where", "difference between", and "difference from".
- Detects the "thing is used to" construction.
- Trailing spaces do not restart the same AI question context.
- Word suggestions commit the selected word with a following space.
- Existing Smart AI, Rewrite, Explain, voice, calculator, modes, and clipboard features retained.
