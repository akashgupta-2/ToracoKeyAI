package com.toracokey.ai

object QuestionEngine {

    private val starters = setOf(
        "what", "why", "how", "when", "where", "who", "which",
        "whose", "whom", "can", "could", "will", "would", "should",
        "shall", "do", "does", "did", "is", "are", "am", "was",
        "were", "have", "has", "had", "define", "explain", "name",
        "tell", "give", "list"
    )

    private val phraseStarters = listOf(
        "for what",
        "in which",
        "in what",
        "from where",
        "difference between",
        "difference from"
    )

    fun isQuestion(text: String): Boolean {
        // Normalize trailing whitespace so "what is car" and
        // "what is car " are the same question context.
        val q = text.trim().lowercase()
        if (q.isEmpty()) return false

        // Explicit question mark.
        if (q.endsWith("?")) return true

        // Multi-word question starters.
        val matchingPhrase = phraseStarters.firstOrNull { phrase ->
            q == phrase || q.startsWith("$phrase ")
        }

        if (matchingPhrase != null) {
            return q.length > matchingPhrase.length
        }

        // "A thing is used to/as/for..." construction.
        // Examples: "car is used to transport people",
        // "car is used for transportation", "this device is used as a calculator".
        val usedToPattern = Regex(
            """\b[a-z][a-z0-9-]*(?:\s+[a-z][a-z0-9-]*){0,6}\s+(?:is|are|was|were)\s+used\s+(?:to|as|for)(?:\s|$)""",
            RegexOption.IGNORE_CASE
        )

        if (usedToPattern.containsMatchIn(q)) {
            return true
        }

        // Normal single-word question starters.
        val first = q
            .split(Regex("\\s+"), limit = 2)
            .firstOrNull()
            ?: return false

        if (first !in starters) return false

        // A single word such as "what" or "is" is not enough.
        return q.length > first.length
    }
}
