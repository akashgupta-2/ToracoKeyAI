package com.toracokey.ai

object WordSuggestions {
    private val commonWords = listOf(
        "the","and","you","that","this","for","with","are","was","have","from","they",
        "your","what","when","where","who","which","why","how","can","will","would",
        "could","should","there","their","about","into","more","some","than","then",
        "them","these","those","here","just","like","know","want","need","good","great",
        "also","only","very","really","because","been","being","were","has","had","does",
        "did","not","but","all","any","one","two","three","time","today","tomorrow",
        "people","thing","things","make","made","get","got","go","going","come","came",
        "see","look","take","give","keep","find","think","thought","say","said","tell",
        "use","used","work","working","help","helpful","please","thanks","thank","hello",
        "hey","yes","no","okay","right","sure","maybe","now","later","before","after",
        "first","last","next","new","old","same","different","best","better","well",
        "much","many","most","only","still","even","back","down","up","out","over",
        "under","again","always","never","sometimes","often","every","each","another",
        "while","during","without","through","between","around","against","before",
        "school","class","study","student","exam","question","answer","physics","chemistry",
        "maths","science","chapter","book","movie","song","game","phone","keyboard",
        "computer","car","train","plane","flight","airport","city","country","india",
        "world","year","day","night","morning","evening","family","friend","friends",
        "please","sorry","welcome","happy","love","want","need","can","may","might",
        "must","let","lets","put","try","trying","start","started","stop","open","close",
        "write","writing","read","reading","send","sent","come","coming","go","going",
        "call","called","message","messages","ask","asked","answer","answers","find",
        "found","show","shown","look","looks","looking","use","using","keep","kept",
        "leave","left","live","lives","run","running","move","moving","play","playing",
        "watch","watching","listen","listening","hear","heard","feel","felt","seem",
        "seems","be","being","am","is","are","was","were","do","does","did","has","have",
        "had","to","of","in","on","at","by","as","or","if","so","it","its","my","me",
        "we","us","our","he","him","his","she","her","they","them","i","a","an",
        "first","second","third","last","next","today","tomorrow","yesterday",
        "please","could","would","should","will","shall","might","maybe","probably",
        "actually","exactly","really","simply","quickly","slowly","correct","wrong",
        "true","false","safe","ready","available","possible","important","different",
        "easy","hard","simple","short","long","small","large","high","low","early",
        "late","fast","slow","right","left","inside","outside","near","far"
    ).distinct()

    private val nextWords = mapOf(
        "who" to listOf("is", "was", "are", "wrote", "made"),
        "what" to listOf("is", "are", "does", "do", "was"),
        "why" to listOf("is", "are", "does", "did", "was"),
        "how" to listOf("are", "do", "to", "can", "does"),
        "when" to listOf("is", "was", "are", "did", "will"),
        "where" to listOf("is", "are", "can", "does", "did"),
        "which" to listOf("is", "are", "one", "was", "do"),
        "i" to listOf("am", "have", "want", "need", "can"),
        "you" to listOf("are", "can", "have", "want", "need"),
        "we" to listOf("are", "can", "have", "will", "should"),
        "the" to listOf("best", "same", "first", "next", "last"),
        "is" to listOf("the", "a", "this", "it", "there"),
        "are" to listOf("the", "you", "they", "there", "we"),
        "can" to listOf("you", "be", "i", "we", "also"),
        "will" to listOf("be", "you", "have", "the", "it"),
        "would" to listOf("be", "you", "have", "like", "want"),
        "should" to listOf("be", "i", "you", "we", "have"),
        "do" to listOf("you", "i", "we", "they", "this"),
        "does" to listOf("it", "he", "she", "this", "that"),
        "did" to listOf("you", "he", "she", "they", "it")
    )

    fun suggest(text: String, limit: Int = 3): List<String> {
        val trimmed = text.trimEnd()
        if (trimmed.isEmpty()) return commonWords.take(limit)

        val hasTrailingSpace = text.lastOrNull()?.isWhitespace() == true
        val last = trimmed.split(Regex("\\s+")).last().lowercase()

        if (hasTrailingSpace) {
            return nextWords[last]?.take(limit) ?: commonWords.take(limit)
        }

        val prefix = last
        if (prefix.length < 1) return commonWords.take(limit)

        val completions = commonWords
            .filter { it.startsWith(prefix) && it != prefix }
            .take(limit)

        return if (completions.isNotEmpty()) {
            completions
        } else {
            nextWords[prefix]?.take(limit) ?: emptyList()
        }
    }
}
