# ToracoKey AI v0.38.7 — Gboard Geometry + Black/Grey Theme + Contextual Unique Suggestions

Based on the v0.38.2 Android project.

Changes in this revision:
- increased the visible keyboard row height to 66dp to move the key geometry closer to the Gboard reference;
- tightened key margins to reduce excessive gaps while preserving full-width touch slots;
- reduced the bottom black tail to 6dp so the empty area below the keyboard is minimized;
- reduced the spacebar weight so it is no longer excessively wide;
- changed the keyboard background to a clearly visible grey-at-top to pure-black-at-bottom gradient;
- changed the key palette to progressively darker grey toward the lower rows;
- increased the suggestion strip to 48dp and matched its grey-to-black treatment more closely;
- moved the Mode changer to the far-left/start of the suggestion strip;
- kept three visible word suggestions and case-insensitive de-duplication;
- added contextual next-word predictions such as `shorter -> i / than / now / version / one`;
- preserved existing AI, voice, authorization, number/symbol pages and utility controls.

Version: 0.38.7
Version code: 52


## v0.38.7 Geometry Alignment
- Increased letter-row height slightly to make the keyboard closer to the Gboard reference height.
- Fixed the third letter row so Z-M uses the same base key width as the A-L row instead of being stretched by its own row weight total.
- Kept Shift and Backspace as wider edge controls with small balancing side spacers.
- Kept Mode fixed at the far-left of the suggestion strip.
- Kept three local suggestions, typo correction, prefix completion, contextual next-word prediction, and personal learning.
- Updated app version and authorization User-Agent to 0.38.7.
