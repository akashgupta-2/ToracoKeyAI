package com.toracokey.ai

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.os.Handler
import android.os.Looper

class QwertyKeyboard(
    private val service: InputMethodService,
    private val getMode: () -> KeyboardMode,
    private val isAllowed: () -> Boolean,
    private val onKey: (String) -> Unit,
    private val onMode: () -> Unit
) : LinearLayout(service) {

    private val rowHeight = dp(66)
    private val keyboardBg = Color.BLACK
    private val keyBg = Color.rgb(70, 74, 79)
    private val keyText = Color.rgb(245, 245, 245)
    private var symbols = false
    private var secondarySymbols = false
    private var shift = false
    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false
    private var currentRowKind = 0

    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            onKey("\b")
            backspaceHandler.postDelayed(this, 55)
        }
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.TOP
        setPadding(dp(2), dp(2), dp(2), dp(2))
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.rgb(104, 107, 112),
                Color.rgb(78, 81, 86),
                Color.rgb(43, 45, 48),
                Color.BLACK
            )
        )
        rebuild()
    }

    private fun rebuild() {
        removeAllViews()
        if (symbols) {
            // Main number/symbol area: three full-width rows, 10 keys each.
            currentRowKind = 1
            addRow("1234567890", 0f)
            if (secondarySymbols) {
                currentRowKind = 1
                addKeyRow(listOf("[", "]", "{", "}", "\\", "|", "~", "^", "=", "_"))
                addRow("©™_`€£¥•°§", 0f)
            } else {
                currentRowKind = 1
                addRow("@#$%&*()-+", 0f)
                addKeyRow(listOf(",", "!", "?", "/", ":", ";", "\"", "=", "'", "..."))
            }
            addUtilityRow()
        } else {
            currentRowKind = 1
            addRow("qwertyuiop", 0f)
            currentRowKind = 2
            addRow("asdfghjkl", 0.45f)
            currentRowKind = 3
            addBottomLetterRow()
        }

        currentRowKind = 4
        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        key(bottom, if (symbols) "ABC" else "?123", 1f) {
            symbols = !symbols
            secondarySymbols = false
            shift = false
            rebuild()
        }
        key(bottom, "SPACE", 4.4f) { onKey(" ") }
        key(bottom, ".", 0.9f) { onKey(".") }
        key(bottom, "↵", 0.9f) { onEnter() }
        addView(bottom, LayoutParams(-1, rowHeight))
        // Gboard leaves a smaller black tail below the last key row.
        // Reducing this from the previous 48dp brings the visible keyboard
        // height/bottom spacing into line with the reference screenshot.
        addView(android.view.View(context), LayoutParams(-1, dp(6)))
    }

    private fun addUtilityRow() {
        currentRowKind = 4
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        // Preserve existing controls: symbol switcher, Date, Time, Backspace.
        key(row, "#=+", 1.15f) {
            secondarySymbols = !secondarySymbols
            rebuild()
        }
        key(row, "Date", 1.65f) { onKey("__TORACOKEY_INSERT_DATE__") }
        key(row, "Time", 1.65f) { onKey("__TORACOKEY_INSERT_TIME__") }
        key(row, "⌫", 1.15f, true) { onKey("\b") }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun addBottomLetterRow() {
        currentRowKind = 4
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        // Gboard-style third row: Shift/Caps and Backspace reach the
        // keyboard edges. Removing the old side spacers also gives Z-M
        // slightly more horizontal room.
        key(row, "⇧", 1.15f) {
            shift = !shift
            rebuild()
        }

        "zxcvbnm".forEach { c ->
            val label = if (shift) c.uppercaseChar().toString() else c.toString()
            key(row, label) { onKey(typeFor(label)) }
        }

        key(row, "⌫", 1.15f, true) { onKey("\b") }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun addRow(chars: String, sideWeight: Float, includeBackspace: Boolean = false) {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (sideWeight > 0f) row.addView(android.view.View(context), LayoutParams(0, -1, sideWeight))
        chars.forEach { c ->
            val label = if (!symbols && shift && c.isLetter()) c.uppercaseChar().toString() else c.toString()
            key(row, label) { onKey(typeFor(label)) }
        }
        if (includeBackspace) {
            key(row, "⌫", 1f, true) { onKey("\b") }
        } else if (symbols && (chars == ",!?/:;\"=" || chars == "©™_`€£¥")) {
            // Date takes the old punctuation-row backspace position.
            key(row, "Date", 1.7f) { onKey("__TORACOKEY_INSERT_DATE__") }
        } else if (sideWeight > 0f) {
            row.addView(android.view.View(context), LayoutParams(0, -1, sideWeight))
        }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun addKeyRow(labels: List<String>) {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        labels.forEach { label ->
            key(row, label) {
                if (label == "...") onKey("...") else onKey(typeFor(label))
            }
        }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun typeFor(label: String): String {
        // The service applies ReverseCalc-style special typing modes centrally.
        // The keyboard only emits the actual character pressed.
        return label
    }

    private fun onEnter() {
        if (!isAllowed()) return
        try {
            service.currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
            service.currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER))
        } catch (_: Exception) {}
    }

    private fun key(row: LinearLayout, label: String, weight: Float = 1f, backspace: Boolean = false, action: () -> Unit) {
        // Use a full-width touch slot for every key. The visible key keeps its
        // small gap/margin, while the invisible slot remains tappable across the
        // entire allocated width. This makes edge taps behave more like Gboard
        // instead of requiring the user to hit the visual center of the key.
        val slot = FrameLayout(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }

        val b = Button(context).apply {
            text = label
            textSize = if (label == "SPACE") 13f else 15f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply {
                val colors = when (label) {
                    "↵" -> intArrayOf(Color.rgb(126, 202, 196), Color.rgb(105, 184, 178))
                    "SPACE", "?123", ".", "⇧", "⌫", "ABC" -> when (currentRowKind) {
                        4 -> intArrayOf(Color.rgb(66, 68, 71), Color.rgb(45, 46, 48))
                        else -> intArrayOf(Color.rgb(84, 87, 92), Color.rgb(65, 68, 72))
                    }
                    else -> when (currentRowKind) {
                        // Gboard-like dark theme: neutral grey keys above,
                        // progressively deeper grey toward the black lower area.
                        1 -> intArrayOf(Color.rgb(112, 115, 120), Color.rgb(92, 95, 100))
                        2 -> intArrayOf(Color.rgb(98, 101, 106), Color.rgb(78, 81, 86))
                        3 -> intArrayOf(Color.rgb(82, 85, 90), Color.rgb(61, 64, 68))
                        else -> intArrayOf(Color.rgb(50, 52, 55), Color.rgb(31, 32, 34))
                    }
                }
                orientation = GradientDrawable.Orientation.TOP_BOTTOM
                setColors(colors)
                cornerRadius = dp(9).toFloat()
            }
            stateListAnimator = null
            // The wrapper owns the touch target; the Button is visual only.
            isClickable = false
            isFocusable = false
        }
        slot.addView(b, FrameLayout.LayoutParams(-1, -1).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })

        if (backspace) {
            slot.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        if (!isAllowed()) return@setOnTouchListener true
                        backspaceDeleting = false; backspaceBurstStarted = false
                        backspaceHandler.postDelayed({
                            if (!slot.isAttachedToWindow) return@postDelayed
                            backspaceDeleting = true; backspaceBurstStarted = true
                            backspaceHandler.post(backspaceRunnable)
                        }, 350); true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        backspaceHandler.removeCallbacksAndMessages(null)
                        val burst = backspaceBurstStarted
                        backspaceDeleting = false; backspaceBurstStarted = false
                        if (e.actionMasked == MotionEvent.ACTION_UP && !burst && isAllowed()) action()
                        true
                    }
                    else -> true
                }
            }
        } else {
            slot.setOnClickListener {
                if (!isAllowed()) return@setOnClickListener
                try { action() } catch (_: Exception) {}
            }
        }

        row.addView(slot, LayoutParams(0, -1, weight))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDetachedFromWindow() {
        backspaceHandler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
