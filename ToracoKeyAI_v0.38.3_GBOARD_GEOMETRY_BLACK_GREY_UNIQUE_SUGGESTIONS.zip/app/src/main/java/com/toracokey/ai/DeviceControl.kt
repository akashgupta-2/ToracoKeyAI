package com.toracokey.ai

import android.content.Context
import android.os.Build
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import org.json.JSONObject

/**
 * Remote installation authorization.
 *
 * The identifier is an app-generated UUID stored locally. It is not the
 * Android hardware ID, phone number, email, contacts, or typed text.
 */
class DeviceControl(private val context: Context) {
    companion object {
        // The current backend registers/checks an installation through this endpoint.
        const val CONTROL_URL = "https://toracokeyai-backend.onrender.com/device/register"
        private const val PREFS = "toracokey_device_control"
        private const val INSTALL_ID = "install_id"
        private const val STATUS = "status"
        private const val REGISTERED = "registered"
    }

    data class Result(val allowed: Boolean, val status: String, val message: String)

    fun getInstallId(): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(INSTALL_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val generated = UUID.randomUUID().toString()
        prefs.edit().putString(INSTALL_ID, generated).apply()
        return generated
    }

    /**
     * Local authorization is intentionally sticky. Once this installation has
     * been accepted by the backend, keyboard switches, service restarts and
     * Android process recreation must not make the user authorize again.
     * The only normal way to clear this state is an explicit local reset.
     */
    fun cachedAllowed(): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getBoolean(REGISTERED, false)
    }

    fun needsRegistration(): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return !prefs.getBoolean(REGISTERED, false)
    }

    fun clearAuthorization() {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(REGISTERED, false)
            .putString(STATUS, "pending")
            .apply()
    }

    fun check(): Result {
        // Never contact the authorization server again after the installation
        // has already been accepted. This prevents re-authorization when the
        // user switches keyboards/apps or Android recreates the IME service.
        if (cachedAllowed()) {
            return Result(true, "authorized", "Authorized")
        }

        var connection: HttpURLConnection? = null
        return try {
            val installId = getInstallId()
            val url = URL(CONTROL_URL)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 15_000
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "ToracoKeyAI/0.37.8")
            }

            // The current backend expects deviceId.
            val body = JSONObject()
                .put("deviceId", installId)
                .put("appVersion", "0.37.8")
                .put("androidVersion", Build.VERSION.RELEASE ?: "unknown")
                .put("sdk", Build.VERSION.SDK_INT)
                .put("deviceModel", Build.MODEL ?: "unknown")
                .toString()

            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()

            if (code !in 200..299) {
                return Result(false, "offline", "Authorization server unavailable")
            }

            val json = JSONObject(response)
            val status = json.optString("status", "pending")
            val allowed = json.optBoolean("allowed", false) || json.optBoolean("authorized", false)
            val message = json.optString("message", status)

            if (allowed) {
                // Once accepted, keep the local authorization permanently.
                // A later transient/pending response must not revoke it.
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(STATUS, "authorized")
                    .putBoolean(REGISTERED, true)
                    .apply()
                Result(true, "authorized", message.ifBlank { "Authorized" })
            } else {
                // Only an installation that has never been accepted remains
                // pending/blocked. An already accepted installation never gets
                // here because of the early cachedAllowed() return above.
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(STATUS, status)
                    .apply()
                Result(false, status, message)
            }
        } catch (_: Exception) {
            if (cachedAllowed()) {
                Result(true, "authorized_cached", "Authorized")
            } else {
                Result(false, "offline", "Connect to the internet to verify this installation")
            }
        } finally {
            connection?.disconnect()
        }
    }
}
