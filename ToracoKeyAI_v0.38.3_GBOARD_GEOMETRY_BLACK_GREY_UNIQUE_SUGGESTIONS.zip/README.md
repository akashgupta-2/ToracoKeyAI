# ToracoKey AI v0.38.3 — Gboard Geometry + Black/Grey Theme + Contextual Unique Suggestions

Based on the v0.38.2 Android project.

Changes in this revision:
- increased the visible keyboard row height to 66dp to move the key geometry closer to the Gboard reference;
- tightened key margins to reduce excessive gaps while preserving full-width touch slots;
- reduced the bottom black tail to 6dp so the empty area below the keyboard is minimized;
- reduced the spacebar weight so it is no longer excessively wide;
- changed the keyboard background to a clearly visible grey-at-top to pure-black-at-bottom gradient;
- changed the key palette to progressively darker grey toward the lower rows;
- increased the suggestion strip to 48dp and matched its grey-to-black treatment more closely;
- moved the Mode changer to the far-left/start of the suggestion strip;
- kept three visible word suggestions and case-insensitive de-duplication;
- added contextual next-word predictions such as `shorter -> i / than / now / version / one`;
- preserved existing AI, voice, authorization, number/symbol pages and utility controls.

Version: 0.38.3
Version code: 49
