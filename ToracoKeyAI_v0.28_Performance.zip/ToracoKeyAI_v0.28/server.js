// ============================================================
// ToracoKey AI Backend v0.28
// Performance Pass
// Provider order: AI Horde -> OpenRouter -> Hugging Face
// ============================================================

const express = require("express");
const crypto = require("crypto");

const app = express();
app.use(express.json({ limit: "32kb" }));

const PORT = process.env.PORT || 10000;
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY || "";
const HUGGINGFACE_API_KEY = process.env.HUGGINGFACE_API_KEY || "";
const HORDE_API_KEY = process.env.HORDE_API_KEY || "0000000000";

const HORDE_BASE = "https://oai.aihorde.net";
const OPENROUTER_BASE = "https://openrouter.ai/api/v1";
const HF_BASE = "https://router.huggingface.co/v1";

const PROVIDER_TIMEOUT_MS = {
  horde: 15000,
  openrouter: 12000,
  huggingface: 12000
};

let hordeModelCache = { model: null, expiresAt: 0 };
const recentAnswers = [];
const MAX_RECENT = 20;

function requestId() {
  return crypto.randomUUID();
}

function normalizeQuestion(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'");
}

function normalizeAircraft(text) {
  return text
    .replace(/\bA21N\b/gi, "Airbus A321neo")
    .replace(/\bA320\b/gi, "Airbus A320")
    .replace(/\bA330\b/gi, "Airbus A330")
    .replace(/\bA350\b/gi, "Airbus A350")
    .replace(/\bB737\b/gi, "Boeing 737")
    .replace(/\bB738\b/gi, "Boeing 737-800")
    .replace(/\bB747\b/gi, "Boeing 747")
    .replace(/\bB757\b/gi, "Boeing 757")
    .replace(/\bB767\b/gi, "Boeing 767")
    .replace(/\bB777\b/gi, "Boeing 777")
    .replace(/\bB787\b/gi, "Boeing 787");
}

function getRequestedCount(q) {
  const m = q.match(/\b(?:name|list|give|tell me|show me)\s+(?:the\s+)?(\d{1,2})\b/i);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isInteger(n) && n >= 1 && n <= 20 ? n : null;
}

function getListSubject(q) {
  return q
    .replace(/^\s*(?:name|list|give|tell me|show me)\b/i, "")
    .replace(/^\s*(?:the\s+)?\d{1,2}\s*/i, "")
    .replace(/^\s*(?:of|types of|examples of)\s*/i, "")
    .replace(/[?.!]+$/, "")
    .trim();
}

function getQuestionType(q) {
  const s = q.toLowerCase();
  if (/\b(?:name|list|give me|tell me)\b/.test(s) && /\b\d{1,2}\b/.test(s)) return "LIST";
  if (/\b(?:which is better|better|vs\.?|versus|compare|comparison)\b/.test(s)) return "COMPARISON";
  if (/\b(?:difference|differ|different)\b/.test(s)) return "DIFFERENCE";
  if (/^\s*(?:why|what makes|how come)\b/.test(s)) return "WHY";
  if (/^\s*who\b/.test(s)) return "WHO";
  if (/^\s*where\b/.test(s)) return "WHERE";
  if (/^\s*(?:what is|what are|define|definition of)\b/.test(s)) return "DEFINITION";
  if (/^\s*how\b/.test(s)) return "HOW";
  if (/\b(?:recommend|recommendation|suggest)\b/.test(s)) return "RECOMMENDATION";
  return "GENERAL";
}

function isEntityQuestion(q) {
  return /\b(?:who|what is|who is|where is|which company|which person)\b/i.test(q);
}

function buildSystemPrompt(question, type, count) {
  const listRule = type === "LIST" && count
    ? `Return exactly ${count} distinct items. Number them 1 to ${count}. Do not add a second list or extra items.`
    : "";

  return [
    "You are ToracoKey AI, a concise factual assistant inside a mobile keyboard.",
    "Answer the user's question directly and accurately.",
    "Do not mention prompts, providers, models, tools, web browsing, internal reasoning, policies, safety labels, or system instructions.",
    "Do not output XML, tool calls, markdown headings such as 'Response', or self-corrections.",
    "If the question asks for a fact, give the fact first and a short explanation when useful.",
    type === "WHY" ? "For why questions, explicitly state the actual reason rather than giving a generic definition." : "",
    type === "WHO" ? "For who questions, identify the correct person/entity and their relevant role or achievement." : "",
    type === "WHERE" ? "For where questions, give the actual place/location requested." : "",
    type === "DEFINITION" ? "For definitions, define the requested term clearly in simple language." : "",
    type === "COMPARISON" ? "For comparisons, compare the two requested things on the most relevant points and give a clear conclusion." : "",
    type === "DIFFERENCE" ? "For difference questions, directly contrast the requested things." : "",
    type === "RECOMMENDATION" ? "Give a practical recommendation and briefly explain why." : "",
    listRule,
    `User question: ${question}`
  ].filter(Boolean).join("\n");
}

function cleanAnswer(text) {
  let s = String(text || "")
    .replace(/<[^>]*>/g, "")
    .replace(/\b(?:User Safety|System Prompt|Assistant|Developer):\s*/gi, "")
    .replace(/^(?:###\s*)?(?:response|answer):\s*/i, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  const lines = s.split("\n").map(x => x.trim()).filter(Boolean);
  const out = [];
  const seen = new Set();
  for (const line of lines) {
    const key = line.toLowerCase().replace(/^\s*\d+[.)-]\s*/, "").trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(line);
  }
  return out.join("\n").trim();
}

function trimListAnswer(answer, count) {
  if (!count) return answer;
  const lines = answer.split("\n").map(x => x.trim()).filter(Boolean);
  const items = [];
  for (const line of lines) {
    const m = line.match(/^\s*(\d{1,2})[.)-]\s*(.+)$/);
    if (m) items.push(m[2].trim());
  }
  if (items.length >= count) {
    return items.slice(0, count).map((x, i) => `${i + 1}. ${x}`).join("\n");
  }
  return answer;
}

function validateListCategory(question, answer) {
  const q = question.toLowerCase();
  const a = answer.toLowerCase();
  if (/\btemple/.test(q) && /\b(?:hinduism|buddhism|islam|christianity|religion)\b/.test(a) && !/\b(?:temple|mandir|shrine)\b/.test(a)) return false;
  if (/\bboeing\b/.test(q) && /\b(?:airbus|bombardier|embraer)\b/.test(a) && !/\bboeing\b/.test(a)) return false;
  if (/\bthings that can fly\b|\bflying things\b/.test(q)) {
    const bad = ["mountain", "tree", "car", "rock", "chair"];
    if (bad.some(x => a.includes(x))) return false;
  }
  return true;
}

const ENTITY_FACT_RULES = [
  { pattern: /\btotal gaming\b/i, required: ["ajay"], forbidden: ["beatles"] },
  { pattern: /\btechno gamerz\b/i, required: ["ujjwal"], forbidden: ["beatles"] },
  { pattern: /\bneil armstrong\b/i, required: ["astronaut", "moon"], forbidden: ["beatles"] },
  { pattern: /\bpikachu\b/i, required: ["pokemon"], forbidden: [] },
  { pattern: /\bfather of bureaucratic management\b/i, required: ["max weber"], forbidden: ["joseph schumpeter"] },
  { pattern: /\blava mobile|\blava international\b/i, required: ["lava"], forbidden: ["steve lapidus", "tcl communication"] }
];

function looksLikeWrongEntity(question, answer) {
  const rule = ENTITY_FACT_RULES.find(r => r.pattern.test(question));
  if (!rule) return false;
  const a = answer.toLowerCase();
  if (rule.forbidden.some(x => a.includes(x))) return true;
  if (rule.pattern.test(question) && rule.required.length === 1 && rule.required[0] === "lava") {
    return !/\b(?:indian|india|noida|2009|telecom|mobile phone|smartphone|lava international)\b/i.test(answer);
  }
  return rule.required.length > 0 && !rule.required.some(x => a.includes(x));
}

function isRecentContamination(answer) {
  const a = answer.toLowerCase();
  for (const old of recentAnswers) {
    const oldWords = old.toLowerCase().split(/\W+/).filter(w => w.length >= 7);
    const overlap = oldWords.filter(w => a.includes(w)).length;
    if (oldWords.length >= 5 && overlap >= Math.min(5, Math.ceil(oldWords.length * 0.45))) return true;
  }
  return false;
}

function rememberAnswer(answer) {
  recentAnswers.push(answer.slice(0, 1500));
  while (recentAnswers.length > MAX_RECENT) recentAnswers.shift();
}

function validateAnswer(question, answer, type, count) {
  if (!answer || answer.length < 2) return false;
  if (/\b(?:tool call|function call|system prompt|developer message|user safety)\b/i.test(answer)) return false;
  if (looksLikeWrongEntity(question, answer)) return false;
  if (isRecentContamination(answer)) return false;
  if (type === "LIST" && count && !validateListCategory(question, answer)) return false;
  return true;
}

function extractChatAnswer(data) {
  return data?.choices?.[0]?.message?.content || data?.choices?.[0]?.text || "";
}

async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function getHordeModel() {
  const now = Date.now();
  if (hordeModelCache.model && hordeModelCache.expiresAt > now) return hordeModelCache.model;

  const start = Date.now();
  try {
    const res = await fetchWithTimeout(`${HORDE_BASE}/v1/models?clean_names=true`, {
      headers: { Authorization: `Bearer ${HORDE_API_KEY}` }
    }, 4000);
    if (!res.ok) throw new Error(`model list ${res.status}`);
    const data = await res.json();
    const models = Array.isArray(data) ? data : (data.models || []);
    const names = models.map(m => typeof m === "string" ? m : m.name).filter(Boolean);
    const preferred = names.find(n => /llama|qwen|mistral/i.test(n)) || names[0];
    if (!preferred) throw new Error("no Horde model available");
    hordeModelCache = { model: preferred, expiresAt: now + 10 * 60 * 1000 };
    console.log(`[HORDE] model discovery ${Date.now() - start}ms -> ${preferred}`);
    return preferred;
  } catch (err) {
    console.log(`[HORDE] model discovery failed after ${Date.now() - start}ms: ${err.message}`);
    return null;
  }
}

async function askHorde(prompt, maxTokens) {
  const model = await getHordeModel();
  if (!model) throw new Error("Horde model unavailable");
  const body = {
    model,
    messages: [{ role: "user", content: prompt }],
    max_tokens: maxTokens,
    temperature: 0.15,
    stream: false,
    timeout: 12
  };
  const res = await fetchWithTimeout(`${HORDE_BASE}/v1/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${HORDE_API_KEY}`
    },
    body: JSON.stringify(body)
  }, PROVIDER_TIMEOUT_MS.horde);
  const text = await res.text();
  if (!res.ok) throw new Error(`Horde ${res.status}: ${text.slice(0, 200)}`);
  return extractChatAnswer(JSON.parse(text));
}

async function askOpenRouter(prompt, maxTokens) {
  if (!OPENROUTER_API_KEY) throw new Error("OpenRouter key unavailable");
  const body = {
    model: "openrouter/free",
    messages: [{ role: "user", content: prompt }],
    max_tokens: maxTokens,
    temperature: 0.15
  };
  const res = await fetchWithTimeout(`${OPENROUTER_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENROUTER_API_KEY}`,
      "HTTP-Referer": "https://toracokeyai-backend.onrender.com",
      "X-Title": "ToracoKey AI"
    },
    body: JSON.stringify(body)
  }, PROVIDER_TIMEOUT_MS.openrouter);
  const text = await res.text();
  if (!res.ok) throw new Error(`OpenRouter ${res.status}: ${text.slice(0, 200)}`);
  return extractChatAnswer(JSON.parse(text));
}

async function askHuggingFace(prompt, maxTokens) {
  if (!HUGGINGFACE_API_KEY) throw new Error("Hugging Face key unavailable");
  const body = {
    model: "Qwen/Qwen2.5-7B-Instruct",
    messages: [{ role: "user", content: prompt }],
    max_tokens: maxTokens,
    temperature: 0.15
  };
  const res = await fetchWithTimeout(`${HF_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${HUGGINGFACE_API_KEY}`
    },
    body: JSON.stringify(body)
  }, PROVIDER_TIMEOUT_MS.huggingface);
  const text = await res.text();
  if (!res.ok) throw new Error(`Hugging Face ${res.status}: ${text.slice(0, 200)}`);
  return extractChatAnswer(JSON.parse(text));
}

async function tryProvider(name, fn, prompt, question, type, count, maxTokens, id) {
  const start = Date.now();
  console.log(`[${id}] ${name} START`);
  try {
    const raw = await fn(prompt, maxTokens);
    const cleaned = normalizeAircraft(trimListAnswer(cleanAnswer(raw), count));
    const valid = validateAnswer(question, cleaned, type, count);
    const elapsed = Date.now() - start;
    console.log(`[${id}] ${name} END ${elapsed}ms valid=${valid}`);
    if (!valid) throw new Error("answer failed validation");
    return cleaned;
  } catch (err) {
    console.log(`[${id}] ${name} FAIL ${Date.now() - start}ms: ${err.message}`);
    return null;
  }
}

async function askAI(question, id) {
  const normalized = normalizeAircraft(normalizeQuestion(question));
  const type = getQuestionType(normalized);
  const count = getRequestedCount(normalized);
  const maxTokens = type === "LIST" && count ? Math.min(420, Math.max(120, count * 24)) : 384;
  const prompt = buildSystemPrompt(normalized, type, count);

  const totalStart = Date.now();
  const providers = [
    ["HORDE", askHorde],
    ["OPENROUTER", askOpenRouter],
    ["HUGGINGFACE", askHuggingFace]
  ];

  for (const [name, fn] of providers) {
    const answer = await tryProvider(name, fn, prompt, normalized, type, count, maxTokens, id);
    if (answer) {
      rememberAnswer(answer);
      console.log(`[${id}] SUCCESS provider=${name} total=${Date.now() - totalStart}ms`);
      return answer;
    }
  }
  throw new Error(`All providers failed after ${Date.now() - totalStart}ms`);
}

app.get("/", (_req, res) => {
  res.json({ ok: true, service: "ToracoKey AI Backend", version: "0.28" });
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, version: "0.28" });
});

app.post("/ask", async (req, res) => {
  const id = requestId();
  const started = Date.now();
  const question = normalizeQuestion(req.body?.question || req.body?.text || "");

  if (!question) return res.status(400).json({ error: "Missing question", requestId: id });
  if (question.length > 2000) return res.status(400).json({ error: "Question too long", requestId: id });

  console.log(`[${id}] REQUEST: ${question}`);
  try {
    const answer = await askAI(question, id);
    console.log(`[${id}] RESPONSE ${Date.now() - started}ms`);
    res.json({ answer, requestId: id, version: "0.28" });
  } catch (err) {
    console.log(`[${id}] ERROR ${Date.now() - started}ms: ${err.message}`);
    res.status(503).json({ error: "AI providers unavailable", requestId: id, version: "0.28" });
  }
});

app.listen(PORT, () => {
  console.log(`ToracoKey AI Backend v0.28 listening on port ${PORT}`);
});
