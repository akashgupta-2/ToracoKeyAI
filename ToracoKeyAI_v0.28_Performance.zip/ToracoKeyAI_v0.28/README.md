# ToracoKey AI Backend v0.28

Performance-focused backend for ToracoKey AI.

Provider order:
1. AI Horde
2. OpenRouter
3. Hugging Face

Performance changes:
- Hard request timeouts per provider
- One attempt per provider
- Cached Horde model discovery for 10 minutes
- Provider start/end timing logs
- Fast fallback between providers
- Existing list/entity/contamination validation retained
- CommonJS package configuration compatible with Render

Render start command:
`node server.js`
