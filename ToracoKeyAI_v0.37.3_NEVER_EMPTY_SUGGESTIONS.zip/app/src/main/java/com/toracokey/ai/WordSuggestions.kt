package com.toracokey.ai

/**
 * Fast, fully local keyboard suggestions.
 *
 * Important behavior:
 * - The suggestion strip should never intentionally become empty.
 * - While a word is being typed, show completions.
 * - Once a word is complete, immediately show next-word predictions.
 * - If there is no exact context prediction, fall back to broader
 *   next-word candidates instead of returning an empty list.
 * - No network or AI request is used for normal suggestions.
 */
object WordSuggestions {
    private val commonWords = listOf(
        "the","and","you","that","this","for","with","are","was","have","from","they",
        "your","what","when","where","who","which","why","how","can","will","would",
        "could","should","there","their","about","into","more","some","than","then",
        "them","these","those","here","just","like","know","want","need","good","great",
        "also","only","very","really","because","been","being","were","has","had","does",
        "did","not","but","all","any","one","two","three","time","today","tomorrow",
        "people","thing","things","make","made","get","got","go","going","come","came",
        "see","look","take","give","keep","find","think","thought","say","said","tell",
        "use","used","work","working","help","helpful","please","thanks","thank","hello",
        "hey","yes","no","okay","right","sure","maybe","now","later","before","after",
        "first","last","next","new","old","same","different","best","better","well",
        "much","many","most","still","even","back","down","up","out","over",
        "under","again","always","never","sometimes","often","every","each","another",
        "while","during","without","through","between","around","against","school","class",
        "study","student","exam","question","answer","physics","chemistry","maths","science",
        "chapter","book","movie","song","game","phone","keyboard","computer","car","train",
        "plane","flight","airport","city","country","india","world","year","day","night",
        "morning","evening","family","friend","friends","sorry","welcome","happy","love",
        "may","might","must","let","lets","put","try","trying","start","started","stop",
        "open","close","write","writing","read","reading","send","sent","call","called",
        "message","messages","ask","asked","answers","found","show","shown","looks","looking",
        "using","kept","leave","left","live","lives","run","running","move","moving","play",
        "playing","watch","watching","listen","listening","hear","heard","feel","felt","seem",
        "seems","be","am","is","do","of","in","on","at","by","as","or","if","so","it",
        "its","my","me","we","us","our","he","him","his","she","her","i","a","an",
        "second","third","yesterday","shall","probably","actually","exactly","simply","quickly",
        "slowly","correct","wrong","true","false","safe","ready","available","possible",
        "important","easy","hard","simple","short","long","small","large","high","low","early",
        "late","fast","slow","left","inside","outside","near","far"
    ).distinct()

    /**
     * Strong context predictions for common words.
     */
    private val nextWords = mapOf(
        "who" to listOf("is", "was", "are", "wrote", "made"),
        "what" to listOf("is", "are", "does", "do", "was"),
        "why" to listOf("is", "are", "does", "did", "was"),
        "how" to listOf("are", "do", "to", "can", "does"),
        "when" to listOf("is", "was", "are", "did", "will"),
        "where" to listOf("is", "are", "can", "does", "did"),
        "which" to listOf("is", "are", "one", "was", "do"),
        "i" to listOf("am", "have", "want", "need", "can"),
        "you" to listOf("are", "can", "have", "want", "need"),
        "we" to listOf("are", "can", "have", "will", "should"),
        "the" to listOf("best", "same", "first", "next", "last"),
        "is" to listOf("the", "a", "this", "it", "there"),
        "are" to listOf("the", "you", "they", "there", "we"),
        "can" to listOf("you", "be", "i", "we", "also"),
        "will" to listOf("be", "you", "have", "the", "it"),
        "would" to listOf("be", "you", "have", "like", "want"),
        "should" to listOf("be", "i", "you", "we", "have"),
        "do" to listOf("you", "i", "we", "they", "this"),
        "does" to listOf("it", "he", "she", "this", "that"),
        "did" to listOf("you", "he", "she", "they", "it"),
        "am" to listOf("going", "doing", "trying", "looking", "ready"),
        "have" to listOf("to", "been", "a", "the", "some"),
        "has" to listOf("been", "the", "a", "to", "not"),
        "had" to listOf("a", "the", "been", "to", "already"),
        "want" to listOf("to", "a", "the", "you", "more"),
        "need" to listOf("to", "a", "the", "some", "more"),
        "like" to listOf("to", "the", "this", "that", "it"),
        "going" to listOf("to", "the", "home", "there", "back"),
        "come" to listOf("to", "here", "back", "with", "and"),
        "coming" to listOf("to", "the", "back", "here", "with"),
        "go" to listOf("to", "the", "home", "there", "back"),
        "got" to listOf("to", "the", "a", "it", "this"),
        "get" to listOf("the", "a", "to", "it", "some"),
        "make" to listOf("it", "a", "the", "sure", "this"),
        "made" to listOf("a", "the", "it", "this", "sure"),
        "please" to listOf("help", "send", "tell", "let", "make"),
        "thank" to listOf("you", "you!", "you.", "you,", "everyone"),
        "hello" to listOf("there", "everyone", "again", "world", "friend"),
        "hey" to listOf("there", "everyone", "you", "what", "how"),
        "good" to listOf("morning", "afternoon", "evening", "job", "idea"),
        "very" to listOf("good", "well", "important", "easy", "different"),
        "really" to listOf("good", "want", "need", "like", "know"),
        "what's" to listOf("the", "your", "this", "that", "going"),
        "can" to listOf("you", "i", "we", "also", "be")
    )

    /**
     * Broader fallback predictions. These are deliberately different from
     * the alphabetical/common-word list so a completed word still produces
     * useful-looking next-word suggestions.
     */
    private val fallbackNextWords = listOf(
        "the", "a", "to", "and", "is", "it", "this", "that", "you", "your",
        "my", "me", "for", "with", "in", "on", "of", "can", "will", "have",
        "want", "need", "more", "some", "also", "just", "now", "then", "there", "here"
    )

    /**
     * Returns suggestions that are always populated when limit > 0.
     *
     * The algorithm deliberately treats an already-complete word differently
     * from a partial word: complete words trigger next-word prediction instead
     * of waiting for another space or returning an empty list.
     */
    fun suggest(text: String, limit: Int = 3): List<String> {
        if (limit <= 0) return emptyList()

        val trimmed = text.trimEnd()
        if (trimmed.isEmpty()) {
            return fillSuggestions(emptyList(), limit)
        }

        val hasTrailingSpace = text.lastOrNull()?.isWhitespace() == true
        val words = trimmed.split(Regex("\\s+")).filter { it.isNotBlank() }
        val last = words.lastOrNull()?.lowercase().orEmpty()

        // After a space, predict the next word from the completed context.
        if (hasTrailingSpace) {
            val context = nextWords[last].orEmpty()
            return fillSuggestions(context, limit)
        }

        // While the current word is being typed, show completions first.
        val completions = commonWords
            .asSequence()
            .filter { it.startsWith(last) && it != last }
            .take(limit)
            .toList()

        // If the current token is already a complete word, do NOT stop.
        // Immediately continue with next-word predictions.
        if (commonWords.contains(last)) {
            return fillSuggestions(
                nextWords[last].orEmpty() + fallbackForContext(words),
                limit
            )
        }

        // Partial word: completions are primary, but fill any remaining
        // slots with context/fallback suggestions so the strip never empties.
        if (completions.isNotEmpty()) {
            return fillSuggestions(
                completions + nextWords[last].orEmpty() + fallbackForContext(words),
                limit
            )
        }

        // Unknown/long token: still provide suggestions rather than stopping.
        return fillSuggestions(
            nextWords[last].orEmpty() + fallbackForContext(words),
            limit
        )
    }

    private fun fallbackForContext(words: List<String>): List<String> {
        if (words.size < 2) return fallbackNextWords

        val previous = words[words.lastIndex - 1].lowercase()
        return nextWords[previous].orEmpty() + fallbackNextWords
    }

    private fun fillSuggestions(candidates: List<String>, limit: Int): List<String> {
        val result = LinkedHashSet<String>()

        for (candidate in candidates) {
            val clean = candidate.trim()
            if (clean.isNotEmpty()) result.add(clean)
            if (result.size >= limit) return result.toList()
        }

        // Absolute last-resort fallback: this guarantees the strip does not
        // become empty merely because the current word/context is unknown.
        for (candidate in commonWords) {
            if (candidate.isNotBlank()) result.add(candidate)
            if (result.size >= limit) break
        }

        return result.take(limit)
    }
}
