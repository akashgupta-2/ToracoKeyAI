# ToracoKey AI v0.47.0 — Remote policy setup

This source retains the remote kill switch. Deploy the backend changes before distributing the v0.47.0 APK.

## Policy fields

- `typingEnabled`: disables all keyboard typing when `false`.
- `aiEnabled`: independently disables AI when `false`; it is forced to `false` whenever `typingEnabled` is `false`.
- `minimumAppVersion`: minimum allowed app version in `x.y.z` format. Older compatible clients receive HTTP 426 with the minimum version.
- `message`: administrator-facing status text returned to the app.

## 1. Install and mount the router

Copy `backend-policy-router.js` into the backend repository. Near the other imports in `server.js`, add:

```js
const {
  router: toracoPolicyRouter,
  loadPolicy: loadToracoPolicy
} = require('./backend-policy-router');
```

Mount the router after JSON body parsing and after any app-version middleware that must also gate `/device/policy`:

```js
app.use(toracoPolicyRouter);
```

Check the order in your real `server.js`; this ZIP does not contain the live backend's `server.js`, so mounting and route integration cannot be applied automatically here.

## 2. Configure the administrator token and durable storage

Set `TORACOKEY_ADMIN_TOKEN` in the hosting platform's secret/environment settings. Never commit the real token to GitHub or put it in an APK.

Set `TORACOKEY_POLICY_FILE` to a writable **persistent** path if your host's ordinary filesystem is ephemeral. The default is `toracokey-policy.json` in the backend working directory. If the file is lost, the router falls back to its default policy (typing and AI enabled), so durable storage and a tested recovery procedure are important.

## 3. Make version enforcement use the policy setting

In your existing minimum-version middleware, load the value dynamically:

```js
const minimumVersion = loadToracoPolicy().minimumAppVersion;
```

Use that value for the version comparison and include it in the HTTP 426 JSON response, for example:

```js
return res.status(426).json({
  ok: false,
  code: 'UPDATE_REQUIRED',
  minimumAppVersion: minimumVersion,
  error: `Update required: install ToracoKey AI ${minimumVersion} or newer`
});
```

Keep the backend's existing version-header validation and route protection. The Android app reads `minimumAppVersion` from this response to display the correct version.

## 4. Enforce AI shutdown on the server

At the beginning of each server-side AI route (including `/ask`), before provider requests or other AI work, enforce the policy:

```js
const policy = loadToracoPolicy();
if (!policy.typingEnabled || !policy.aiEnabled) {
  return res.status(503).json({
    ok: false,
    code: 'FEATURE_DISABLED',
    error: 'AI is disabled by the administrator'
  });
}
```

Apply equivalent enforcement to every other endpoint that can incur AI-provider costs or return AI output. A client-side switch alone is not sufficient to secure server-side AI use.

## 5. Admin controls

The examples below use a placeholder URL. Replace it with your deployed backend URL and keep the token secret.

Read current policy:

```bash
curl -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  https://YOUR-BACKEND/admin/policy
```

**Kill switch: disable both typing and AI**

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"typingEnabled":false,"aiEnabled":false,"message":"ToracoKey is temporarily disabled"}'
```

Re-enable typing but keep AI disabled:

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"typingEnabled":true,"aiEnabled":false,"message":"AI is temporarily disabled"}'
```

Re-enable both:

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"typingEnabled":true,"aiEnabled":true,"message":"ToracoKey is enabled"}'
```

Block older policy-aware app versions (example):

```bash
curl -X PATCH https://YOUR-BACKEND/admin/policy \
  -H "Content-Type: application/json" \
  -H "X-ToracoKey-Admin-Token: $TORACOKEY_ADMIN_TOKEN" \
  -d '{"minimumAppVersion":"0.46.0","message":"Please update ToracoKey AI"}'
```

Only raise the minimum version after the newer release is available. Existing APKs that do not implement the policy client cannot be remotely shut down by this mechanism.

## Operational limits and test checklist

- App policy refresh is approximately once per minute; changes are not guaranteed to take effect instantly.
- A cached policy can remain effective for up to five minutes during network failures; after cache expiry, the app fails closed.
- The version header is not cryptographic proof of APK identity and can be spoofed by a modified client.
- Confirm the host's filesystem persistence, restart the backend, and verify the policy remains unchanged.
- Test disable typing, disable AI only, re-enable both, minimum-version 426, offline/cache expiry, and the actual server-side `/ask` rejection.
- The router file is an integration component. Because the actual deployed backend `server.js` is not included in this Android ZIP, these integration steps must be performed and tested in the backend repository.
