# ToracoKey AI v0.6 — ReverseCalc Merge

ToracoKey AI keyboard with a Gboard-style dark layout, AI suggestion bar, calculator/percentage suggestions, emoji suggestions, symbols, shift, long-press backspace, and ReverseCalc-inspired text modes.

Modes: Normal, Reverse, Mono, Double, Alt Case, H H.

AI backend remains server-side at Render; no API key is stored in the APK.
