package com.toracokey.ai

enum class KeyboardMode {
    NORMAL, REVERSE, MONO, DOUBLE, ALT_CASE, SPACED_DOUBLE, HELLO
}
