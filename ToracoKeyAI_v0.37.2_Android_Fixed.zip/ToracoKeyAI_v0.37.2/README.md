# ToracoKey AI v0.37.2

Android keyboard project based on v0.37.1 with the authorization and GitHub Actions fixes.

## Changes in v0.37.2
- Device authorization now uses `POST /device/register`.
- The Android request sends `deviceId`, matching the current backend.
- Successful `allowed` authorization is cached correctly for the grace period.
- Keyboard authorization remains asynchronous so startup does not wait on the network.
- The 123/symbol face keeps the 3-row number layout with unique numbers.
- Clipboard and voice-input improvements from v0.37.1 are retained.
- GitHub Actions now builds the Android project directly from the repository root.
- The workflow no longer expects a nested ZIP file.

## Important
This ZIP is the **Android project only**.

Do not replace or redeploy the currently working backend from this ZIP. Keep the existing backend service unchanged.
