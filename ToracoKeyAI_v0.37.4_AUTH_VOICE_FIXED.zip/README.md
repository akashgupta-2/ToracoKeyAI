# ToracoKey AI v0.37.3

Android keyboard project.

## GitHub Actions

The repository root is the Android Gradle project root. The workflow in
`.github/workflows/build.yml` builds `:app:assembleDebug` and uploads the
resulting debug APK.

## Backend

The Android app uses the deployed ToracoKey AI backend. Backend source is not
included or changed in this Android package.


## Authorization behavior
- Device registration is performed only until the installation is authorized.
- Successful authorization is stored locally without an expiration timer.
- The Android keyboard no longer performs periodic authorization checks.


## v0.37.3 Infinite Suggestions
- Replaced the small hard-coded suggestion list with a large local English vocabulary.
- Added prefix completion for long and uncommon words.
- Added local fuzzy spelling correction for mistyped words.
- Added on-device personal word and word-pair learning so frequently used words rise in the suggestions.
- Normal suggestions never send typed text to the backend.
- The bundled vocabulary is generated from CMUdict vocabulary with TextBlob spelling-frequency data; the CMUdict source requests acknowledgement of Carnegie Mellon University.
