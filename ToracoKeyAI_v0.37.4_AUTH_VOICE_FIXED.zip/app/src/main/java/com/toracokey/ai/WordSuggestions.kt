package com.toracokey.ai

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream
import android.util.Base64
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Local predictive typing engine.
 *
 * Design goals:
 * - Large vocabulary instead of a small hard-coded commonWords list.
 * - Prefix completion for long/uncommon words.
 * - Fuzzy spelling correction for typing mistakes.
 * - Personal learning: words and word-pairs used by the user are ranked higher.
 * - Everything stays on-device; normal suggestions never call the AI backend.
 * - Always returns up to 3 useful suggestions instead of stopping at a valid word.
 */
object WordSuggestions {
    private const val ASSET_NAME = "toracokey_words.tsv.gz"
    private const val MAX_PERSONAL_WORDS = 4000
    private const val MAX_PERSONAL_PAIRS = 6000
    private const val MAX_PREFIX_SCAN = 2500
    private const val MAX_FUZZY_SCAN = 14000
    private const val FUZZY_MIN_LENGTH = 4
    private const val PERSONAL_WORD_WEIGHT = 18.0
    private const val PERSONAL_PAIR_WEIGHT = 24.0

    private data class Entry(
        val word: String,
        val frequency: Int
    )

    private var appContext: Context? = null
    @Volatile private var loaded = false
    @Volatile private var loading = false
    private var entries: List<Entry> = emptyList()
    private var topFrequencyWords: List<String> = emptyList()

    // Personal learning is deliberately kept local to the keyboard.
    private val personalWords = ConcurrentHashMap<String, Int>()
    private val personalPairs = ConcurrentHashMap<String, Int>()

    private val fallback = listOf(
        "the", "a", "to", "and", "is", "it", "this", "that", "you", "your",
        "my", "me", "for", "with", "in", "on", "of", "can", "will", "have",
        "want", "need", "more", "some", "also", "just", "now", "then", "there", "here"
    )

    /** Start loading the large local dictionary without blocking keyboard startup. */
    fun initialize(context: Context) {
        appContext = context.applicationContext
        loadPersonalLearning()
        if (loaded || loading) return
        loading = true
        Thread {
            try {
                loadDictionary()
            } finally {
                loading = false
            }
        }.start()
    }

    /**
     * Returns suggestions for the current editor text.
     * The current token is completed/corrected; after a completed token,
     * next-word predictions are used instead.
     */
    fun suggest(text: String, limit: Int = 3): List<String> {
        if (limit <= 0) return emptyList()
        ensureLoadedSynchronouslyIfPossible()

        val trimmed = text.trimEnd()
        if (trimmed.isEmpty()) return fill(fallback, limit)

        val trailingSpace = text.lastOrNull()?.isWhitespace() == true
        val words = tokenize(trimmed)
        val last = words.lastOrNull().orEmpty()
        if (last.isEmpty()) return fill(fallback, limit)

        if (trailingSpace) {
            return nextWordCandidates(words, limit)
        }

        val lower = last.lowercase(Locale.ROOT)
        val completions = prefixCandidates(lower, limit * 5)

        // If the user is still typing a prefix, completion/correction wins.
        if (lower.length < 3) {
            return fill(completions + nextWordCandidates(words, limit) + fallback, limit)
        }

        if (completions.isNotEmpty()) {
            // If the exact word is already present, keep next-word prediction
            // active rather than treating the strip as finished.
            val exact = completions.any { it.equals(lower, ignoreCase = true) }
            if (!exact || lower.length <= 3) {
                return fill(completions + fuzzyCandidates(lower) + nextWordCandidates(words, limit), limit)
            }

            return fill(
                nextWordCandidates(words, limit) +
                    completions.filterNot { it.equals(lower, true) } +
                    fuzzyCandidates(lower),
                limit
            )
        }

        // No prefix match: this is where typo recovery matters most.
        val fuzzy = if (lower.length >= FUZZY_MIN_LENGTH) fuzzyCandidates(lower) else emptyList()
        return fill(fuzzy + nextWordCandidates(words, limit) + fallback, limit)
    }

    /** Learn text typed/committed by the user. No text leaves the device. */
    fun learnFromText(text: String) {
        val words = tokenize(text)
        if (words.isEmpty()) return

        words.forEach { word ->
            incrementBounded(personalWords, word, MAX_PERSONAL_WORDS)
        }

        for (i in 1 until words.size) {
            val pair = words[i - 1] + "\u0000" + words[i]
            incrementBounded(personalPairs, pair, MAX_PERSONAL_PAIRS)
        }

        savePersonalLearning()
    }

    /** Learn a selected suggestion with the current context. */
    fun learnSelection(contextText: String, selectedWord: String) {
        val word = selectedWord.trim().lowercase(Locale.ROOT)
        if (word.isEmpty()) return
        incrementBounded(personalWords, word, MAX_PERSONAL_WORDS)

        val previous = tokenize(contextText).lastOrNull()
        if (!previous.isNullOrEmpty()) {
            incrementBounded(
                personalPairs,
                previous + "\u0000" + word,
                MAX_PERSONAL_PAIRS
            )
        }
        savePersonalLearning()
    }

    private fun nextWordCandidates(words: List<String>, limit: Int): List<String> {
        val previous = words.lastOrNull()?.lowercase(Locale.ROOT)
        if (previous.isNullOrEmpty()) return fill(fallback, limit)

        val pairPrefix = previous + "\u0000"
        val ranked = personalPairs.entries
            .asSequence()
            .filter { it.key.startsWith(pairPrefix) }
            .map { pair ->
                val word = pair.key.removePrefix(pairPrefix)
                word to (pair.value * PERSONAL_PAIR_WEIGHT + 60.0)
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .take(limit)
            .toList()

        // For words the user has not personally paired yet, use corpus frequency.
        val personalBroad = personalWords.entries
            .sortedByDescending { it.value }
            .map { it.key }
            .take(limit * 4)

        return fill(ranked + personalBroad + topFrequencyWords + fallback, limit)
    }

    private fun prefixCandidates(prefix: String, wanted: Int): List<String> {
        if (!loaded || entries.isEmpty() || prefix.isEmpty()) return emptyList()

        val start = lowerBound(prefix)
        val candidates = ArrayList<Pair<String, Double>>()
        var index = start
        var scanned = 0
        while (index < entries.size && entries[index].word.startsWith(prefix) && scanned < MAX_PREFIX_SCAN) {
            val entry = entries[index]
            val personal = personalWords[entry.word] ?: 0
            val exactBonus = if (entry.word == prefix) 8.0 else 0.0
            val lengthPenalty = max(0, entry.word.length - prefix.length) * 0.35
            val score = baseScore(entry.frequency) + personal * PERSONAL_WORD_WEIGHT + exactBonus - lengthPenalty
            candidates.add(entry.word to score)
            index++
            scanned++
        }

        personalWords.entries
            .asSequence()
            .filter { it.key.startsWith(prefix) }
            .forEach { item ->
                candidates.add(
                    item.key to (item.value * PERSONAL_WORD_WEIGHT + 60.0 - max(0, item.key.length - prefix.length) * 0.35)
                )
            }

        return candidates
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(wanted)
    }

    private fun fuzzyCandidates(token: String): List<String> {
        if (!loaded || entries.isEmpty()) return emptyList()

        val first = token.firstOrNull() ?: return emptyList()
        val minLength = max(2, token.length - 2)
        val maxLength = token.length + 2
        val candidates = ArrayList<Pair<String, Double>>()

        // The dictionary is alphabetical, so only inspect the first-letter range.
        var index = lowerBound(first.toString())
        var scanned = 0
        while (index < entries.size && scanned < MAX_FUZZY_SCAN) {
            val entry = entries[index]
            if (entry.word.firstOrNull() != first) break

            if (entry.word.length in minLength..maxLength && entry.word != token) {
                val distance = editDistance(token, entry.word, 3)
                if (distance <= 3) {
                    val personal = personalWords[entry.word] ?: 0
                    val score =
                        -distance * 45.0 +
                            baseScore(entry.frequency) +
                            personal * PERSONAL_WORD_WEIGHT
                    candidates.add(entry.word to score)
                }
            }

            index++
            scanned++
        }

        personalWords.entries
            .asSequence()
            .filter { item ->
                item.key != token &&
                    item.key.firstOrNull() == first &&
                    item.key.length in minLength..maxLength
            }
            .forEach { item ->
                val distance = editDistance(token, item.key, 3)
                if (distance <= 3) {
                    candidates.add(
                        item.key to (-distance * 45.0 + item.value * PERSONAL_WORD_WEIGHT + 60.0)
                    )
                }
            }

        return candidates
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(5)
    }

    private fun baseScore(frequency: Int): Double {
        // Frequency is only a ranking signal. Personal usage can override it.
        return kotlin.math.ln((frequency + 1).toDouble()) * 4.0
    }

    private fun editDistance(a: String, b: String, cutoff: Int): Int {
        if (abs(a.length - b.length) > cutoff) return cutoff + 1
        if (a == b) return 0

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in a.indices) {
            current[0] = i + 1
            var rowMin = current[0]

            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = min(
                    min(current[j] + 1, previous[j + 1] + 1),
                    previous[j] + cost
                )
                rowMin = min(rowMin, current[j + 1])
            }

            if (rowMin > cutoff) return cutoff + 1
            val swap = previous
            previous = current
            current = swap
        }

        return previous[b.length]
    }

    private fun lowerBound(prefix: String): Int {
        var low = 0
        var high = entries.size
        while (low < high) {
            val mid = (low + high) ushr 1
            if (entries[mid].word < prefix) low = mid + 1 else high = mid
        }
        return low
    }

    private fun tokenize(text: String): List<String> =
        Regex("[A-Za-z]{2,32}")
            .findAll(text.lowercase(Locale.ROOT))
            .map { it.value }
            .toList()

    private fun fill(candidates: List<String>, limit: Int): List<String> {
        val result = LinkedHashSet<String>()
        for (candidate in candidates) {
            val clean = candidate.trim().lowercase(Locale.ROOT)
            if (clean.matches(Regex("[a-z]{2,32}"))) result.add(clean)
            if (result.size >= limit) return result.toList()
        }
        return result.take(limit)
    }

    private fun loadDictionary() {
        val context = appContext ?: return
        try {
            val loadedEntries = ArrayList<Entry>(130_000)
            context.assets.open(ASSET_NAME).use { raw ->
                GZIPInputStream(raw).use { gzip ->
                    BufferedReader(InputStreamReader(gzip, Charsets.UTF_8), 64 * 1024).useLines { lines ->
                        lines.forEach { line ->
                            val tab = line.indexOf('\t')
                            if (tab <= 1) return@forEach
                            val word = line.substring(0, tab)
                            val frequency = line.substring(tab + 1).toIntOrNull() ?: 1
                            if (word.matches(Regex("[a-z]{2,32}"))) {
                                loadedEntries.add(Entry(word, frequency))
                            }
                        }
                    }
                }
            }

            loadedEntries.sortBy { it.word }
            entries = loadedEntries
            topFrequencyWords = loadedEntries
                .sortedByDescending { baseScore(it.frequency) }
                .take(500)
                .map { it.word }
            loaded = loadedEntries.isNotEmpty()
        } catch (_: Exception) {
            entries = emptyList()
            topFrequencyWords = emptyList()
            loaded = false
        }
    }

    private fun ensureLoadedSynchronouslyIfPossible() {
        if (loaded || loading) return
        loading = true
        try {
            loadDictionary()
        } finally {
            loading = false
        }
    }

    private fun incrementBounded(map: ConcurrentHashMap<String, Int>, key: String, maxEntries: Int) {
        map.merge(key, 1) { old, one -> min(old + one, 100_000) }
        if (map.size > maxEntries) {
            // Cheap bounded cleanup: remove one low-count entry rather than
            // allowing personal learning to grow without limit.
            val weakest = map.entries.minByOrNull { it.value }
            if (weakest != null) map.remove(weakest.key, weakest.value)
        }
    }

    private fun loadPersonalLearning() {
        val context = appContext ?: return
        try {
            val prefs = context.getSharedPreferences("toracokey_word_learning", Context.MODE_PRIVATE)
            decodeMap(prefs.getString("words", ""), personalWords)
            decodeMap(prefs.getString("pairs", ""), personalPairs)
        } catch (_: Exception) {}
    }

    private fun savePersonalLearning() {
        val context = appContext ?: return
        try {
            val prefs = context.getSharedPreferences("toracokey_word_learning", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("words", encodeMap(personalWords))
                .putString("pairs", encodeMap(personalPairs))
                .apply()
        } catch (_: Exception) {}
    }

    private fun encodeMap(map: Map<String, Int>): String =
        map.entries.joinToString("|") {
            Base64.encodeToString(it.key.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) + ":" + it.value
        }

    private fun decodeMap(raw: String?, target: ConcurrentHashMap<String, Int>) {
        if (raw.isNullOrBlank()) return
        raw.split('|').forEach { item ->
            val split = item.lastIndexOf(':')
            if (split <= 0) return@forEach
            try {
                val key = String(Base64.decode(item.substring(0, split), Base64.NO_WRAP), Charsets.UTF_8)
                val value = item.substring(split + 1).toIntOrNull() ?: return@forEach
                target[key] = value
            } catch (_: Exception) {}
        }
    }
}
