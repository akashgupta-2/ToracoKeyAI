# ToracoKey AI v0.48.1 — Local Access and Remote Kill Switch Update

**Android version:** `0.48.1`  
**Version code:** `60`  
**Minimum Android version:** Android 7.0 (API 24)  
**Build toolchain:** Java 17, Android SDK 35, Gradle 8.11.1

## Features included in this source

- Nine keyboard typing modes: Normal, Reverse, Mono, Double, Alt Case, Spaced Double, Hello, Vertical, and Stair.
- Server-controlled typing and AI feature switches through `GET /device/policy`.
- Protected administrator policy endpoint for disabling/re-enabling typing and AI, and changing the minimum supported app version.
- Fail-closed policy verification: a missing/expired policy disables typing and AI instead of silently allowing them.
- A policy cache valid for up to five minutes when the backend is temporarily unreachable; after expiry, controls fail closed.
- AI assistance and question detection, voice input, word suggestions, and the bundled compressed word list.
- Built-in arithmetic suggestions for expressions entered in the keyboard, including +, −, ×, ÷, percentages, brackets, decimals, and powers. Tap the `= result` suggestion to insert the answer.
- Wider Shift/Caps and Backspace touch keys, with the bottom-row letter columns kept aligned.

## Remote kill switch

The kill switch is retained. The administrator can independently disable AI or disable both typing and AI. Setting `typingEnabled` to `false` automatically forces `aiEnabled` to `false`.

The app refreshes policy approximately once per minute. A connected app applies the next policy refresh; do not assume an instantaneous response. If the backend is unreachable before the app has ever received a policy, typing and AI stay enabled instead of showing an authorization/connectivity block. If the app has received a policy before, it preserves the last known state while offline—including a disabled state. A remote change cannot reach an offline device until it reconnects.

The app's remote policy only controls app builds that implement it. Older APKs without policy enforcement cannot be remotely shut down by this feature. Server-side AI routes must also enforce the AI kill switch; client-side controls alone are not a security boundary.

## Build

The GitHub Actions workflow is `.github/workflows/build.yml`. It verifies the expected version, prints Kotlin compiler diagnostics, builds the debug APK, and uploads it as an Actions artifact.

Required build environment:

- JDK 17
- Android SDK platform 35 and build-tools 35.0.0
- Gradle 8.11.1

## Backend setup

See [`BACKEND_POLICY_SETUP.md`](BACKEND_POLICY_SETUP.md) before deploying the app. The backend must mount `backend-policy-router.js`, enforce the configured minimum version, enforce the AI switch on server-side AI routes, and persist the policy file on durable storage if settings must survive restarts/redeploys.

## Release note

This ZIP contains source code and workflow configuration, not a verified signed release APK. Run the workflow and test the APK and remote policy changes on a staging backend before distributing the build.
