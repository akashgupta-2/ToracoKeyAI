# Dictionary project review — v0.48.1

## Verified from source
- The compressed local dictionary contains 124,215 rows and 124,215 unique normalized words.
- The app has a prefix-completion/typo-correction engine in `WordSuggestions.kt`.
- The suggestion strip calls that engine and defensively removes case-insensitive duplicates.
- `gboard_shortcuts.tsv` contains 1,163 shortcut/answer mappings, but the current app does not expand these mappings while typing. They are stored as an asset only.

## Changes made in this package
- Fixed the GitHub Actions workflow so it builds the checked-out project directly instead of searching for an older ZIP that is not present.
- Added workflow checks for dictionary integrity, version consistency, and the expected dictionary deduplication code.
- Synchronized app `versionName` and backend app-version header to `0.48.1`; increased `versionCode` to `60`.

## Important limitation
This is a source-level correction, not a verified APK. The Android build has not been run in this environment. Run the GitHub Actions workflow and test suggestions on a device before treating the dictionary as fixed. Shortcut expansion remains unimplemented by design.
