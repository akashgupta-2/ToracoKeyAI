ToracoKey AI v0.22
Smart AI detection, clean AI responses, real word suggestions, AI Rewrite, AI Explain, and clipboard manager.
