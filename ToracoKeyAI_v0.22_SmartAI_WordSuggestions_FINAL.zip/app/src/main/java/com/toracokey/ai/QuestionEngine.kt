package com.toracokey.ai

object QuestionEngine {
    private val starters = setOf(
        "what", "why", "how", "when", "where", "who", "which",
        "whose", "whom", "can", "could", "will", "would", "should",
        "shall", "do", "does", "did", "is", "are", "am", "was",
        "were", "have", "has", "had", "define", "explain", "name",
        "tell", "give", "list"
    )

    fun isQuestion(text: String): Boolean {
        val q = text.trim().lowercase()
        if (q.isEmpty()) return false

        if (q.endsWith("?")) return true

        val first = q.split(Regex("\\s+"), limit = 2).firstOrNull() ?: return false
        if (first !in starters) return false

        // Avoid treating a single word such as "is" or "can" as a question.
        return q.length > first.length
    }
}
