package com.toracokey.ai

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout

class QwertyKeyboard(
    context: Context,
    private val onKey: (String) -> Unit
) : LinearLayout(context) {

    private val rowHeight = dp(54)

    init {
        orientation = VERTICAL
        setPadding(2, 2, 2, 2)

        addRow("qwertyuiop", 0)
        addRow("asdfghjkl", 1)
        addRow("zxcvbnm", 2)

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        val space = keyButton("space") {
            onKey(" ")
        }

        val delete = keyButton("⌫") {
            onKey("\b")
        }

        bottom.addView(
            space,
            LinearLayout.LayoutParams(0, rowHeight, 4f).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
        )

        bottom.addView(
            delete,
            LinearLayout.LayoutParams(0, rowHeight, 1f).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
        )

        addView(
            bottom,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                rowHeight
            )
        )
    }

    private fun addRow(text: String, index: Int) {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        if (index == 2) {
            row.setPadding(dp(28), 0, dp(28), 0)
        }

        text.forEach { character ->
            val key = keyButton(character.toString()) {
                onKey(character.toString())
            }

            row.addView(
                key,
                LinearLayout.LayoutParams(0, rowHeight, 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                }
            )
        }

        addView(
            row,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                rowHeight
            )
        )
    }

    private fun keyButton(label: String, action: () -> Unit): Button {
        return Button(context).apply {
            text = label
            textSize = 17f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(7).toFloat()
                setStroke(dp(1), Color.LTGRAY)
            }
            setOnClickListener { action() }
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
