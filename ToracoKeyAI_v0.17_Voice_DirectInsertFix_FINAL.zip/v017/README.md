ToracoKey AI v0.17

Features in this version:
- Gboard-style forgiving key touch targets
- Voice typing via Android speech recognition
- Automatic AI retry (up to 3 attempts) for transient failures
- Existing AI, calculator, emoji, and special typing modes preserved
