package com.toracokey.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.app.ActivityCompat

class VoiceInputActivity : Activity() {
    companion object {
        const val ACTION_VOICE_RESULT = "com.toracokey.ai.VOICE_RESULT"
        const val EXTRA_TEXT = "text"
        const val ACTION_VOICE_PERMISSION_GRANTED = "com.toracokey.ai.VOICE_PERMISSION_GRANTED"
        private const val REQUEST_AUDIO = 7001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            sendPermissionGranted()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_AUDIO && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            sendPermissionGranted()
        } else {
            finish()
        }
    }

    private fun sendPermissionGranted() {
        sendBroadcast(Intent(ACTION_VOICE_PERMISSION_GRANTED).setPackage(packageName))
        finish()
    }
}
