# ToracoKey AI v0.37.3

Android keyboard project.

## GitHub Actions

The repository root is the Android Gradle project root. The workflow in
`.github/workflows/build.yml` builds `:app:assembleDebug` and uploads the
resulting debug APK.

## Backend

The Android app uses the deployed ToracoKey AI backend. Backend source is not
included or changed in this Android package.
