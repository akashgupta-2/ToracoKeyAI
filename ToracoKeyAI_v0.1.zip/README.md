# ToracoKey AI — v0.1

Starter Android IME for an AI-powered keyboard.

## Current version
- Android Input Method Service
- QWERTY keyboard
- Third row has Gboard-style horizontal indentation
- Detects likely questions
- Shows a local demo answer in the suggestion strip
- Tapping the answer inserts it into the current app

## Next build
1. Replace local demo answers with an AI API.
2. Add web-search fallback for current/factual questions.
3. Add proper suggestion chips.
4. Add backspace, enter, shift, numbers and symbols.
5. Add ToracoKey settings.
6. Add secure API-key/server configuration.

Do not put a secret API key directly inside the APK. For production, use a secure backend or another protected authentication mechanism.
