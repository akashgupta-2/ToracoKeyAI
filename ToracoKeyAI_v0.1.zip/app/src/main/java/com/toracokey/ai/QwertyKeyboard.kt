package com.toracokey.ai

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout

class QwertyKeyboard(
    context: Context,
    private val onKey: (String) -> Unit
) : LinearLayout(context) {

    init {
        orientation = VERTICAL
        val rows = listOf(
            "qwertyuiop",
            "asdfghjkl",
            "zxcvbnm"
        )

        rows.forEachIndexed { index, row ->
            val line = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER
            }

            row.forEach { char ->
                val button = Button(context).apply {
                    text = char.toString()
                    textSize = 17f
                    setTextColor(Color.BLACK)
                    setOnClickListener { onKey(char.toString()) }
                }
                line.addView(button, LinearLayout.LayoutParams(0, 0, 1f))
            }

            // Gboard-style third row: centered/indented relative to the second row.
            if (index == 2) {
                line.setPadding(28, 0, 28, 0)
            }

            addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
        }

        val space = Button(context).apply {
            text = "space"
            setOnClickListener { onKey(" ") }
        }
        val delete = Button(context).apply {
            text = "⌫"
            setOnClickListener { onKey("\b") }
        }

        bottom.addView(space, LinearLayout.LayoutParams(0, 0, 4f))
        bottom.addView(delete, LinearLayout.LayoutParams(0, 0, 1f))
        addView(bottom, LinearLayout.LayoutParams(-1, 0, 1f))
    }
}
