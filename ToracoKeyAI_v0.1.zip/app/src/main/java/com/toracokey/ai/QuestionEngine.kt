package com.toracokey.ai

data class AnswerResult(val answer: String)

object QuestionEngine {

    private val questionWords = listOf(
        "what", "why", "how", "when", "where", "who",
        "which", "can", "is", "are", "define", "explain"
    )

    fun detect(text: String): AnswerResult? {
        val clean = text.trim()
        if (clean.isEmpty()) return null

        val lower = clean.lowercase()
        val looksLikeQuestion =
            lower.endsWith("?") ||
            questionWords.any { lower.startsWith("$it ") }

        if (!looksLikeQuestion) return null

        // Local demo answers. This will be replaced by the AI/search API.
        val answer = when {
            "coulomb" in lower ->
                "F = kq₁q₂/r² — electrostatic force between two point charges."
            "2+2" in lower ->
                "4"
            "photosynthesis" in lower ->
                "Plants use light energy to convert CO₂ and water into glucose and oxygen."
            else ->
                "Question detected. AI search connection will answer this."
        }

        return AnswerResult(answer)
    }
}
