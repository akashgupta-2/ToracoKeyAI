package com.toracokey.ai

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class ToracoKeyService : InputMethodService() {

    private lateinit var suggestions: TextView
    private lateinit var keyboard: LinearLayout

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 6, 6, 6)
        }

        suggestions = TextView(this).apply {
            text = "ToracoKey AI • Type a question"
            textSize = 15f
            setPadding(12, 12, 12, 12)
            setOnClickListener {
                val answer = tag as? String ?: return@setOnClickListener
                currentInputConnection.commitText(answer, 1)
            }
        }

        root.addView(
            suggestions,
            LinearLayout.LayoutParams(-1, 58)
        )

        keyboard = QwertyKeyboard(this) { text ->
            currentInputConnection.commitText(text, 1)
            updateQuestionDetection()
        }

        root.addView(
            keyboard,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        suggestions.text = "ToracoKey AI • Type a question"
        suggestions.tag = null
    }

    private fun updateQuestionDetection() {
        val before = currentInputConnection.getTextBeforeCursor(300, 0)?.toString() ?: ""
        val result = QuestionEngine.detect(before)

        if (result != null) {
            suggestions.text = "AI: ${result.answer}  • Tap to insert"
            suggestions.tag = result.answer
        } else {
            suggestions.text = "ToracoKey AI • Type a question"
            suggestions.tag = null
        }
    }
}
