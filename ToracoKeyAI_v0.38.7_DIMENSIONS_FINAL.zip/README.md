# ToracoKey AI v0.38.7 — Dimensions Final

This build changes keyboard geometry only, calibrated to the supplied 1080×2400 reference measurements.

## Geometry
- Total keyboard target: ~730 px
- Toolbar: ~120 px
- Letter/symbol rows: ~126 px
- Visible standard key: ~96 px
- Horizontal key gap: ~12 px
- Vertical row gap: ~12 px
- Bottom-row standard keys: same 96 px geometry
- Z–M row uses the same key size as S–K row
- Spacebar visible width: ~510 px
- Spacebar height: ~126 px

Authorization, suggestions, voice input, backend/provider logic, and the word list are not intentionally changed.
