# ToracoKey AI v0.37.1 — Remote User Control

## Android changes

- Anonymous installation UUID is generated locally and persisted.
- The keyboard checks authorization when it starts and every 15 minutes.
- New installations are authorized by default unless the backend uses `DEFAULT_DEVICE_STATUS=pending`.
- A blocked installation cannot type, delete, switch modes, use Time/Date, use calculator/suggestions, use clipboard insertion, use voice typing, or use AI actions.
- The backend also rejects `/ask` requests from blocked/pending installations.
- Offline behavior is conservative: a recently authorized installation has a 24-hour cached grace period; new/pending/blocked installations remain unavailable when authorization cannot be verified.

## Backend changes

`backend/server.js` provides:

- `POST /device/check` — register/check an installation.
- `POST /ask` — AI endpoint with server-side device authorization.
- `GET /admin` — administrator dashboard.
- `GET /admin/users` — list all registered installations.
- `GET /admin/stats` — counts by state.
- `POST /admin/users/:installId/authorize` — allow an installation.
- `POST /admin/users/:installId/pending` — hold an installation.
- `POST /admin/users/:installId/block` — block an installation.
- `DELETE /admin/users/:installId` — remove an installation record.

## Important deployment setting

The device registry is stored in a JSON file. Render's normal filesystem is not durable across service replacement/redeploys. For persistent user-control data, attach a Render persistent disk and set:

`DEVICE_DATA_FILE=/var/data/devices.json`

Set a strong `ADMIN_TOKEN` in Render environment variables. Never put the admin token inside the Android APK or GitHub repository.

The device ID is an anonymous installation UUID. This implementation deliberately does not collect typed text, contacts, phone numbers, email addresses, or exact location.


## v0.37.1 Improvements

- Voice typing re-captures the active editor connection when recognition actually starts, including after microphone permission is granted.
- Voice typing preserves the active typing mode and safely falls back to the current input connection if the earlier connection changed.
- Clipboard is refreshed when the keyboard opens and when Clipboard is opened, with more reliable clipboard history handling.
- Keyboard startup uses recent authorization cache immediately and prevents overlapping authorization checks, reducing intermittent opening stalls.
- Number/symbol face uses a unique three-row number area: 123 / 456 / 789, with 0 placed once in the utility row.
- AI backend request format remains compatible with the current ToracoKey backend by sending the installation ID.
- AI provider credentials remain server-side; no API key is stored in the Android app.
