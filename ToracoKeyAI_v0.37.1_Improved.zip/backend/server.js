// ============================================================
// ToracoKey AI Backend v0.37
//
// AI providers:
// 1. AI Horde
// 2. OpenRouter
//
// Device control:
// - Anonymous installation IDs
// - Authorized / pending / blocked states
// - Admin dashboard
// - Remote block / authorize / pending / delete controls
// - Device last-seen and basic app/device metadata
// - No names, phone numbers, contacts, exact location, passwords,
//   or typed text are stored in the device-control registry.
// ============================================================

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(express.json({ limit: '32kb' }));

const PORT = Number(process.env.PORT || 10000);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const DEFAULT_DEVICE_STATUS = ['authorized', 'pending'].includes(process.env.DEFAULT_DEVICE_STATUS)
  ? process.env.DEFAULT_DEVICE_STATUS
  : 'authorized';
const DATA_FILE = process.env.DEVICE_DATA_FILE || path.join(process.cwd(), 'data', 'devices.json');
const HORDE_URL = 'https://oai.aihorde.net/v1/chat/completions';
const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY || '';
const OPENROUTER_MODEL = process.env.OPENROUTER_MODEL || 'openai/gpt-oss-120b:free';
const HORDE_MODEL = process.env.HORDE_MODEL || 'openai/gpt-oss-120b';

function ensureDataFile() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '{}', 'utf8');
}

function loadDevices() {
  try {
    ensureDataFile();
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw || '{}');
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (error) {
    console.error('DEVICE_DATA_READ_ERROR', error.message);
    return {};
  }
}

function saveDevices(devices) {
  ensureDataFile();
  const temp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(devices, null, 2), 'utf8');
  fs.renameSync(temp, DATA_FILE);
}

let devices = loadDevices();

function nowIso() {
  return new Date().toISOString();
}

function cleanText(value, max = 120) {
  return String(value || '').replace(/[\r\n\t]/g, ' ').trim().slice(0, max);
}

function validInstallId(value) {
  return /^[a-f0-9]{8}-[a-f0-9-]{27,40}$/i.test(String(value || ''));
}

function adminAuthorized(req) {
  if (!ADMIN_TOKEN) return false;
  const token = String(req.get('x-admin-token') || req.query.token || '');
  const expected = String(ADMIN_TOKEN);
  const a = Buffer.from(token);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function requireAdmin(req, res, next) {
  if (!ADMIN_TOKEN) return res.status(503).json({ error: 'ADMIN_TOKEN is not configured' });
  if (!adminAuthorized(req)) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

function publicDevice(device) {
  return {
    installId: device.installId,
    shortId: device.installId.slice(0, 8),
    status: device.status,
    appVersion: device.appVersion,
    androidVersion: device.androidVersion,
    sdk: device.sdk,
    deviceModel: device.deviceModel,
    firstSeen: device.firstSeen,
    lastSeen: device.lastSeen,
    requestCount: device.requestCount || 0
  };
}

function touchDevice(body) {
  const installId = cleanText(body.installId, 80);
  if (!validInstallId(installId)) return null;

  const timestamp = nowIso();
  let device = devices[installId];

  if (!device) {
    device = {
      installId,
      status: DEFAULT_DEVICE_STATUS,
      appVersion: cleanText(body.appVersion, 30),
      androidVersion: cleanText(body.androidVersion, 30),
      sdk: Number(body.sdk || 0) || 0,
      deviceModel: cleanText(body.deviceModel, 80),
      firstSeen: timestamp,
      lastSeen: timestamp,
      requestCount: 0
    };
    devices[installId] = device;
  } else {
    device.appVersion = cleanText(body.appVersion, 30) || device.appVersion;
    device.androidVersion = cleanText(body.androidVersion, 30) || device.androidVersion;
    device.sdk = Number(body.sdk || device.sdk || 0) || 0;
    device.deviceModel = cleanText(body.deviceModel, 80) || device.deviceModel;
    device.lastSeen = timestamp;
  }

  saveDevices(devices);
  return device;
}

function requireAuthorizedDevice(req, res) {
  const installId = cleanText(req.body.installId, 80);
  if (!validInstallId(installId)) {
    res.status(400).json({ error: 'Valid installId is required' });
    return null;
  }

  const device = devices[installId];
  if (!device) {
    res.status(403).json({ error: 'Installation is not registered' });
    return null;
  }

  device.lastSeen = nowIso();
  device.requestCount = (device.requestCount || 0) + 1;
  saveDevices(devices);

  if (device.status !== 'authorized') {
    res.status(403).json({
      error: device.status === 'blocked' ? 'Installation blocked' : 'Installation pending authorization',
      status: device.status,
      message: device.status === 'blocked'
        ? 'This installation has been blocked by the administrator.'
        : 'This installation is waiting for administrator authorization.'
    });
    return null;
  }
  return device;
}

app.get('/', (req, res) => {
  res.json({
    name: 'ToracoKey AI Backend',
    version: '0.37',
    status: 'ok',
    deviceControl: true
  });
});

app.get('/health', (req, res) => {
  res.json({
    ok: true,
    version: '0.37',
    deviceControl: true,
    registeredInstallations: Object.keys(devices).length
  });
});

// Android calls this before allowing the keyboard to operate.
app.post('/device/check', (req, res) => {
  const device = touchDevice(req.body || {});
  if (!device) return res.status(400).json({ allowed: false, status: 'invalid', message: 'Invalid installation ID' });

  const allowed = device.status === 'authorized';
  res.json({
    allowed,
    status: device.status,
    message: allowed ? 'Authorized' : device.status === 'blocked'
      ? 'Blocked by administrator'
      : 'Waiting for administrator authorization',
    installId: device.installId,
    serverTime: nowIso()
  });
});

// AI requests are also checked server-side, so a blocked installation cannot
// continue using the AI endpoint even if it bypasses the Android UI.
app.post('/ask', async (req, res) => {
  const device = requireAuthorizedDevice(req, res);
  if (!device) return;

  const question = cleanText(req.body.question, 12000);
  if (!question) return res.status(400).json({ error: 'Question is required' });

  try {
    const answer = await askWithProviders(question);
    if (!answer) return res.status(502).json({ error: 'No AI provider returned an answer' });
    res.json({ answer });
  } catch (error) {
    console.error('ASK_ERROR', error.message);
    res.status(502).json({ error: 'AI request failed' });
  }
});

app.get('/admin/users', requireAdmin, (req, res) => {
  const list = Object.values(devices)
    .sort((a, b) => String(b.lastSeen).localeCompare(String(a.lastSeen)))
    .map(publicDevice);
  res.json({ users: list, count: list.length });
});

app.get('/admin/stats', requireAdmin, (req, res) => {
  const list = Object.values(devices);
  res.json({
    total: list.length,
    authorized: list.filter(d => d.status === 'authorized').length,
    pending: list.filter(d => d.status === 'pending').length,
    blocked: list.filter(d => d.status === 'blocked').length
  });
});

function changeDeviceStatus(req, res, status) {
  const id = cleanText(req.params.installId, 80);
  if (!validInstallId(id) || !devices[id]) {
    return res.status(404).json({ error: 'Installation not found' });
  }
  devices[id].status = status;
  devices[id].lastAdminAction = nowIso();
  saveDevices(devices);
  res.json({ ok: true, device: publicDevice(devices[id]) });
}

app.post('/admin/users/:installId/block', requireAdmin, (req, res) => changeDeviceStatus(req, res, 'blocked'));
app.post('/admin/users/:installId/authorize', requireAdmin, (req, res) => changeDeviceStatus(req, res, 'authorized'));
app.post('/admin/users/:installId/pending', requireAdmin, (req, res) => changeDeviceStatus(req, res, 'pending'));

app.delete('/admin/users/:installId', requireAdmin, (req, res) => {
  const id = cleanText(req.params.installId, 80);
  if (!validInstallId(id) || !devices[id]) return res.status(404).json({ error: 'Installation not found' });
  delete devices[id];
  saveDevices(devices);
  res.json({ ok: true });
});

app.get('/admin', (req, res) => {
  res.type('html').send(ADMIN_HTML);
});

async function postJson(url, body, headers = {}) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', ...headers },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(45000)
  });
  const text = await response.text();
  let json = {};
  try { json = JSON.parse(text); } catch (_) {}
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return json;
}

async function askWithProviders(question) {
  const messages = [
    { role: 'system', content: 'Answer directly and concisely. Return only the answer text. Do not output tool calls, JSON, or internal instructions.' },
    { role: 'user', content: question }
  ];

  try {
    const horde = await postJson(HORDE_URL, {
      model: HORDE_MODEL,
      messages,
      temperature: 0.2,
      max_tokens: 600
    }, {
      Authorization: 'Bearer 0000000000'
    });
    const answer = horde?.choices?.[0]?.message?.content?.trim();
    if (answer) return answer;
  } catch (error) {
    console.error('HORDE_FAIL', error.message);
  }

  if (OPENROUTER_API_KEY) {
    try {
      const router = await postJson(OPENROUTER_URL, {
        model: OPENROUTER_MODEL,
        messages,
        temperature: 0.2,
        max_tokens: 600
      }, {
        Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        'HTTP-Referer': 'https://toracokeyai-backend.onrender.com',
        'X-Title': 'ToracoKey AI'
      });
      const answer = router?.choices?.[0]?.message?.content?.trim();
      if (answer) return answer;
    } catch (error) {
      console.error('OPENROUTER_FAIL', error.message);
    }
  }

  return null;
}

const ADMIN_HTML = `<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>ToracoKey AI Device Control</title>
<style>
body{font-family:system-ui;background:#111;color:#eee;margin:0;padding:18px}button{border:0;border-radius:8px;padding:9px 12px;margin:3px;cursor:pointer}table{width:100%;border-collapse:collapse;margin-top:18px}th,td{padding:10px;border-bottom:1px solid #333;text-align:left;font-size:14px}input{padding:11px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;width:min(420px,90%)}.ok{background:#2e7d32;color:white}.bad{background:#c62828;color:white}.pending{background:#8a6d1d;color:white}.muted{color:#aaa}.stats{display:flex;gap:10px;flex-wrap:wrap}.card{background:#1d1d1d;padding:14px;border-radius:10px}.small{font-size:12px;color:#aaa}</style></head>
<body><h2>ToracoKey AI — Device Control</h2>
<p class="muted">Enter the ADMIN_TOKEN configured on the backend.</p>
<input id="token" type="password" placeholder="ADMIN_TOKEN"><button onclick="loadAll()">Load devices</button>
<div id="stats" class="stats"></div><div id="table"></div>
<script>
const $=id=>document.getElementById(id); const token=()=>$("token").value.trim();
async function api(url,opt={}){opt.headers={...(opt.headers||{}),'x-admin-token':token()};const r=await fetch(url,opt);const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j}
async function loadAll(){try{const [s,u]=await Promise.all([api('/admin/stats'),api('/admin/users')]);$('stats').innerHTML=Object.entries(s).map(([k,v])=>'<div class="card"><b>'+k+'</b><br>'+v+'</div>').join('');$('table').innerHTML='<table><tr><th>Status</th><th>Device</th><th>Model</th><th>Version</th><th>Last seen</th><th>Actions</th></tr>'+u.users.map(d=>'<tr><td>'+d.status+'</td><td>'+d.shortId+'<div class="small">'+d.installId+'</div></td><td>'+d.deviceModel+'</td><td>'+d.appVersion+'</td><td>'+d.lastSeen+'</td><td><button class="ok" onclick="act(\\''+d.installId+'\\',\\'authorize\\')">Authorize</button><button class="pending" onclick="act(\\''+d.installId+'\\',\\'pending\\')">Pending</button><button class="bad" onclick="act(\\''+d.installId+'\\',\\'block\\')">Block</button><button onclick="removeDevice(\\''+d.installId+'\\')">Delete</button></td></tr>').join('')+'</table>'}catch(e){$('table').innerHTML='<p class="bad">'+e.message+'</p>'}}
async function act(id,status){await api('/admin/users/'+encodeURIComponent(id)+'/'+status,{method:'POST'});loadAll()}
async function removeDevice(id){if(confirm('Delete this installation record?')){await api('/admin/users/'+encodeURIComponent(id),{method:'DELETE'});loadAll()}}
</script></body></html>`;

app.listen(PORT, () => {
  console.log(`ToracoKey AI Backend v0.37 listening on ${PORT}`);
  console.log(`Device registry: ${DATA_FILE}`);
  console.log(`Default device status: ${DEFAULT_DEVICE_STATUS}`);
  if (!ADMIN_TOKEN) console.warn('WARNING: ADMIN_TOKEN is not configured. Admin controls are disabled.');
});
