# ToracoKey AI Backend v0.37

This backend keeps the existing `/ask` API and adds remote installation control.

## Render environment variables

Required for admin controls:

- `ADMIN_TOKEN` — long random secret used by the `/admin` dashboard and admin API.

Optional:

- `OPENROUTER_API_KEY` — OpenRouter fallback key.
- `OPENROUTER_MODEL` — defaults to `openai/gpt-oss-120b:free`.
- `HORDE_MODEL` — defaults to `openai/gpt-oss-120b`.
- `DEFAULT_DEVICE_STATUS` — `authorized` (default) or `pending`.
- `DEVICE_DATA_FILE` — path to the device registry JSON file. On Render, use a persistent disk path such as `/var/data/devices.json` if you want the registry to survive service restarts/deploys.

## Render start command

`node server.js`

## Admin dashboard

Open:

`https://YOUR-BACKEND-DOMAIN/admin`

Enter the value of `ADMIN_TOKEN`.

The dashboard shows registered installations and lets the administrator:

- Authorize
- Put into pending state
- Block
- Delete a device record

The registry stores only an anonymous app-generated installation UUID plus basic app/device metadata and timestamps. It does not store typed text, contacts, phone numbers, email addresses, or exact location.
