# ToracoKey AI v0.6 — ReverseCalc Merge

ToracoKey AI keyboard with a Gboard-style dark layout, AI suggestion bar, calculator/percentage suggestions, emoji suggestions, symbols, shift, long-press backspace, and ReverseCalc-inspired text modes.

Modes: Normal, Reverse, Mono, Double, Alt Case, H H.

AI backend remains server-side at Render; no API key is stored in the APK.


## v0.7 UI update
- Moved the Caps/Shift button from the bottom row to directly beside Z.
- Removed the bottom-row Shift button.
- Kept the Z-M row Gboard-style with Caps/Shift, Z-M, and Backspace.
- AI/backend functionality remains unchanged.
