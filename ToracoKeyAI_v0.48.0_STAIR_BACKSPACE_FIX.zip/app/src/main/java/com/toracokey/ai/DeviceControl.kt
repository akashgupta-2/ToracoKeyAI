package com.toracokey.ai

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.util.UUID

/** Fetches the server-owned feature policy. The backend must expose GET /device/policy. */
class DeviceControl(private val context: Context) {
    companion object {
        const val CONTROL_URL = "https://toracokeyai-backend.onrender.com/device/policy"
        const val APP_VERSION = "0.48.0"
        private const val PREFS = "toracokey_feature_policy"
        private const val TYPING = "typing_enabled"
        private const val AI = "ai_enabled"
        private const val MIN_VERSION = "minimum_app_version"
        private const val MESSAGE = "policy_message"
        private const val FETCHED_AT = "fetched_at"
        private const val INSTALL_ID = "install_id"
    }

    data class Result(
        val typingEnabled: Boolean,
        val aiEnabled: Boolean,
        val status: String,
        val message: String,
        val minimumAppVersion: String
    )

    fun getInstallId(): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString(INSTALL_ID, null)
        if (!old.isNullOrBlank()) return old
        val id = UUID.randomUUID().toString()
        prefs.edit().putString(INSTALL_ID, id).apply()
        return id
    }

    fun cachedPolicy(): Result {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val fetchedAt = p.getLong(FETCHED_AT, 0L)
        if (fetchedAt == 0L) {
            // No policy has ever been received. Do not treat connectivity as
            // an authorization requirement; remote controls apply when reachable.
            return Result(
                true, true, "offline_default",
                "Remote kill switch is unavailable; local typing and AI remain enabled",
                ""
            )
        }

        // Preserve the last known server decision while offline, even if old.
        // This means a previously received DISABLED state remains disabled.
        val typing = p.getBoolean(TYPING, true)
        val ai = typing && p.getBoolean(AI, true)
        val status = when {
            !typing -> "typing_disabled"
            !ai -> "ai_disabled"
            else -> "cached"
        }
        return Result(
            typing, ai, status,
            p.getString(MESSAGE, "Using last known remote policy") ?: "Using last known remote policy",
            p.getString(MIN_VERSION, "") ?: ""
        )
    }

    fun checkPolicy(): Result {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL(CONTROL_URL)
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 10_000
                useCaches = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-ToracoKey-App-Version", APP_VERSION)
                setRequestProperty("User-Agent", "ToracoKeyAI/$APP_VERSION")
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            if (code == 426) {
                // The backend may return a newer minimum version in its 426 body.
                // Parse it so the app can show the real required version instead of
                // incorrectly repeating the currently installed version.
                val errorJson = try {
                    JSONObject(body)
                } catch (_: Exception) {
                    JSONObject()
                }
                val minimum = errorJson.optString("minimumAppVersion", "").trim()
                val serverMessage = errorJson.optString("error", "").trim()
                val message = when {
                    minimum.isNotBlank() -> "Update required: install ToracoKey AI $minimum or newer"
                    serverMessage.isNotBlank() -> serverMessage
                    else -> "This version is no longer supported. Please update ToracoKey AI."
                }
                return Result(false, false, "update_required", message, minimum)
            }
            if (code !in 200..299) {
                return cachedPolicy()
            }

            val json = JSONObject(body)
            val minimum = json.optString("minimumAppVersion", "0.0.0")
            val versionAllowed = compareVersions(APP_VERSION, minimum) >= 0
            val typing = versionAllowed && json.optBoolean("typingEnabled", false)
            val ai = versionAllowed && typing && json.optBoolean("aiEnabled", false)
            val message = when {
                !versionAllowed -> "Update required: version $minimum or newer"
                !typing -> json.optString("message", "Typing is disabled by the administrator")
                !ai -> json.optString("message", "AI features are disabled by the administrator")
                else -> json.optString("message", "ToracoKey is enabled")
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(TYPING, typing)
                .putBoolean(AI, ai)
                .putString(MIN_VERSION, minimum)
                .putString(MESSAGE, message)
                .putLong(FETCHED_AT, System.currentTimeMillis())
                .apply()
            Result(typing, ai, if (!versionAllowed) "update_required" else if (!typing) "typing_disabled" else if (!ai) "ai_disabled" else "enabled", message, minimum)
        } catch (_: Exception) {
            cachedPolicy()
        } finally {
            connection?.disconnect()
        }
    }

    private fun compareVersions(a: String, b: String): Int {
        val aa = a.split('.').map { it.toIntOrNull() ?: 0 }
        val bb = b.split('.').map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(aa.size, bb.size)) {
            val x = aa.getOrElse(i) { 0 }
            val y = bb.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }
}
