ToracoKey AI v0.21
Safe special typing and deferred UI refresh.
