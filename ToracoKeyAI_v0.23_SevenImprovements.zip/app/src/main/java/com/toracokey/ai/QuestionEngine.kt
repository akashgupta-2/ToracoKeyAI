package com.toracokey.ai

object QuestionEngine {
    private val starters = setOf(
        "what", "why", "how", "when", "where", "who", "which",
        "whose", "whom", "can", "could", "will", "would", "should",
        "shall", "do", "does", "did", "is", "are", "am", "was",
        "were", "have", "has", "had", "define", "explain", "name",
        "tell", "give", "list"
    )

    fun isQuestion(text: String): Boolean {
        // Trailing spaces do not change the question context.
        val q = text.trim().lowercase()
        if (q.isEmpty()) return false

        // Explicit question mark.
        if (q.endsWith("?")) return true

        // Multi-word question starters that do not begin with
        // the normal single-word starter list.
        val phraseStarters = listOf(
            "for what",
            "in which",
            "in what",
            "from where",
            "difference between",
            "difference from"
        )

        if (phraseStarters.any { q == it || q.startsWith("$it ") }) {
            return q.length > it.length
        }

        // "A thing is used to..." construction.
        // Example: "car is used to transport..."
        //
        // This is intentionally based on the construction rather
        // than treating every occurrence of "used" as a question.
        val usedToPattern = Regex(
            """\b[a-z][a-z0-9-]*(?:\s+[a-z][a-z0-9-]*){0,6}\s+(?:is|are|was|were)\s+used\s+to(?:\s|$)""",
            RegexOption.IGNORE_CASE
        )

        if (usedToPattern.containsMatchIn(q)) {
            return true
        }

        val first = q
            .split(Regex("\\s+"), limit = 2)
            .firstOrNull()
            ?: return false

        if (first !in starters) return false

        // Avoid treating a single word such as "is" or "can"
        // as a question.
        return q.length > first.length
    }
}
