package com.toracokey.ai

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import androidx.core.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ToracoKeyService : InputMethodService() {
    companion object {
        private const val BACKEND_URL = "https://toracokeyai-backend.onrender.com/ask"
        private const val DEBOUNCE_MS = 700L
        private const val MAX_AI_ANSWERS = 5
    }

    private lateinit var suggestionScroll: HorizontalScrollView
    private lateinit var suggestions: LinearLayout
    private val mainHandler = Handler(Looper.getMainLooper())
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val debounceExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var pendingRequest: java.util.concurrent.ScheduledFuture<*>? = null
    private var requestNumber = 0L
    private var mode = KeyboardMode.NORMAL
    private var latestAiAnswers: List<String> = emptyList()
    private var aiError: String? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var voiceListening = false
    private var voiceInputConnection: InputConnection? = null
    private var voiceMode: KeyboardMode = KeyboardMode.NORMAL

    private val voicePermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == VoiceInputActivity.ACTION_VOICE_PERMISSION_GRANTED) {
                startSpeechRecognizer()
            }
        }
    }

    private fun startVoiceTyping() {
        voiceInputConnection = currentInputConnection
        voiceMode = mode
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            try {
                startActivity(Intent(this, VoiceInputActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (_: Exception) {}
            return
        }
        startSpeechRecognizer()
    }

    private fun startSpeechRecognizer() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
                if (!SpeechRecognizer.isRecognitionAvailable(this)) return@post

                val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer = recognizer
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) { voiceListening = true }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { voiceListening = false }
                    override fun onError(error: Int) { voiceListening = false; mainHandler.post { if (::suggestions.isInitialized) updateSuggestions() } }
                    override fun onResults(results: android.os.Bundle?) {
                        voiceListening = false
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.trim().orEmpty()
                        if (text.isNotEmpty()) {
                            val ic = voiceInputConnection
                            val selectedMode = voiceMode
                            mainHandler.post {
                                try {
                                    val output = transformVoiceText(text, selectedMode)
                                    ic?.commitText(output, 1)
                                } catch (_: Exception) {
                                    // Keep the keyboard alive even if the target editor closes.
                                } finally {
                                    voiceInputConnection = null
                                    updateQuestionDetection()
                                    if (::suggestions.isInitialized) updateSuggestions()
                                }
                            }
                        } else {
                            voiceInputConnection = null
                            mainHandler.post { if (::suggestions.isInitialized) updateSuggestions() }
                        }
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }
                recognizer.startListening(intent)
            } catch (_: Exception) {
                voiceListening = false
                updateSuggestions()
            }
        }
    }

    private fun stopSpeechRecognizer() {
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        voiceListening = false
    }

    private val keyboardBg = Color.rgb(47, 48, 50)
    private val suggestionBg = Color.rgb(61, 64, 68)
    private val keyText = Color.rgb(245, 245, 245)

    override fun onCreate() {
        super.onCreate()
        ContextCompat.registerReceiver(
            this,
            voicePermissionReceiver,
            IntentFilter(VoiceInputActivity.ACTION_VOICE_PERMISSION_GRANTED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setBackgroundColor(keyboardBg)
        }

        suggestionScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(keyboardBg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        suggestionScroll.addView(suggestions, ViewGroup.LayoutParams(-2, dp(40)))
        root.addView(suggestionScroll, LinearLayout.LayoutParams(-1, dp(40)))

        val keyboard = QwertyKeyboard(
            service = this,
            getMode = { mode },
            onKey = { value ->
                commitTypedKey(value)
                updateQuestionDetection()
            },
            onMode = { cycleMode() }
        )
        root.addView(keyboard, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        updateSuggestions()
        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        pendingRequest?.cancel(false)
        requestNumber++
        latestAiAnswers = emptyList()
        aiError = null
        mode = KeyboardMode.NORMAL
        if (::suggestions.isInitialized) updateSuggestions()
    }

    private fun updateQuestionDetection() {
        if (!::suggestions.isInitialized) return
        val text = editorText()
        val isQuestion = QuestionEngine.isQuestion(text) && mode == KeyboardMode.NORMAL
        pendingRequest?.cancel(true)
        pendingRequest = null
        latestAiAnswers = emptyList()
        aiError = null
        if (!isQuestion) {
            requestNumber++
            updateSuggestions()
            return
        }
        val question = text.trim()
        val thisRequest = ++requestNumber
        updateSuggestions(thinking = true)
        pendingRequest = debounceExecutor.schedule({
            networkExecutor.execute {
                val requestedCount = requestedAnswerCount(question)
                val answerLimit = requestedCount.coerceIn(1, MAX_AI_ANSWERS)
                val aiPrompt =
                    "Answer this question with up to $answerLimit distinct, concise valid answers. " +
                    "If the question asks to name/list a specific number of items, provide that many when valid. " +
                    "Put each answer on its own line. Do not number them and do not add explanations unless necessary. " +
                    "Question: $question"
                val result = askBackendWithRetry(aiPrompt)
                mainHandler.post {
                    // Only ignore results from an older request. Do not compare the
                    // editor text again: Android IMEs may normalize/correct text
                    // while the network request is in flight.
                    if (thisRequest != requestNumber) return@post
                    latestAiAnswers = result.answer?.let { parseAnswers(it) }.orEmpty()
                    aiError = result.error
                    updateSuggestions()
                }
            }
        }, DEBOUNCE_MS, TimeUnit.MILLISECONDS)
    }

    private fun requestedAnswerCount(question: String): Int {
        val q = question.lowercase()
        val words = mapOf(
            "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
            "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10
        )
        val match = Regex("\\b(name|list)\\s+(\\d+|one|two|three|four|five|six|seven|eight|nine|ten)\\b").find(q)
            ?: return 1
        return match.groupValues[2].toIntOrNull() ?: (words[match.groupValues[2]] ?: 1)
    }

    private fun updateSuggestions(thinking: Boolean = false) {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        addChip("▦ ${modeName()}") { cycleMode() }
        addChip("🎤 Voice") { startVoiceTyping() }

        val all = editorText()
        val tok = all.substringAfterLast(" ")
        Calculator.calculate(tok)?.let { addChip("= $it") { replaceToken(it) } }
        EmojiData.search(tok).forEach { item -> addChip(item.emoji) { replaceToken(item.emoji) } }

        if (thinking) {
            addChip("✨ Thinking…") {}
        } else if (latestAiAnswers.isNotEmpty()) {
            latestAiAnswers.take(MAX_AI_ANSWERS).forEach { answer ->
                addChip("✨ $answer") { replaceAll(all, answer); latestAiAnswers = emptyList(); aiError = null }
            }
        } else if (!aiError.isNullOrBlank() && QuestionEngine.isQuestion(all) && mode == KeyboardMode.NORMAL) {
            addChip("⚠ ${aiError!!}") {}
        } else if (QuestionEngine.isQuestion(all) && mode == KeyboardMode.NORMAL) {
            addChip("✨ AI ready") {}
        }

        if (all.isNotEmpty() && mode != KeyboardMode.NORMAL) {
            val transformed = transformAll(all)
            if (transformed != all) addChip("↻ $transformed") { replaceAll(all, transformed) }
        }

        if (suggestions.childCount == 1) addChip("Type a question • calculator • emoji • modes") {}
    }

    private fun cycleMode() {
        // Change only the state during the key/click callback. Do not mutate the
        // suggestion view hierarchy while Android is dispatching that callback.
        pendingRequest?.cancel(true)
        pendingRequest = null
        requestNumber++

        val values = KeyboardMode.values()
        mode = values[(mode.ordinal + 1) % values.size]
        latestAiAnswers = emptyList()
        aiError = null

        // Refresh after the current touch/click dispatch has completely returned.
        mainHandler.post {
            if (!::suggestions.isInitialized) return@post
            try {
                updateSuggestions()
            } catch (_: Exception) {
                // Never let a suggestion refresh crash the IME.
            }
        }
    }

    private fun addChip(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = if (label.startsWith("✨")) 14f else 13f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(8), 0, dp(8), 0)
            background = GradientDrawable().apply { setColor(suggestionBg); cornerRadius = dp(9).toFloat() }
            stateListAnimator = null
            setOnClickListener { try { action() } catch (_: Exception) {} }
        }
        suggestions.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun commitTypedKey(value: String) {
        if (value == "\b") {
            safeDelete(1)
            return
        }
        if (value == " " || value.length != 1 || !value[0].isLetter()) {
            safeCommit(value)
            return
        }

        val ch = value[0]
        try {
            when (mode) {
                KeyboardMode.NORMAL, KeyboardMode.REVERSE -> safeCommit(ch.toString())
                KeyboardMode.MONO -> safeCommit("$ch ")
                KeyboardMode.DOUBLE -> safeCommit("$ch$ch ")
                KeyboardMode.ALT_CASE -> {
                    val before = editorText()
                    val letters = before.count { it.isLetter() }
                    val out = if (letters % 2 == 0) ch.lowercaseChar() else ch.uppercaseChar()
                    safeCommit(out.toString())
                }
                KeyboardMode.SPACED_DOUBLE -> safeCommit("$ch $ch ")
            }
        } catch (_: Exception) {
            safeCommit(ch.toString())
        }
    }

    private fun replaceToken(value: String) {
        val all = editorText()
        val token = all.substringAfterLast(" ")
        if (token.isNotEmpty()) safeDelete(token.length)
        safeCommit(value)
        updateQuestionDetection()
    }

    private fun replaceAll(old: String, value: String) {
        if (old.isNotEmpty()) safeDelete(old.length)
        safeCommit(value)
        updateQuestionDetection()
    }

    private fun transformVoiceText(input: String, selectedMode: KeyboardMode): String = when (selectedMode) {
        KeyboardMode.NORMAL, KeyboardMode.REVERSE -> input + " "
        KeyboardMode.MONO -> input.split(" ", limit = -1).joinToString(" ") { word ->
            word.toCharArray().joinToString(" ")
        } + " "
        KeyboardMode.DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { word ->
            word.toCharArray().joinToString("") { ch -> "$ch$ch " }.trimEnd()
        } + " "
        KeyboardMode.ALT_CASE -> {
            var upper = false
            buildString(input.length + 1) {
                input.forEach { ch ->
                    if (ch == ' ') { append(ch); upper = false }
                    else { append(if (upper) ch.uppercaseChar() else ch.lowercaseChar()); upper = !upper }
                }
                append(' ')
            }
        }
        KeyboardMode.SPACED_DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { word ->
            word.toCharArray().joinToString(" ") { ch -> "$ch $ch" }
        } + " "
    }

    private fun transformAll(input: String): String = when (mode) {
        KeyboardMode.NORMAL -> input
        KeyboardMode.REVERSE -> input.reversed()
        KeyboardMode.MONO -> input.split(" ", limit = -1).joinToString(" ") { it.toCharArray().joinToString(" ") }
        KeyboardMode.DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { w -> w.toCharArray().joinToString(" ") { ch -> "$ch$ch" } }
        KeyboardMode.ALT_CASE -> {
            var upper = false
            buildString(input.length) { input.forEach { ch ->
                if (ch == ' ') { append(ch); upper = false }
                else { append(if (upper) ch.uppercaseChar() else ch.lowercaseChar()); upper = !upper }
            }}
        }
        KeyboardMode.SPACED_DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { w -> w.toCharArray().joinToString(" ") { ch -> "$ch $ch" } }
    }

    private fun parseAnswers(raw: String): List<String> {
        return raw
            .replace("\r", "")
            .split("\n", "|||", "•", ";")
            .map { it.trim().replace(Regex("^[-*]\\s+"), "").replace(Regex("^\\d+[.)]\\s+"), "") }
            .filter { it.isNotBlank() }
            .distinct()
            .take(MAX_AI_ANSWERS)
    }

    private fun editorText(): String = try { currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: "" } catch (_: Exception) { "" }
    private fun safeCommit(value: String) { try { currentInputConnection?.commitText(value, 1) } catch (_: Exception) {} }
    private fun safeDelete(count: Int) { try { currentInputConnection?.deleteSurroundingText(count, 0) } catch (_: Exception) {} }

    private fun modeName() = when (mode) {
        KeyboardMode.NORMAL -> "Normal"
        KeyboardMode.REVERSE -> "Reverse"
        KeyboardMode.MONO -> "Mono"
        KeyboardMode.DOUBLE -> "Double"
        KeyboardMode.ALT_CASE -> "Alt"
        KeyboardMode.SPACED_DOUBLE -> "H H"
    }

    private data class AiResult(val answer: String?, val error: String?)

    private fun askBackendWithRetry(question: String): AiResult {
        var last = AiResult(null, "No answer")
        repeat(3) { attempt ->
            if (Thread.currentThread().isInterrupted) return last
            last = askBackend(question)
            if (last.answer != null) return last
            if (attempt < 2) {
                try { Thread.sleep(800L * (attempt + 1)) }
                catch (_: InterruptedException) { return last }
            }
        }
        return last
    }

    private fun askBackend(question: String): AiResult {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 45_000
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "ToracoKeyAI/0.17.1")
            }
            val body = JSONObject().put("question", question).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseBody = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            if (status !in 200..299) {
                return AiResult(null, "Server error $status")
            }
            val answer = JSONObject(responseBody).optString("answer").trim()
            if (answer.isNotBlank()) AiResult(answer, null)
            else AiResult(null, "No answer")
        } catch (e: Exception) {
            val message = e.message?.take(32)?.replace("\n", " ") ?: "Network error"
            AiResult(null, message)
        } finally {
            connection?.disconnect()
        }
    }

    override fun onDestroy() {
        stopSpeechRecognizer()
        try { unregisterReceiver(voicePermissionReceiver) } catch (_: Exception) {}
        pendingRequest?.cancel(true)
        pendingRequest = null
        requestNumber++
        try { debounceExecutor.shutdownNow() } catch (_: Exception) {}
        try { networkExecutor.shutdownNow() } catch (_: Exception) {}
        mainHandler.removeCallbacksAndMessages(null)
        voiceInputConnection = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
