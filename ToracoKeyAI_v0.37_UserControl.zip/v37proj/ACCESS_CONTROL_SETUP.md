# ToracoKey AI v0.37 — User Control

This version adds device authorization. The Android keyboard registers an anonymous device ID with a separate access-control service before allowing the IME to run. A blocked device is denied and the keyboard hides itself.

## 1. Deploy `access-server`
Create a separate Render Web Service from the `access-server` folder.
- Build command: `npm install`
- Start command: `npm start`
- Environment variable: `ADMIN_TOKEN` = a long random secret
- Optional: `LEASE_HOURS=24`
- Recommended for persistent users: attach a Render persistent disk and set `DATA_DIR=/var/data/toracokey-access`

After deployment, note the service URL.

## 2. Put the URL in Android
Open:
`app/src/main/java/com/toracokey/ai/DeviceAccess.kt`

Change:
`https://toracokeyai-access.onrender.com`
to your actual access-control Render URL.

## 3. What the admin can control
Open the access service `/admin` page and enter the same `ADMIN_TOKEN`.

You can:
- see every registered device
- see device name, Android version and app version
- see first/last seen
- block one device
- unblock one device
- disable/enable ToracoKey AI globally

## Important
The access service intentionally stores an anonymous device ID and limited device metadata. It does not receive typed text, contacts, passwords or location.

Without persistent storage, the user list resets when the Render service is restarted/redeployed. Use a persistent Render disk if you need the registry to survive restarts.
