const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json({ limit: '32kb' }));

const PORT = process.env.PORT || 10000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');
const LEASE_HOURS = Number(process.env.LEASE_HOURS || 24);

fs.mkdirSync(DATA_DIR, { recursive: true });

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return fallback;
  }
}

function writeJson(file, value) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2));
  fs.renameSync(tmp, file);
}

let users = readJson(USERS_FILE, {});
let settings = readJson(SETTINGS_FILE, { enabled: true });

function saveUsers() { writeJson(USERS_FILE, users); }
function saveSettings() { writeJson(SETTINGS_FILE, settings); }
function now() { return new Date().toISOString(); }
function leaseUntil() { return new Date(Date.now() + LEASE_HOURS * 3600000).toISOString(); }
function clean(value, max) { return String(value || '').trim().slice(0, max); }
function isValidDeviceId(id) { return /^[a-f0-9-]{16,128}$/i.test(id); }

function adminAuth(req, res, next) {
  if (!ADMIN_TOKEN) return res.status(503).json({ error: 'ADMIN_TOKEN is not configured' });
  const auth = req.get('authorization') || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token || token.length !== ADMIN_TOKEN.length || !crypto.timingSafeEqual(Buffer.from(token), Buffer.from(ADMIN_TOKEN))) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
}

function publicUser(user) {
  return {
    deviceId: user.deviceId,
    deviceName: user.deviceName,
    androidVersion: user.androidVersion,
    appVersion: user.appVersion,
    firstSeen: user.firstSeen,
    lastSeen: user.lastSeen,
    status: user.blocked ? 'blocked' : (settings.enabled ? 'active' : 'globally_disabled'),
    blocked: !!user.blocked,
    blockReason: user.blockReason || '',
    lastIp: user.lastIp || null
  };
}

app.get('/', (req, res) => {
  res.json({ ok: true, service: 'ToracoKey Access Control', version: '1.0.0' });
});

app.post('/access/register', (req, res) => {
  const deviceId = clean(req.body?.deviceId, 128);
  if (!isValidDeviceId(deviceId)) return res.status(400).json({ authorized: false, error: 'Invalid device ID' });

  const existing = users[deviceId];
  const current = existing || {
    deviceId,
    firstSeen: now(),
    blocked: false,
    blockReason: ''
  };

  current.lastSeen = now();
  current.lastIp = req.ip;
  current.deviceName = clean(req.body?.deviceName, 120) || current.deviceName || 'Unknown device';
  current.androidVersion = clean(req.body?.androidVersion, 40) || current.androidVersion || 'Unknown';
  current.appVersion = clean(req.body?.appVersion, 40) || current.appVersion || 'Unknown';

  users[deviceId] = current;
  saveUsers();

  if (!settings.enabled) {
    return res.status(403).json({ authorized: false, reason: 'service_disabled', message: 'ToracoKey AI is currently disabled by the administrator.' });
  }
  if (current.blocked) {
    return res.status(403).json({ authorized: false, reason: 'blocked', message: current.blockReason || 'This device has been blocked.' });
  }

  res.json({ authorized: true, leaseUntil: leaseUntil(), serverTime: now() });
});

app.post('/access/heartbeat', (req, res) => {
  const deviceId = clean(req.body?.deviceId, 128);
  if (!isValidDeviceId(deviceId) || !users[deviceId]) return res.status(403).json({ authorized: false, reason: 'unknown_device' });
  const user = users[deviceId];
  user.lastSeen = now();
  user.lastIp = req.ip;
  saveUsers();

  if (!settings.enabled) return res.status(403).json({ authorized: false, reason: 'service_disabled' });
  if (user.blocked) return res.status(403).json({ authorized: false, reason: 'blocked', message: user.blockReason || 'This device has been blocked.' });
  res.json({ authorized: true, leaseUntil: leaseUntil(), serverTime: now() });
});

app.get('/admin', (req, res) => {
  res.type('html').send(`<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>ToracoKey Access Control</title><style>body{font-family:system-ui;background:#111;color:#eee;margin:0;padding:20px}button,input{padding:10px;border-radius:8px;border:1px solid #444;background:#222;color:#eee;margin:4px}button{cursor:pointer}table{width:100%;border-collapse:collapse;margin-top:16px}td,th{padding:8px;border-bottom:1px solid #333;text-align:left;font-size:13px}.blocked{color:#ff7777}.active{color:#77dd99}.danger{background:#5a2020}.card{background:#191919;padding:16px;border-radius:12px;margin-bottom:16px}@media(max-width:800px){table{display:block;overflow:auto;white-space:nowrap}}</style></head><body><div class="card"><h2>ToracoKey AI — User Control</h2><input id="token" type="password" placeholder="Admin token"><button onclick="load()">Login / Refresh</button><button onclick="toggle()" id="global">Loading...</button><div id="summary"></div></div><div class="card"><button onclick="load()">Refresh users</button><table><thead><tr><th>Device</th><th>Android</th><th>App</th><th>First seen</th><th>Last seen</th><th>Status</th><th>Action</th></tr></thead><tbody id="users"></tbody></table></div><script>const t=()=>document.getElementById('token').value;async function api(url,opt={}){opt.headers={...(opt.headers||{}),Authorization:'Bearer '+t(),'Content-Type':'application/json'};const r=await fetch(url,opt);const j=await r.json();if(!r.ok)throw new Error(j.error||j.message||'Request failed');return j}async function load(){try{const d=await api('/admin/users');document.getElementById('global').textContent=d.settings.enabled?'Disable keyboard globally':'Enable keyboard globally';document.getElementById('summary').textContent=d.users.length+' registered devices';document.getElementById('users').innerHTML=d.users.map(u=>'<tr><td>'+esc(u.deviceName)+'<br><small>'+esc(u.deviceId)+'</small></td><td>'+esc(u.androidVersion)+'</td><td>'+esc(u.appVersion)+'</td><td>'+esc(u.firstSeen)+'</td><td>'+esc(u.lastSeen)+'</td><td class="'+(u.blocked?'blocked':'active')+'">'+esc(u.status)+'</td><td><button class="'+(u.blocked?'':'danger')+'" onclick="block(\''+u.deviceId+'\','+(!u.blocked)+')">'+(u.blocked?'Unblock':'Block')+'</button></td></tr>').join('')}catch(e){alert(e.message)}}async function block(id,b){try{await api('/admin/users/'+encodeURIComponent(id)+'/'+(b?'block':'unblock'),{method:'POST',body:JSON.stringify({reason:b?'Blocked by administrator':''})});load()}catch(e){alert(e.message)}}async function toggle(){try{const d=await api('/admin/settings',{method:'POST',body:JSON.stringify({enabled:document.getElementById('global').textContent.startsWith('Disable')?false:true})});load()}catch(e){alert(e.message)}}function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</script></body></html>`);
});

app.get('/admin/users', adminAuth, (req, res) => {
  const list = Object.values(users).sort((a,b) => String(b.lastSeen).localeCompare(String(a.lastSeen))).map(publicUser);
  res.json({ settings, users: list });
});

app.post('/admin/users/:deviceId/block', adminAuth, (req, res) => {
  const id = req.params.deviceId;
  if (!users[id]) return res.status(404).json({ error: 'Device not found' });
  users[id].blocked = true;
  users[id].blockReason = clean(req.body?.reason, 200) || 'Blocked by administrator';
  users[id].lastSeen = now();
  saveUsers();
  res.json({ ok: true, user: publicUser(users[id]) });
});

app.post('/admin/users/:deviceId/unblock', adminAuth, (req, res) => {
  const id = req.params.deviceId;
  if (!users[id]) return res.status(404).json({ error: 'Device not found' });
  users[id].blocked = false;
  users[id].blockReason = '';
  users[id].lastSeen = now();
  saveUsers();
  res.json({ ok: true, user: publicUser(users[id]) });
});

app.post('/admin/settings', adminAuth, (req, res) => {
  settings.enabled = Boolean(req.body?.enabled);
  saveSettings();
  res.json({ ok: true, settings });
});

app.listen(PORT, () => console.log(`ToracoKey Access Control running on port ${PORT}`));
