# ToracoKey AI Access Control

Separate Render service for anonymous device authorization and administrator control.

## Environment variables
- `ADMIN_TOKEN`: long random secret used by the admin dashboard/API.
- `LEASE_HOURS`: optional authorization lease, default 24.
- `DATA_DIR`: optional persistent directory. On Render, attach a persistent disk and set `DATA_DIR=/var/data/toracokey-access` if you want the user list to survive service restarts.

## Admin
Open `/admin`, enter `ADMIN_TOKEN`, and you can:
- see registered devices
- see first/last seen, Android/app version, and device name
- block or unblock individual devices
- disable/enable the keyboard globally

The service stores an anonymous generated device ID. It does not receive typed text, contacts, passwords, or location.
