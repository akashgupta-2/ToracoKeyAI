package com.toracokey.ai

import kotlin.math.pow
import java.math.BigDecimal
import java.math.RoundingMode

object Calculator {
    fun calculate(input: String): String? {
        val s = input.replace(" ", "")
        if (s.isEmpty() || !s.matches(Regex("[0-9+\\-*/%.()^]+"))) return null
        return try {
            val v = P(s).parse()
            if (!v.isFinite()) null
            else {
                // Format through BigDecimal.valueOf so exact integer results such
                // as 100^10 are not printed with binary floating-point artifacts.
                val decimal = BigDecimal.valueOf(v)
                if (decimal.stripTrailingZeros().scale() <= 0) {
                    decimal.toBigIntegerExact().toString()
                } else {
                    decimal.setScale(10, RoundingMode.HALF_UP)
                        .stripTrailingZeros()
                        .toPlainString()
                }
            }
        } catch (_: Exception) { null }
    }

    private class P(private val s: String) {
        var p = 0
        fun parse(): Double { val v = e(); if (p != s.length) error("extra"); return v }
        fun e(): Double {
            var v = t()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) {
                val o = s[p++]
                val rhsStart = p
                val r = t()
                // For +/-, a percentage RHS is a percentage of the current LHS:
                // 67-7% = 67-(7/100*67) = 62.31.
                val rhsWasPercentage = rhsStart < s.length && s.substring(rhsStart, p).endsWith("%")
                val rr = if (rhsWasPercentage) v * r else r
                v = if (o == '+') v + rr else v - rr
            }
            return v
        }
        fun t(): Double {
            var v = pow()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) {
                val o = s[p++]; val r = pow()
                if (o == '/' && r == 0.0) error("zero")
                v = if (o == '*') v * r else v / r
            }
            return v
        }
        fun pow(): Double { var v = postfix(); if (p < s.length && s[p] == '^') { p++; v = v.pow(pow()) }; return v }

        // Calculator-style percentage: 7% after 67- means 7% of 67.
        // Standalone 50% remains 0.5, and multiplication/division keep normal
        // percentage semantics (e.g. 200*10% = 20).
        fun postfix(): Double {
            var v = u()
            if (p < s.length && s[p] == '%') {
                p++
                v /= 100.0
            }
            return v
        }

        fun u(): Double {
            if (p < s.length && s[p] == '+') { p++; return u() }
            if (p < s.length && s[p] == '-') { p++; return -u() }
            return n()
        }
        fun n(): Double {
            if (p < s.length && s[p] == '(') {
                p++; val v = e(); if (p >= s.length || s[p++] != ')') error(")"); return v
            }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (st == p) error("num")
            return s.substring(st, p).toDouble()
        }
    }
}
