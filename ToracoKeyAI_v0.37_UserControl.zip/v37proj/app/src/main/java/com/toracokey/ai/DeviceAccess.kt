package com.toracokey.ai

import android.content.Context
import android.os.Build
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import org.json.JSONObject

object DeviceAccess {
    private const val PREFS = "toracokey_access"
    private const val DEVICE_ID = "device_id"
    private const val AUTHORIZED_UNTIL = "authorized_until"

    // Deploy access-server separately and replace this URL with its Render URL.
    private const val ACCESS_BASE_URL = "https://toracokeyai-access.onrender.com"

    private fun deviceId(context: Context): String {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = p.getString(DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val id = UUID.randomUUID().toString()
        p.edit().putString(DEVICE_ID, id).apply()
        return id
    }

    fun currentDeviceId(context: Context): String = deviceId(context)

    fun authorize(context: Context, appVersion: String): Boolean {
        return try {
            val payload = JSONObject()
                .put("deviceId", deviceId(context))
                .put("deviceName", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                .put("androidVersion", Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString())
                .put("appVersion", appVersion)
            val result = post("/access/register", payload)
            if (result.optBoolean("authorized", false)) {
                val until = result.optString("leaseUntil", "")
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(AUTHORIZED_UNTIL, until).apply()
                true
            } else false
        } catch (_: Exception) {
            false
        }
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        val connection = (URL(ACCESS_BASE_URL + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 10000
            doOutput = true
            useCaches = false
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "ToracoKeyAI-Access/0.37")
        }
        return try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (text.isBlank()) JSONObject().put("authorized", false)
            else JSONObject(text)
        } finally {
            connection.disconnect()
        }
    }
}
