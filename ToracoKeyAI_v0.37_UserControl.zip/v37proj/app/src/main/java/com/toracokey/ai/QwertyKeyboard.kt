package com.toracokey.ai

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.os.Handler
import android.os.Looper

class QwertyKeyboard(
    private val service: InputMethodService,
    private val getMode: () -> KeyboardMode,
    private val onKey: (String) -> Unit,
    private val onMode: () -> Unit
) : LinearLayout(service) {

    private val rowHeight = dp(56)
    private val keyboardBg = Color.rgb(47, 48, 50)
    private val keyBg = Color.rgb(70, 73, 78)
    private val keyText = Color.rgb(245, 245, 245)
    private var symbols = false
    private var secondarySymbols = false
    private var shift = false
    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false

    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            onKey("\b")
            backspaceHandler.postDelayed(this, 55)
        }
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.TOP
        setPadding(dp(3), dp(3), dp(3), dp(3))
        setBackgroundColor(keyboardBg)
        rebuild()
    }

    private fun rebuild() {
        removeAllViews()
        if (symbols) {
            addRow("1234567890", 0f)
            if (secondarySymbols) {
                addRow("[]{}\\|~^", 0.45f)
                addRow("©™_`€£¥", 0.45f, false)
            } else {
                addRow("@#$%&*()-+", 0.45f)
                addRow(",!?/:;\"='", 0.45f, false)
            }
            addUtilityRow()
        } else {
            addRow("qwertyuiop", 0f)
            addRow("asdfghjkl", 0.45f)
            addBottomLetterRow()
        }

        val bottom = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        key(bottom, if (symbols) "ABC" else "?123", 1f) {
            symbols = !symbols
            secondarySymbols = false
            shift = false
            rebuild()
        }
        // The fourth-row text-selection/mode button is intentionally removed.
        // Keep the remaining controls closer to the Gboard bottom-row proportions.
        key(bottom, "SPACE", 5.8f) { onKey(" ") }
        // Dot replaces the language-switcher key on the 123 face.
        key(bottom, ".", 0.9f) { onKey(".") }
        key(bottom, "↵", 0.9f) { onEnter() }
        addView(bottom, LayoutParams(-1, rowHeight))
        // Reserve the same kind of bottom breathing room used by the earlier Gboard-like layout.
        addView(android.view.View(context), LayoutParams(-1, dp(52)))
    }

    private fun addUtilityRow() {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        // #=+ switches between the two symbol pages. Other keys are unique
        // symbols, avoiding the repeated @, &, and * keys from the old layout.
        val entries = if (secondarySymbols) {
            listOf("#=+", "°", "•", "§", "¶", "±", "×", "Time")
        } else {
            listOf("#=+", "[", "]", "{", "}", "\\", "|", "Time")
        }

        entries.forEach { label ->
            key(row, label, if (label == "Time") 1.7f else 1f) {
                when (label) {
                    "#=+" -> {
                        secondarySymbols = !secondarySymbols
                        rebuild()
                    }
                    "Time" -> onKey("__TORACOKEY_INSERT_TIME__")
                    else -> onKey(label)
                }
            }
        }

        // Backspace remains at the far-right edge of the utility row.
        key(row, "⌫", 1.15f, true) { onKey("\b") }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun addBottomLetterRow() {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        // Gboard-style third row: Shift/Caps and Backspace reach the
        // keyboard edges. Removing the old side spacers also gives Z-M
        // slightly more horizontal room.
        key(row, "⇧", 1.15f) {
            shift = !shift
            rebuild()
        }

        "zxcvbnm".forEach { c ->
            val label = if (shift) c.uppercaseChar().toString() else c.toString()
            key(row, label) { onKey(typeFor(label)) }
        }

        key(row, "⌫", 1.15f, true) { onKey("\b") }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun addRow(chars: String, sideWeight: Float, includeBackspace: Boolean = false) {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (sideWeight > 0f) row.addView(android.view.View(context), LayoutParams(0, -1, sideWeight))
        chars.forEach { c ->
            val label = if (!symbols && shift && c.isLetter()) c.uppercaseChar().toString() else c.toString()
            key(row, label) { onKey(typeFor(label)) }
        }
        if (includeBackspace) {
            key(row, "⌫", 1f, true) { onKey("\b") }
        } else if (symbols && (chars == ",!?/:;\"=" || chars == "©™_`€£¥")) {
            // Date takes the old punctuation-row backspace position.
            key(row, "Date", 1.7f) { onKey("__TORACOKEY_INSERT_DATE__") }
        } else if (sideWeight > 0f) {
            row.addView(android.view.View(context), LayoutParams(0, -1, sideWeight))
        }
        addView(row, LayoutParams(-1, rowHeight))
    }

    private fun typeFor(label: String): String {
        // The service applies ReverseCalc-style special typing modes centrally.
        // The keyboard only emits the actual character pressed.
        return label
    }

    private fun onEnter() {
        try {
            service.currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
            service.currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER))
        } catch (_: Exception) {}
    }

    private fun key(row: LinearLayout, label: String, weight: Float = 1f, backspace: Boolean = false, action: () -> Unit) {
        // Use a full-width touch slot for every key. The visible key keeps its
        // small gap/margin, while the invisible slot remains tappable across the
        // entire allocated width. This makes edge taps behave more like Gboard
        // instead of requiring the user to hit the visual center of the key.
        val slot = FrameLayout(context).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }

        val b = Button(context).apply {
            text = label
            textSize = if (label == "SPACE") 13f else 15f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply { setColor(keyBg); cornerRadius = dp(9).toFloat() }
            stateListAnimator = null
            // The wrapper owns the touch target; the Button is visual only.
            isClickable = false
            isFocusable = false
        }
        slot.addView(b, FrameLayout.LayoutParams(-1, -1).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        })

        if (backspace) {
            slot.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        backspaceDeleting = false; backspaceBurstStarted = false
                        backspaceHandler.postDelayed({
                            if (!slot.isAttachedToWindow) return@postDelayed
                            backspaceDeleting = true; backspaceBurstStarted = true
                            backspaceHandler.post(backspaceRunnable)
                        }, 350); true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        backspaceHandler.removeCallbacksAndMessages(null)
                        val burst = backspaceBurstStarted
                        backspaceDeleting = false; backspaceBurstStarted = false
                        if (e.actionMasked == MotionEvent.ACTION_UP && !burst) action()
                        true
                    }
                    else -> true
                }
            }
        } else {
            slot.setOnClickListener { try { action() } catch (_: Exception) {} }
        }

        row.addView(slot, LayoutParams(0, -1, weight))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDetachedFromWindow() {
        backspaceHandler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
