# ToracoKey AI v0.24

Android keyboard with seven Smart AI, clipboard, question-detection, and word-suggestion improvements.

## Included improvements
- Clipboard text is appended after the existing context.
- Detects "for what" and "in which" question starters.
- Detects "in what", "from where", "difference between", and "difference from".
- Detects the "thing is used to" construction.
- Trailing spaces do not restart the same AI question context.
- Word suggestions commit the selected word with a following space.
- Existing Smart AI, Rewrite, Explain, voice, calculator, modes, and clipboard features retained.


## v0.30 Hello Mode
- Added `Hello` typing mode.
- Each letter is doubled without spaces: `hello` -> `hheelllloo`.
- Backspace removes one complete generated unit in Hello mode, so one backspace removes two letters.
- Existing Mono, Double, and H H modes also use generated-unit-aware backspace.


## v0.32 Changes
- Improved 123/symbol keyboard face.
- Backspace remains at the far-right of the punctuation row.
- Added Time and Date insertion keys on the 123 face.
- Removed separate math/currency/date pages; ABC and 123 remain the only layout switch.
- Calculator output rounds floating-point artifacts, including `1200000-56%` → `528000`.
- Updated GitHub Actions workflow to build the project directly.

## v0.37 User Control
- Added anonymous device registration and authorization.
- Blocked devices are denied access to the keyboard.
- Added separate access-control Render service with admin dashboard.
- Admin can view registered devices, block/unblock devices, and globally disable/enable the keyboard.
