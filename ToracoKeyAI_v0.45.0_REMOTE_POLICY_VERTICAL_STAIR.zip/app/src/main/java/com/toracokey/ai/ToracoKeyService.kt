package com.toracokey.ai

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import androidx.core.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ToracoKeyService : InputMethodService() {
    private val deviceControl by lazy { DeviceControl(this) }
    @Volatile private var deviceAllowed = false // server policy: typingEnabled
    @Volatile private var aiAllowed = false
    @Volatile private var deviceStatus = "policy_unavailable"
    @Volatile private var deviceMessage = "Checking remote feature policy…"
    private val authorizationExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var authorizationCheckRunning = false
    private val policyRefreshRunnable = object : Runnable {
        override fun run() {
            refreshRemotePolicy()
            mainHandler.postDelayed(this, 60_000L)
        }
    }

    companion object {
        private const val BACKEND_URL = "https://toracokeyai-backend.onrender.com/ask"
        private const val DEBOUNCE_MS = 700L
        private const val MAX_AI_ANSWERS = 5
    }

    private lateinit var suggestionScroll: HorizontalScrollView
    private lateinit var suggestions: LinearLayout
    private lateinit var modeButton: Button
    private val mainHandler = Handler(Looper.getMainLooper())
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val debounceExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var pendingRequest: java.util.concurrent.ScheduledFuture<*>? = null
    private var requestNumber = 0L
    private var mode = KeyboardMode.NORMAL
    private var stairCharacterIndex = 0

    // Number of characters produced by each special-mode key press.
    // Backspace removes the complete generated unit instead of only one
    // character. Example: HELLO mode "o" -> "oo", one backspace -> removes "oo".
    private val generatedUnits = java.util.ArrayDeque<Int>()
    private var latestAiAnswers: List<String> = emptyList()
    private var aiError: String? = null
    private enum class AiAction { QUESTION, REWRITE, EXPLAIN }
    private var aiAction = AiAction.QUESTION
    // Trailing spaces must not make the same question look new.
    private var lastQuestionContext: String? = null
    private var showClipboard = false
    private val clipboardItems = mutableListOf<String>()
    private val clipboardManager by lazy {
        getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
    }
    private val clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
        rememberClipboard()
        if (::suggestions.isInitialized) scheduleSuggestionRefresh()
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var voiceListening = false
    private var voiceInputConnection: InputConnection? = null
    private var voiceMode: KeyboardMode = KeyboardMode.NORMAL
    private var voiceRetryCount = 0

    private val voicePermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == VoiceInputActivity.ACTION_VOICE_PERMISSION_GRANTED) {
                startSpeechRecognizer()
            }
        }
    }

    private fun startVoiceTyping() {
        if (!deviceAllowed) {
            updateSuggestions()
            return
        }

        // Capture the editor BEFORE opening the permission activity. The old
        // implementation recaptured currentInputConnection after the activity
        // returned, which can be null on several Android/IME combinations.
        voiceInputConnection = currentInputConnection
        voiceMode = mode
        voiceRetryCount = 0

        if (voiceInputConnection == null) {
            updateSuggestions()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            try {
                startActivity(Intent(this, VoiceInputActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (_: Exception) {
                voiceInputConnection = null
                updateSuggestions()
            }
            return
        }

        startSpeechRecognizer()
    }

    private fun startSpeechRecognizer() {
        mainHandler.post {
            try {
                if (!deviceAllowed || voiceInputConnection == null) {
                    // If the permission activity caused the connection object to
                    // be cleared, make one delayed attempt to reacquire it.
                    val reacquired = currentInputConnection
                    if (deviceAllowed && reacquired != null) {
                        voiceInputConnection = reacquired
                    } else {
                        voiceInputConnection = null
                        if (::suggestions.isInitialized) updateSuggestions()
                        return@post
                    }
                }

                speechRecognizer?.destroy()
                speechRecognizer = null
                if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                    voiceInputConnection = null
                    if (::suggestions.isInitialized) updateSuggestions()
                    return@post
                }

                val recognizer = if (
                    android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                    SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
                ) {
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                } else {
                    SpeechRecognizer.createSpeechRecognizer(this)
                }

                speechRecognizer = recognizer
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {
                        voiceListening = true
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { voiceListening = false }

                    override fun onError(error: Int) {
                        voiceListening = false
                        // Some recognizers report a transient timeout/no-match
                        // even though the microphone and permission are fine.
                        // Give it one clean retry before abandoning voice mode.
                        val retryable = error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_NO_MATCH ||
                            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_SERVER ||
                            error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_NETWORK

                        if (retryable && voiceRetryCount < 1 && voiceInputConnection != null) {
                            voiceRetryCount++
                            mainHandler.postDelayed({ startSpeechRecognizer() }, 250L)
                        } else {
                            voiceInputConnection = null
                            mainHandler.post {
                                if (::suggestions.isInitialized) updateSuggestions()
                            }
                        }
                    }

                    override fun onResults(results: android.os.Bundle?) {
                        voiceListening = false
                        voiceRetryCount = 0
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.trim().orEmpty()

                        val ic = voiceInputConnection
                        val selectedMode = voiceMode
                        voiceInputConnection = null

                        if (text.isNotEmpty() && ic != null) {
                            mainHandler.post {
                                try {
                                    val output = transformVoiceText(text, selectedMode)
                                    ic.commitText(output, 1)
                                } catch (_: Exception) {
                                    // The target editor may have disappeared; do not
                                    // let that terminate the keyboard service.
                                } finally {
                                    if (mode == KeyboardMode.NORMAL) scheduleQuestionDetection()
                                    else scheduleSuggestionRefresh()
                                }
                            }
                        } else if (::suggestions.isInitialized) {
                            updateSuggestions()
                        }
                    }

                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                recognizer.startListening(intent)
            } catch (_: Exception) {
                voiceListening = false
                voiceInputConnection = null
                try { speechRecognizer?.destroy() } catch (_: Exception) {}
                speechRecognizer = null
                if (::suggestions.isInitialized) updateSuggestions()
            }
        }
    }

    private fun stopSpeechRecognizer() {
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        voiceListening = false
    }

    private val keyboardBg = Color.BLACK
    private val suggestionBg = Color.rgb(101, 104, 109)
    private val keyText = Color.rgb(248, 248, 248)

    override fun onCreate() {
        super.onCreate()
        WordSuggestions.initialize(this)
        ContextCompat.registerReceiver(
            this,
            voicePermissionReceiver,
            IntentFilter(VoiceInputActivity.ACTION_VOICE_PERMISSION_GRANTED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        try {
            clipboardManager.addPrimaryClipChangedListener(clipboardListener)
            rememberClipboard()
        } catch (_: Exception) {}
        // Load only a short-lived policy cache, then fetch the authoritative policy.
        applyPolicy(deviceControl.cachedPolicy())
        refreshRemotePolicy()
        mainHandler.postDelayed(policyRefreshRunnable, 60_000L)
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.rgb(92, 95, 100),
                    Color.rgb(62, 64, 68),
                    Color.rgb(28, 29, 31),
                    Color.BLACK
                )
            )
        }

        val suggestionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(55, 57, 60))
        }

        // Fixed left mode control. It is deliberately OUTSIDE the scrolling
        // suggestion list, so it can never drift into the middle/end.
        modeButton = Button(this).apply {
            text = "Mode: ${modeName()}"
            textSize = 13f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0
            minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(7), 0, dp(7), 0)
            background = GradientDrawable().apply {
                setColor(Color.rgb(72, 74, 78))
                cornerRadius = dp(8).toFloat()
            }
            stateListAnimator = null
            setOnClickListener { if (deviceAllowed) cycleMode() else updateSuggestions() }
        }
        suggestionBar.addView(modeButton, LinearLayout.LayoutParams(dp(112), dp(40)).apply {
            setMargins(dp(3), dp(3), dp(4), dp(3))
        })

        suggestionScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.BLACK)
        }
        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        suggestionScroll.addView(suggestions, ViewGroup.LayoutParams(-2, dp(46)))
        suggestionBar.addView(suggestionScroll, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(suggestionBar, LinearLayout.LayoutParams(-1, dp(46)))

        val keyboard = QwertyKeyboard(
            service = this,
            getMode = { mode },
            isAllowed = { deviceAllowed },
            onKey = { value ->
                if (!deviceAllowed) {
                    updateSuggestions()
                } else {
                    commitTypedKey(value)
                    // Special typing modes do not need question/AI processing.
                    // Defer UI work until after the key event has fully returned.
                    if (mode == KeyboardMode.NORMAL) {
                        scheduleQuestionDetection()
                    } else {
                        scheduleSuggestionRefresh()
                    }
                }
            },
            onMode = { if (deviceAllowed) cycleMode() else updateSuggestions() }
        )
        root.addView(keyboard, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        updateSuggestions()
        return root
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        pendingRequest?.cancel(false)
        requestNumber++
        latestAiAnswers = emptyList()
        aiError = null
        aiAction = AiAction.QUESTION
        lastQuestionContext = null
        showClipboard = false
        mode = KeyboardMode.NORMAL
        generatedUnits.clear()
        stairCharacterIndex = 0
        applyPolicy(deviceControl.cachedPolicy())
        rememberClipboard()
        refreshRemotePolicy()
        if (::suggestions.isInitialized) updateSuggestions()
    }

    private var refreshRunnable: Runnable? = null

    private fun scheduleQuestionDetection() {
        refreshRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = Runnable { if (::suggestions.isInitialized) updateQuestionDetection() }
        refreshRunnable = r
        mainHandler.postDelayed(r, 80L)
    }

    private fun scheduleSuggestionRefresh() {
        refreshRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = Runnable {
            if (!::suggestions.isInitialized) return@Runnable
            try { updateSuggestions() } catch (_: Exception) {}
        }
        refreshRunnable = r
        mainHandler.postDelayed(r, 80L)
    }

    private fun updateQuestionDetection() {
        if (!::suggestions.isInitialized) return
        if (!deviceAllowed || !aiAllowed) {
            pendingRequest?.cancel(true)
            pendingRequest = null
            latestAiAnswers = emptyList()
            aiError = if (deviceAllowed) "AI is disabled by the administrator" else null
            updateSuggestions()
            return
        }

        val rawText = editorText()
        val context = rawText.trimEnd()
        val isQuestion =
            QuestionEngine.isQuestion(context) &&
                mode == KeyboardMode.NORMAL

        // A trailing space does not change the semantic/context
        // of the question. Keep the existing request alive.
        if (isQuestion &&
            lastQuestionContext == context
        ) {
            updateSuggestions()
            return
        }

        pendingRequest?.cancel(true)
        pendingRequest = null
        latestAiAnswers = emptyList()
        aiError = null
        aiAction = AiAction.QUESTION

        if (!isQuestion) {
            lastQuestionContext = null
            requestNumber++
            updateSuggestions()
            return
        }

        val question = context
        lastQuestionContext = question

        val thisRequest = ++requestNumber
        updateSuggestions(thinking = true)

        pendingRequest = debounceExecutor.schedule({
            networkExecutor.execute {
                val requestedCount = requestedAnswerCount(question)

                // Send only the actual user question to the backend.
                // The backend is responsible for the AI instructions.
                // Do not build another AI prompt here, otherwise the
                // backend receives the instruction text as the question.
                val result =
                    askBackendWithRetry(question)

                mainHandler.post {
                    if (thisRequest != requestNumber) return@post

                    latestAiAnswers =
                        result.answer
                            ?.let { parseAnswers(it) }
                            .orEmpty()

                    aiError =
                        if (
                            latestAiAnswers.isEmpty() &&
                            result.error == null
                        ) {
                            "No usable answer"
                        } else {
                            result.error
                        }

                    aiAction = AiAction.QUESTION
                    updateSuggestions()
                }
            }
        }, DEBOUNCE_MS, TimeUnit.MILLISECONDS)
    }

    private fun requestedAnswerCount(question: String): Int {
        val q = question.lowercase()
        val words = mapOf(
            "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
            "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10
        )
        val match = Regex("\\b(name|list)\\s+(\\d+|one|two|three|four|five|six|seven|eight|nine|ten)\\b").find(q)
            ?: return 1
        return match.groupValues[2].toIntOrNull() ?: (words[match.groupValues[2]] ?: 1)
    }

    private fun updateSuggestions(thinking: Boolean = false) {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()

        if (!deviceAllowed) {
            addChip("Typing disabled") {}
            addChip(deviceMessage) {}
            return
        }

        val all = editorText()

        if (showClipboard) {
            addChip("Back") {
                showClipboard = false
                updateSuggestions()
            }
            if (clipboardItems.isEmpty()) {
                addChip("No clipboard items") {}
            } else {
                clipboardItems.take(8).forEach { item ->
                    val label = item.replace(Regex("\\s+"), " ").trim().take(45)
                    if (label.isNotEmpty()) {
                        addChip(label) {
                            appendClipboardText(all, item)
                            showClipboard = false
                        }
                    }
                }
            }
            return
        }

        // Mode is a fixed control at the far-left of the toolbar. The scrolling
        // area contains only predictions/tools, so it can never move the mode
        // control into the center or end.
        if (::modeButton.isInitialized) modeButton.text = "Mode: ${modeName()}"

        val wordSuggestions = if (!thinking && mode == KeyboardMode.NORMAL) {
            WordSuggestions.suggest(all, 8)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinctBy { it.lowercase(Locale.ROOT) }
                .take(3)
        } else emptyList()

        wordSuggestions.forEach { word ->
            addChip(word) { replaceToken(word) }
        }

        // Keep the existing keyboard tools, but never let them replace the three
        // prediction slots above.
        if (mode == KeyboardMode.NORMAL) addChip("Voice") { startVoiceTyping() }
        addChip("Clipboard") {
            showClipboard = true
            rememberClipboard()
            updateSuggestions()
        }

        Calculator.calculate(all.substringAfterLast(" "))?.let { value ->
            addChip("= $value") { replaceToken(value) }
        }

        if (aiAllowed && mode == KeyboardMode.NORMAL && all.isNotBlank()) {
            addChip("Rewrite") { requestAiAction(AiAction.REWRITE, all) }
            addChip("Explain") { requestAiAction(AiAction.EXPLAIN, all) }
        }

        if (thinking) {
            addChip("Thinking...") {}
        } else if (latestAiAnswers.isNotEmpty()) {
            latestAiAnswers.take(MAX_AI_ANSWERS).forEach { answer ->
                addChip(answer) {
                    replaceAll(all, answer)
                    latestAiAnswers = emptyList()
                    aiError = null
                }
            }
        } else if (!aiError.isNullOrBlank()) {
            addChip(aiError!!) {}
        } else if (aiAllowed && QuestionEngine.isQuestion(all) && mode == KeyboardMode.NORMAL) {
            addChip("AI ready") { updateQuestionDetection() }
        }

        if (all.isNotEmpty() && mode != KeyboardMode.NORMAL) {
            val transformed = transformAll(all)
            if (transformed != all) addChip(transformed) { replaceAll(all, transformed) }
        }
    }

    private fun requestAiAction(action: AiAction, text: String) {
        if (!deviceAllowed || !aiAllowed) { updateSuggestions(); return }
        val cleanText = text.trim()
        if (cleanText.isEmpty() || mode != KeyboardMode.NORMAL) return

        pendingRequest?.cancel(true)
        pendingRequest = null
        val thisRequest = ++requestNumber
        aiAction = action
        latestAiAnswers = emptyList()
        aiError = null
        updateSuggestions(thinking = true)

        val prompt = when (action) {
            AiAction.REWRITE ->
                "Rewrite the following text to be clearer, natural and grammatically correct. " +
                "Return only the rewritten text. Do not explain it. Do not use tool calls. " +
                "Text: $cleanText"
            AiAction.EXPLAIN ->
                "Explain the following text simply and clearly in a short answer. " +
                "Return only the explanation. Do not use tool calls or safety labels. " +
                "Text: $cleanText"
            AiAction.QUESTION -> cleanText
        }

        pendingRequest = debounceExecutor.schedule({
            networkExecutor.execute {
                val result = askBackendWithRetry(prompt)
                mainHandler.post {
                    if (thisRequest != requestNumber) return@post
                    latestAiAnswers = result.answer?.let { parseAnswers(it) }.orEmpty()
                    aiError = if (latestAiAnswers.isEmpty() && result.error == null) {
                        "No usable answer"
                    } else {
                        result.error
                    }
                    updateSuggestions()
                }
            }
        }, 100L, TimeUnit.MILLISECONDS)
    }

    private fun rememberClipboard() {
        try {
            val clip = clipboardManager.primaryClip ?: return
            if (clip.itemCount <= 0) return
            val text = clip.getItemAt(0)
                .coerceToText(this)
                ?.toString()
                ?.trim()
                .orEmpty()
            if (text.isBlank()) return

            clipboardItems.removeAll { it == text }
            clipboardItems.add(0, text)
            while (clipboardItems.size > 12) {
                clipboardItems.removeAt(clipboardItems.lastIndex)
            }
        } catch (_: SecurityException) {
            // Some Android versions restrict clipboard reads. Keep the keyboard alive.
        } catch (_: Exception) {}
    }

    private fun cycleMode() {
        if (!deviceAllowed) return
        // Change only the state during the key/click callback. Do not mutate the
        // suggestion view hierarchy while Android is dispatching that callback.
        pendingRequest?.cancel(true)
        pendingRequest = null
        requestNumber++

        val values = KeyboardMode.values()
        mode = values[(mode.ordinal + 1) % values.size]
        generatedUnits.clear()
        stairCharacterIndex = 0
        latestAiAnswers = emptyList()
        aiError = null
        aiAction = AiAction.QUESTION
        showClipboard = false

        // Refresh only after the touch dispatch has completely returned.
        scheduleSuggestionRefresh()
    }

    private fun addChip(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(10), 0, dp(10), 0)
            background = GradientDrawable().apply {
                setColor(suggestionBg)
                cornerRadius = dp(9).toFloat()
            }
            stateListAnimator = null
            setOnClickListener {
                if (!deviceAllowed) {
                    updateSuggestions()
                    return@setOnClickListener
                }
                try { action() } catch (_: Exception) {}
            }
        }
        suggestions.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        })
    }

    private fun commitTypedKey(value: String) {
        when (value) {
            "__TORACOKEY_INSERT_TIME__" -> {
                generatedUnits.clear()
                safeCommit(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
                scheduleSuggestionRefresh()
                return
            }
            "__TORACOKEY_INSERT_DATE__" -> {
                generatedUnits.clear()
                safeCommit(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
                scheduleSuggestionRefresh()
                return
            }
        }

        if (value == "\b") {
            deleteByTypingMode()
            return
        }

        if (value == " " || value.length != 1 || !value[0].isLetter()) {
            if (value == " ") {
                // Learn only the most recent two words so repeated spaces do not
                // artificially multiply the frequency of the entire sentence.
                val beforeSpace = editorText().trimEnd()
                val recent = Regex("[A-Za-z]{2,32}")
                    .findAll(beforeSpace)
                    .map { it.value }
                    .toList()
                    .takeLast(2)
                    .joinToString(" ")
                if (recent.isNotBlank()) WordSuggestions.learnFromText(recent)
            }
            generatedUnits.clear()
            if (value.isWhitespace() || value.length != 1 || !value[0].isLetter()) stairCharacterIndex = 0
            safeCommit(value)
            return
        }

        val ch = value[0]
        val ic = currentInputConnection ?: return

        try {
            ic.beginBatchEdit()

            val output: String
            val generatedLength: Int

            when (mode) {
                KeyboardMode.NORMAL,
                KeyboardMode.REVERSE -> {
                    output = ch.toString()
                    generatedLength = 1
                }

                KeyboardMode.MONO -> {
                    output = "$ch "
                    generatedLength = output.length
                }

                KeyboardMode.DOUBLE -> {
                    output = "$ch$ch "
                    generatedLength = output.length
                }

                KeyboardMode.ALT_CASE -> {
                    val before = editorText()
                    val letters = before.count { it.isLetter() }
                    val out =
                        if (letters % 2 == 0)
                            ch.lowercaseChar()
                        else
                            ch.uppercaseChar()

                    output = out.toString()
                    generatedLength = 1
                }

                KeyboardMode.SPACED_DOUBLE -> {
                    output = "$ch $ch "
                    generatedLength = output.length
                }

                KeyboardMode.HELLO -> {
                    // HELLO mode repeats each character twice.
                    output = "$ch$ch"
                    generatedLength = output.length
                }

                KeyboardMode.VERTICAL -> {
                    output = "$ch\n"
                    generatedLength = output.length
                }

                KeyboardMode.STAIR -> {
                    stairCharacterIndex = (stairCharacterIndex + 1).coerceAtMost(80)
                    output = ch.toString().repeat(stairCharacterIndex) + "\n"
                    generatedLength = output.length
                }
            }

            ic.commitText(output, 1)

            // Only special/generated typing needs grouped backspace
            // history. Normal modes behave like ordinary typing.
            if (
                mode == KeyboardMode.MONO ||
                mode == KeyboardMode.DOUBLE ||
                mode == KeyboardMode.SPACED_DOUBLE ||
                mode == KeyboardMode.HELLO ||
                mode == KeyboardMode.VERTICAL ||
                mode == KeyboardMode.STAIR
            ) {
                generatedUnits.addLast(generatedLength)
            } else {
                generatedUnits.clear()
            }

        } catch (_: Exception) {
            try {
                ic.commitText(ch.toString(), 1)
                generatedUnits.clear()
            } catch (_: Exception) {}
        } finally {
            try { ic.endBatchEdit() } catch (_: Exception) {}
        }
    }

    private fun deleteByTypingMode() {
        if (
            mode == KeyboardMode.MONO ||
            mode == KeyboardMode.DOUBLE ||
            mode == KeyboardMode.SPACED_DOUBLE ||
            mode == KeyboardMode.HELLO ||
            mode == KeyboardMode.VERTICAL ||
            mode == KeyboardMode.STAIR
        ) {
            val count =
                if (generatedUnits.isEmpty()) {
                    // If the keyboard has no history (for example after
                    // reopening the input field), remove one character
                    // rather than making an unsafe large deletion.
                    1
                } else {
                    generatedUnits.removeLast()
                }

            safeDelete(count)
        } else {
            safeDelete(1)
        }
    }

    private fun replaceToken(value: String) {
        if (!deviceAllowed) return
        generatedUnits.clear()
        val all = editorText()
        WordSuggestions.learnSelection(all, value)
        val token = all.substringAfterLast(" ")

        if (token.isNotEmpty()) {
            safeDelete(token.length)
        }

        // Commit the selected suggestion as a complete word and
        // leave a space for the next word. This prevents the next
        // typed word from replacing the selected suggestion.
        safeCommit(value.trimEnd() + " ")
        scheduleSuggestionRefresh()
        scheduleQuestionDetection()
    }

    private fun appendClipboardText(
        existing: String,
        clipboardText: String
    ) {
        if (!deviceAllowed) return
        generatedUnits.clear()
        val value = clipboardText.trim()
        if (value.isEmpty()) return

        // Clipboard text is ADDED after the current context.
        // Example:
        // "they are going to" + "school"
        // -> "they are going to school"
        val separator =
            if (existing.isNotEmpty() &&
                !existing.last().isWhitespace()
            ) {
                " "
            } else {
                ""
            }

        safeCommit(separator + value)
        scheduleSuggestionRefresh()
        scheduleQuestionDetection()
    }

    private fun replaceAll(old: String, value: String) {
        if (!deviceAllowed) return
        generatedUnits.clear()
        if (old.isNotEmpty()) safeDelete(old.length)
        safeCommit(value)
        updateQuestionDetection()
    }

    private fun transformVoiceText(input: String, selectedMode: KeyboardMode): String = when (selectedMode) {
        KeyboardMode.NORMAL, KeyboardMode.REVERSE -> input + " "
        KeyboardMode.MONO -> input.split(" ", limit = -1).joinToString(" ") { word ->
            word.toCharArray().joinToString(" ")
        } + " "
        KeyboardMode.DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { word ->
            word.toCharArray().joinToString("") { ch -> "$ch$ch " }.trimEnd()
        } + " "
        KeyboardMode.ALT_CASE -> {
            var upper = false
            buildString(input.length + 1) {
                input.forEach { ch ->
                    if (ch == ' ') { append(ch); upper = false }
                    else { append(if (upper) ch.uppercaseChar() else ch.lowercaseChar()); upper = !upper }
                }
                append(' ')
            }
        }
        KeyboardMode.SPACED_DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { word ->
            word.toCharArray().joinToString(" ") { ch -> "$ch $ch" }
        } + " "
        KeyboardMode.HELLO -> input.toCharArray().joinToString("") { ch ->
            if (ch.isLetter()) "$ch$ch" else ch.toString()
        } + " "
        KeyboardMode.VERTICAL -> input.toCharArray().joinToString("\n", postfix = "\n") { it.toString() }
        KeyboardMode.STAIR -> {
            var index = 0
            input.split(" ", limit = -1).joinToString("\n") { word ->
                index = 0
                word.toCharArray().joinToString("\n") { ch -> ch.toString().repeat(++index) }
            } + "\n"
        }
    }

    private fun transformAll(input: String): String = when (mode) {
        KeyboardMode.NORMAL -> input
        KeyboardMode.REVERSE -> input.reversed()
        KeyboardMode.MONO -> input.split(" ", limit = -1).joinToString(" ") { it.toCharArray().joinToString(" ") }
        KeyboardMode.DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { w -> w.toCharArray().joinToString(" ") { ch -> "$ch$ch" } }
        KeyboardMode.ALT_CASE -> {
            var upper = false
            buildString(input.length) { input.forEach { ch ->
                if (ch == ' ') { append(ch); upper = false }
                else { append(if (upper) ch.uppercaseChar() else ch.lowercaseChar()); upper = !upper }
            }}
        }
        KeyboardMode.SPACED_DOUBLE -> input.split(" ", limit = -1).joinToString(" ") { w -> w.toCharArray().joinToString(" ") { ch -> "$ch $ch" } }
        KeyboardMode.HELLO -> input.toCharArray().joinToString("") { ch ->
            if (ch.isLetter()) "$ch$ch" else ch.toString()
        }
        KeyboardMode.VERTICAL -> input.toCharArray().joinToString("\n", postfix = if (input.isNotEmpty()) "\n" else "") { it.toString() }
        KeyboardMode.STAIR -> input.split(" ", limit = -1).joinToString("\n") { word ->
            var index = 0
            word.toCharArray().joinToString("\n") { ch -> ch.toString().repeat(++index) }
        }
    }

    private fun parseAnswers(raw: String): List<String> {
        val cleaned = raw
            .replace("\\r", "")
            .replace(Regex("(?s)<tool_call_start>.*?<tool_call_end>"), "")
            .replace(Regex("(?s)\\[tool_call_start\\].*?\\[tool_call_end\\]"), "")
            .replace(Regex("(?s)\\|<tool_call_start>.*?\\|<tool_call_end>"), "")
            .trim()

        return cleaned
            .split("\\n", "|||", "•", ";")
            .map {
                it.trim()
                    .replace(Regex("^[-*]\\s+"), "")
                    .replace(Regex("^\\d+[.)]\\s+"), "")
            }
            .filter { it.isNotBlank() }
            .filterNot { looksLikeBadAiOutput(it) }
            .distinct()
            .take(MAX_AI_ANSWERS)
    }

    private fun looksLikeBadAiOutput(text: String): Boolean {
        val q = text.lowercase()
        return q.contains("tool_call_start") ||
            q.contains("tool_call_end") ||
            q.contains("[google](") ||
            q.contains("user safety:") ||
            q.startsWith("user safety") ||
            q.contains("<tool_call")
    }

    private fun editorText(): String = try { currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: "" } catch (_: Exception) { "" }
    private fun safeCommit(value: String) { try { currentInputConnection?.commitText(value, 1) } catch (_: Exception) {} }
    private fun safeDelete(count: Int) { try { currentInputConnection?.deleteSurroundingText(count, 0) } catch (_: Exception) {} }

    private fun modeName() = when (mode) {
        KeyboardMode.NORMAL -> "Normal"
        KeyboardMode.REVERSE -> "Reverse"
        KeyboardMode.MONO -> "Mono"
        KeyboardMode.DOUBLE -> "Double"
        KeyboardMode.ALT_CASE -> "Alt"
        KeyboardMode.SPACED_DOUBLE -> "H H"
        KeyboardMode.HELLO -> "Hello"
        KeyboardMode.VERTICAL -> "Vertical"
        KeyboardMode.STAIR -> "Stair"
    }

    private data class AiResult(val answer: String?, val error: String?)

    private fun askBackendWithRetry(question: String): AiResult {
        var last = AiResult(null, "No answer")
        repeat(2) { attempt ->
            if (Thread.currentThread().isInterrupted) return last
            last = askBackend(question)
            if (last.answer != null && !looksLikeBadAiOutput(last.answer)) return last
            if (attempt == 0) {
                try { Thread.sleep(350L) }
                catch (_: InterruptedException) { return last }
            }
        }
        return if (last.answer != null && looksLikeBadAiOutput(last.answer)) {
            AiResult(null, "AI returned an invalid response")
        } else {
            last
        }
    }

    private fun askBackend(question: String): AiResult {
        if (!deviceAllowed || !aiAllowed) return AiResult(null, "AI is disabled by the administrator")
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 45_000
                doOutput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-ToracoKey-App-Version", DeviceControl.APP_VERSION)
                setRequestProperty("X-ToracoKey-Device", deviceControl.getInstallId())
                setRequestProperty("User-Agent", "ToracoKeyAI/${DeviceControl.APP_VERSION}")
            }
            val body = JSONObject()
                .put("question", question)
                .put("deviceId", deviceControl.getInstallId())
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseBody = stream?.let {
                BufferedReader(InputStreamReader(it, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            if (status == 426) {
                return AiResult(
                    null,
                    "Update required: install ToracoKey AI ${DeviceControl.APP_VERSION} or newer"
                )
            }
            if (status !in 200..299) {
                return AiResult(null, "Server error $status")
            }
            val answer = JSONObject(responseBody).optString("answer").trim()
            if (answer.isNotBlank() && !looksLikeBadAiOutput(answer)) AiResult(answer, null)
            else AiResult(null, "Invalid AI response")
        } catch (e: Exception) {
            val message = e.message?.take(32)?.replace("\n", " ") ?: "Network error"
            AiResult(null, message)
        } finally {
            connection?.disconnect()
        }
    }

    private fun applyPolicy(result: DeviceControl.Result) {
        val wasTypingAllowed = deviceAllowed
        deviceAllowed = result.typingEnabled
        aiAllowed = result.aiEnabled
        deviceStatus = result.status
        deviceMessage = result.message
        if (!deviceAllowed) {
            pendingRequest?.cancel(true)
            pendingRequest = null
            requestNumber++
            stopSpeechRecognizer()
            latestAiAnswers = emptyList()
            aiError = null
            showClipboard = false
            mode = KeyboardMode.NORMAL
        }
        if (!aiAllowed) {
            pendingRequest?.cancel(true)
            pendingRequest = null
            latestAiAnswers = emptyList()
            aiError = if (deviceAllowed) "AI is disabled by the administrator" else null
        }
        if (::suggestions.isInitialized) updateSuggestions()
    }

    private fun refreshRemotePolicy() {
        if (authorizationCheckRunning) return
        authorizationCheckRunning = true
        authorizationExecutor.execute {
            val result = try {
                deviceControl.checkPolicy()
            } catch (_: Exception) {
                deviceControl.cachedPolicy()
            } finally {
                authorizationCheckRunning = false
            }
            mainHandler.post { applyPolicy(result) }
        }
    }

    override fun onDestroy() {
        stopSpeechRecognizer()
        try { unregisterReceiver(voicePermissionReceiver) } catch (_: Exception) {}
        try { clipboardManager.removePrimaryClipChangedListener(clipboardListener) } catch (_: Exception) {}
        pendingRequest?.cancel(true)
        pendingRequest = null
        requestNumber++
        try { debounceExecutor.shutdownNow() } catch (_: Exception) {}
        try { networkExecutor.shutdownNow() } catch (_: Exception) {}
        try { authorizationExecutor.shutdownNow() } catch (_: Exception) {}
        mainHandler.removeCallbacks(policyRefreshRunnable)
        mainHandler.removeCallbacksAndMessages(null)
        voiceInputConnection = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
